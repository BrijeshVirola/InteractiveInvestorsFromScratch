package tests.clientnetpositionservice.enums;

import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.clientnetpositionservice.response.GetNetPositionGameConfigResp;
import tests.clientnetpositionservice.response.GetNetPositionResp;

public enum ClientNetPositionEndPoints implements ResponseEndpoints {

	getNetPositionGameConfigSuccess(GetNetPositionGameConfigResp.class, "getnetpositiongameconfig"),
	getNetPositionGameConfigError(CustomErrorResponse.class, "getnetpositiongameconfig"),
	getNetPositionSuccess(GetNetPositionResp.class, "getnetposition"),
	getNetPositionError(CustomErrorResponse.class, "getnetposition");


	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> ClientNetPositionEndPoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
