package tests.clientnetpositionservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetNetPositionGameConfigReq {
	
	private Map<String, Object> parameters = new HashMap<>();

	private GetNetPositionGameConfigReq(Builder builder) {
		this.parameters.put("gt", builder.gt);
		this.parameters.put("gmpid", builder.gmpid);
	}
	
	public Map<String, Object> getParameters() {
		return parameters;
	}

	public static class Builder {
		private String gt;
		private Integer gmpid;

		public Builder params(String gt, Integer gmpid) {
			this.gt = gt;
			this.gmpid = gmpid;
			return this;
		}
		
		public Builder gt(String gt) {
			this.gt = gt;
			return this;
		}

		public Builder gmpid(Integer gmpid) {
			this.gmpid = gmpid;
			return this;
		}
		
		public Builder defaults() {
			this.gt = "AfterShock";
			this.gmpid = 4;
			return this;
		}

		public GetNetPositionGameConfigReq build() {
			return new GetNetPositionGameConfigReq(this);
		}
	}
}
