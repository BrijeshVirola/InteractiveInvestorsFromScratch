package tests.clientnetpositionservice;

import common.BaseClassSetup;

public class GetNetPositionTests extends BaseClassSetup {
	

}
