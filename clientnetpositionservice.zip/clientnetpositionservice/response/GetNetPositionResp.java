package tests.clientnetpositionservice.response;


public class GetNetPositionResp {
	
	@SuppressWarnings("unused")
	private Long sd;
	@SuppressWarnings("unused")
	private Double np;
	@SuppressWarnings("unused")
	private Double ba;
	@SuppressWarnings("unused")
	private Double wa;

	private GetNetPositionResp(Builder builder) {
		this.sd = builder.sd;
		this.np = builder.np;
		this.ba = builder.ba;
		this.wa = builder.wa;
	}

	public static class Builder {
		private Long sd;
		private Double np;
		private Double ba;
		private Double wa;

		public Builder sd(Long sd) {
			this.sd = sd;
			return this;
		}

		public Builder np(Double np) {
			this.np = np;
			return this;
		}
		
		public Builder ba(Double ba) {
			this.ba = ba;
			return this;
		}
		
		public Builder wa(Double wa) {
			this.wa = wa;
			return this;
		}
		
		public Builder defaults() {
			this.sd = 3543L;
			this.np = 0D;
			this.ba = 0D;
			this.wa = 0D;
			return this;
		}

		public GetNetPositionResp build() {
			return new GetNetPositionResp(this);
		}
	}
}
