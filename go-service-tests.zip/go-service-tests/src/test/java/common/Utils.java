package common;

import java.math.BigDecimal;
import java.util.UUID;

import common.enumsconstants.ResponseEndpoints;
import common.testtoken.request.CreateSlotsSessionTestReq;
import common.testtoken.response.CreateSlotsSessionTestResp;
import domain.BaseRequest;
import junit.framework.Assert;
import tests.slotsservice.request.GetActiveGameSessionReq;
import tests.slotsservice.response.GameSessionResp;
import tests.tokenservice.request.CreatePrivateTokenReq;
import tests.tokenservice.request.CreatePublicTokenReq;
import tests.tokenservice.requestobjects.CreatePrivateTokenParams;
import tests.tokenservice.requestobjects.CreatePublicTokenParams;
import tests.tokenservice.response.CreatePublicTokenResp;
import tests.tokenservice.response.TokenResp;

public class Utils {

	public static CreatePublicTokenResp createNewPublicToken(int userId) {

		String publicToken = UUID.randomUUID().toString();

		CreatePublicTokenReq publicRequest = new CreatePublicTokenReq
				.Builder()
				.defaults()
				.params(new CreatePublicTokenParams
						.Builder()
						.defaults()
						.userId(userId)
						.publicToken(publicToken)
						.build())
				.build();

		CreatePublicTokenResp actualCreateResponse =  BaseRequest.getResponse(publicRequest, ResponseEndpoints.createPublicTokenSuccess);
		CreatePublicTokenResp expectedCreateResponse = new CreatePublicTokenResp.Builder()
				.id(null)
				.defaults()
				.sno(actualCreateResponse.sno())
				.publicToken(publicToken)
				.build();

		Assert.assertEquals(expectedCreateResponse.publicToken(),actualCreateResponse.publicToken());
		Assert.assertTrue(actualCreateResponse.sno() > 0);

		return actualCreateResponse;
	}

	public static TokenResp createNewPrivateToken(String publicToken) {
		CreatePrivateTokenReq request = new CreatePrivateTokenReq
				.Builder()
				.defaults()
				.params(new CreatePrivateTokenParams
						.Builder()
						.defaults()
						.token(publicToken)
						.build())
				.build();
		TokenResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.createPrivateTokenSuccess);
		return actualResponse;
	}

	public static String createNewSlotsSession(String username, BigDecimal slotsSessionBalance) {

		CreateSlotsSessionTestReq publicRequest = new CreateSlotsSessionTestReq
				.Builder()
				.defaults()
				.username(username)
				.slotsSessionBalance(slotsSessionBalance)
				.build();

		CreateSlotsSessionTestResp token = BaseRequest.getResponse(publicRequest, ResponseEndpoints.createSlotsSessionTokenSuccess);
		return token.getTestToken();
	}
	
	public static String getSlotsGameSessionId(int userId) {

		GetActiveGameSessionReq request = new GetActiveGameSessionReq.Builder()
				.defaults()
				.userId(userId)
				.build();

		GameSessionResp actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getActiveGameSessionSuccess);

		return actResponse.getGameSessionId();
	}

}
