package common.testtoken.response;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CreateSlotsSessionTestResp {

	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> result = new HashMap<>();

	private CreateSlotsSessionTestResp(Builder builder) {
		this.id = builder.id;
		this.result.put("test_tokens", builder.test_tokens);
	}

	public String getTestToken() {
		String token = this.result.get("test_tokens").toString().replaceAll("\\[", "").replaceAll("\\]", "");
		return token;
	}

	public static class Builder {
		private String id;
		private ArrayList<String> test_tokens;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder testTokens(ArrayList<String> test_tokens) {
			this.test_tokens = test_tokens;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			return this;
		}

		public CreateSlotsSessionTestResp build() {
			return new CreateSlotsSessionTestResp(this);
		}
	}
}


