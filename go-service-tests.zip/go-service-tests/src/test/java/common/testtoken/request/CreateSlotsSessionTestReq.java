package common.testtoken.request;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class CreateSlotsSessionTestReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private CreateSlotsSessionTestReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("username", builder.username);
		this.params.put("regulated_game_id", builder.regulated_game_id);
		this.params.put("token_quantity", builder.token_quantity);
		this.params.put("reality_check_interval", builder.reality_check_interval);
		this.params.put("reality_check_seconds_until", builder.reality_check_seconds_until);
		this.params.put("set_last_token_as_currently_in_play", builder.set_last_token_as_currently_in_play);
		this.params.put("slots_session_balance", builder.slots_session_balance);
	}

	public static class Builder {
		private String id, method, username;
		private Integer regulated_game_id, token_quantity, reality_check_interval, reality_check_seconds_until;
		private Boolean set_last_token_as_currently_in_play;
		private BigDecimal slots_session_balance;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder regulatedGameId(Integer regulated_game_id) {
			this.regulated_game_id = regulated_game_id;
			return this;
		}

		public Builder username(String username) {
			this.username = username;
			return this;
		}

		public Builder tokenQuantity(Integer token_quantity) {
			this.token_quantity = token_quantity;
			return this;
		}

		public Builder realityCheckInterval(Integer reality_check_interval) {
			this.reality_check_interval = reality_check_interval;
			return this;
		}

		public Builder realityCheckSecondsUntil(Integer reality_check_seconds_until) {
			this.reality_check_seconds_until = reality_check_seconds_until;
			return this;
		}

		public Builder setLastTokenAsCurrentlyInPlay(Boolean set_last_token_as_currently_in_play) {
			this.set_last_token_as_currently_in_play = set_last_token_as_currently_in_play;
			return this;
		}

		public Builder slotsSessionBalance(BigDecimal slots_session_balance) {
			this.slots_session_balance = slots_session_balance;
			return this;
		}

		public Builder defaults() {
			this.method = "createslotstoken-test";
			this.id = "1";
			this.username = "go_svc_tests06";
			this.regulated_game_id = 97998;
			this.token_quantity = 1;
			this.reality_check_interval = 1000;
			this.reality_check_seconds_until = 200;
			this.set_last_token_as_currently_in_play = true;
			this.slots_session_balance = new BigDecimal("50.0");
			return this;
		}

		public CreateSlotsSessionTestReq build() {
			return new CreateSlotsSessionTestReq(this);
		}
	}
}

