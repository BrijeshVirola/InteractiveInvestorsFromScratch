package common;
import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.testng.Assert;

import logging.Log;


public class TimeUtils {

	public static String getCurrentTimeAsIsoString() {
		Date currentDate = new Date(System.currentTimeMillis());
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		return dateFormat.format(currentDate);
	}
	
	@SuppressWarnings("restriction")
	public static void dateTime_UTC_Response_Validation(String jsonResponse) {
	try {
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	Date date = new Date();
	String currentSystemDate = dateFormat.format(date); 
	
	Format timeFormat = new SimpleDateFormat("HH:mm");
	String currentTime = timeFormat.format(new Date());



	Assert.assertTrue(jsonResponse.contains(currentSystemDate));
	Assert.assertTrue(jsonResponse.contains(currentTime));
	System.out.println("Time & Date is Validated Successfully");
	} catch (Exception e) {
	e.printStackTrace();

	}
	}

}
