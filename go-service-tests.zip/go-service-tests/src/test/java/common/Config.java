package common;

public class Config {

	public static final long nodeId = 69L;
	public static String tokenPort = "18020";
	public static String gamesPort = "18040";
	public static String gameRoundPort = "18060";
	public static String balancePort = "18050";
	public static String userPort = "18030";
	public static String jackpotDetailsPort = "18130";
	public static String promotionsPort = "18140";
	public static String prizePort = "18180";
	public static String swedenWinLossPort = "18200";
	public static String realityCheckPort = "18070";
	public static String sessionTestPort = "18380";
	public static String netpositionPort = "18480";
	public static String pokerTournamentsPort = "18340";
	public static String cbsBalancePort = "18240";
	public static String slotsPort = "18190";
	public static String gameplayLimitsPort = "8421";
}
