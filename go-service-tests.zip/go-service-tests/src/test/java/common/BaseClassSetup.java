package common;

import org.testng.ITestContext;
import org.testng.annotations.BeforeSuite;

import io.restassured.RestAssured;

public class BaseClassSetup {
	
	private static String baseUri;
	public static String baseUriJackpotDetailsService;
	public static String baseUriUserService;
	public static String baseUriGamesService;
	public static String baseUriGameRoundService;
	public static String baseUriPromotionsService;
	public static String baseUriTokenService;
	public static String baseUriPrizeService;
	public static String baseUriSwedenWinLossService;
	public static String baseUriNetPositionService;
	public static String baseUriPokerTournamentsService;
	public static String baseUriCbsBalanceService;
	public static String baseUriGamingBonusAdminService;
	public static String baseUriGbtService;
	public static String baseUriSlotsService;
	public static String baseUriGamingBonusService;
	public static String baseUriGameLaunchTokenService;
	public static String baseUriGameplayLimitsServices;
	public static String baseUriPlaytechBalanceService;

	
	@BeforeSuite()
	public void init(ITestContext context) {

		baseUri = System.getProperty("baseUri") != null ? System.getProperty("baseUri") : context.getCurrentXmlTest().getParameter("baseUri");
		RestAssured.baseURI = baseUri;
		
		setupServicesUri();
	}
	
	private static void setupServicesUri() {
		baseUriJackpotDetailsService = RestAssured.baseURI + ":" + Config.jackpotDetailsPort + "/api/";
		baseUriUserService = RestAssured.baseURI + ":" + Config.userPort + "/api/";
		baseUriGamesService = RestAssured.baseURI + ":" + Config.gamesPort + "/api/";
		baseUriGameRoundService = RestAssured.baseURI + ":" + Config.gameRoundPort + "/api/";
		baseUriPrizeService = RestAssured.baseURI + ":" + Config.prizePort + "/api/";
		baseUriPromotionsService = RestAssured.baseURI + ":" + Config.promotionsPort + "/api/";
		baseUriTokenService = RestAssured.baseURI + ":" + Config.tokenPort + "/api/";
		baseUriSwedenWinLossService = RestAssured.baseURI + ":" + Config.swedenWinLossPort + "/api/";
		baseUriNetPositionService = RestAssured.baseURI + ":" + Config.netpositionPort + "/api/";
		baseUriPokerTournamentsService = RestAssured.baseURI + ":" + Config.pokerTournamentsPort + "/api/";
		baseUriCbsBalanceService = RestAssured.baseURI + ":" + Config.cbsBalancePort + "/api/";
		baseUriGamingBonusAdminService = RestAssured.baseURI + "/api/";
		baseUriGbtService = RestAssured.baseURI + "/api/";
		baseUriSlotsService = RestAssured.baseURI + ":" + Config.slotsPort + "/api/";
		baseUriGamingBonusService = RestAssured.baseURI + "/api/";
		baseUriGameLaunchTokenService = RestAssured.baseURI + "/api/";
		baseUriGameplayLimitsServices = RestAssured.baseURI + ":" + Config.gameplayLimitsPort + "/api/";
		baseUriPlaytechBalanceService = RestAssured.baseURI + "/api/";
	}
}
