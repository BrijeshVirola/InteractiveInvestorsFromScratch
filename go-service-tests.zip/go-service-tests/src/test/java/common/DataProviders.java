package common;
import org.testng.annotations.DataProvider;

import common.enumsconstants.ProductId;
import common.enumsconstants.ServiceErrors;
import common.enumsconstants.UsersId;

public class DataProviders {
	
	private final int regulatedGameId = 6403;
	private final int anyRegulatedGameId = -1;
	private final int cmscoreGameId = 2885;
	private final int anyCmscoreGameId = -1;
	
	@DataProvider(name = "nullZero")
	public Object[] nullZero() {
		return new Object[] {"null", "0"};
	}
	
	@DataProvider(name = "nullEmptyString")
	public Object[] nullOrEmptyString() {
		return new Object[] {"null", ""};
	}
	
	@DataProvider(name = "group1TransactionTypeProvider")
	public Object[][] getGroup1TransactionTypes() {
		return new Object[][] {
				{TransactionType.STAKE, regulatedGameId, cmscoreGameId},
				{TransactionType.FREE_SPIN_STAKE, regulatedGameId, cmscoreGameId},
				{TransactionType.GOLDEN_CHIP_STAKE, regulatedGameId, cmscoreGameId},
				{TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId},
				{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO, anyRegulatedGameId, anyCmscoreGameId},
				{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO, anyRegulatedGameId, anyCmscoreGameId},
				{TransactionType.POKER_BUY_CHIPS, anyRegulatedGameId, anyCmscoreGameId},
				{TransactionType.POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId},
				{TransactionType.POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId},
				{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER, anyRegulatedGameId, anyCmscoreGameId}
				};
	}
	
	@DataProvider(name = "group1TransactionTypeAmountProvider")
	public Object[][] getGroup1TransactionTypeAmount() {
		return new Object[][] {
			{TransactionType.STAKE, regulatedGameId, cmscoreGameId,"0.00","-1.00"},
			{TransactionType.FREE_SPIN_STAKE, regulatedGameId, cmscoreGameId,"0.00","-1.00"},
			{TransactionType.GOLDEN_CHIP_STAKE, regulatedGameId, cmscoreGameId,"0.00","-1.00"},
			{TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId,"0.00","-1.00"},
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO, anyRegulatedGameId, anyCmscoreGameId,"0.00","-1.00"},
		{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO, anyRegulatedGameId, anyCmscoreGameId,"0.00","-1.00"},
			{TransactionType.POKER_BUY_CHIPS, anyRegulatedGameId, anyCmscoreGameId,"0.00","-1.00"},
			{TransactionType.POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId,"0.00","-1.00"},
			{TransactionType.POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId,"0.00","-1.00"},
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER, anyRegulatedGameId, anyCmscoreGameId,"0.00","-1.00"}
		};
	}
	
	@DataProvider(name = "group3TransactionTypeAmountProvider")
	public Object[][] getGroup3TransactionTypeAmount() {
		return new Object[][] {
			{TransactionType.FREE_SPIN_RETURN, regulatedGameId, cmscoreGameId, "1", "1"},
			{TransactionType.GOLDEN_CHIP_RETURN, regulatedGameId, cmscoreGameId, "1", "1"},
			{TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "1", "1"},
			{TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_CASINO, anyRegulatedGameId, cmscoreGameId, "1", "1"},
			{TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_LIVE_CASINO, anyRegulatedGameId, cmscoreGameId, "1", "1"},
			{TransactionType.POKER_SELL_CHIPS, regulatedGameId, cmscoreGameId, "1", "1"},
			{TransactionType.POKER_TOURNAMENT_WIN, regulatedGameId, cmscoreGameId, "1", "1"},
			{TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_POKER, anyRegulatedGameId, cmscoreGameId, "1", "1"},
		};
	}
	
	@DataProvider(name = "group6TransactionTypeAmountProvider")
	public Object[][] getGroup6TransactionTypeAmount() {
		return new Object[][] {
			{TransactionType.VOID_STAKE, regulatedGameId, cmscoreGameId,"-0.00","-0.00"},
			{TransactionType.VOID_GAMING_STAKE, regulatedGameId, cmscoreGameId,"-0.00","-0.00"},
			{TransactionType.VOID_POKER_BUY_CHIPS, regulatedGameId, cmscoreGameId,"-0.00","-0.00"},
			{TransactionType.VOID_POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId,"-0.00","-0.00"},
			{TransactionType.VOID_POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId,"-0.00","-0.00"},
			{TransactionType.FREE_SPIN_RETURN, regulatedGameId, cmscoreGameId,"-0.00","-0.00"},
		};
	}
	
	@DataProvider(name = "externalBalanceChangeNegativeAmounts")
	public Object[][] externalBalanceChangeNegativeAmounts() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0"},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0"},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0"},
			{ProductId.LIVE_CASINO.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0"}
		};
	}
	
	@DataProvider(name = "handleGbtPositiveAmounts")
	public Object[][] handleGbtPositiveAmounts() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.STAKE},
			{ProductId.GAMES.getId(), TransactionType.FREE_SPIN_STAKE},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GOLDEN_CHIP_STAKE},
			{ProductId.GAMES.getId(), TransactionType.GAMING_STAKE},
			{ProductId.POKER.getId(), TransactionType.POKER_BUY_CHIPS},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_ENTRY},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_REBUY},
			{ProductId.BINGO.getId(), TransactionType.STAKE},
		};
	}
	
	@DataProvider(name = "handleGbtNegativeAmounts")
	public Object[][] handleGbtNegativeAmounts() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.RETURN, 1006, "Returns must use a positive real_amount"},
			{ProductId.GAMES.getId(), TransactionType.FREE_SPIN_RETURN, 1006, "Returns must use a positive real_amount"},
			{ProductId.GAMES.getId(), TransactionType.GOLDEN_CHIP_RETURN, 1006, "Returns must use a positive real_amount"},
			{ProductId.GAMES.getId(), TransactionType.GAMING_RETURN, 1006, "Returns must use a positive real_amount"},
			{ProductId.POKER.getId(), TransactionType.POKER_SELL_CHIPS, 1006, "Returns must use a positive real_amount"},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_WIN, 1006, "Returns must use a positive real_amount"},
			{ProductId.BINGO.getId(), TransactionType.RETURN, 1006, "Returns must use a positive real_amount"},
			{ProductId.CASINO.getId(), TransactionType.VOID_GAMING_STAKE, 1006, "Void stakes must use a positive real_amount"},
			{ProductId.GAMES.getId(), TransactionType.VOID_GAMING_STAKE, 1006, "Void stakes must use a positive real_amount"},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_BUY_CHIPS, 1006, "Void stakes must use a positive real_amount"},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, 1006, "Void stakes must use a positive real_amount"},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_REBUY, 1006, "Void stakes must use a positive real_amount"},
			{ProductId.BINGO.getId(), TransactionType.VOID_STAKE, 1006, "Void stakes must use a positive real_amount"},
		};
	}
	
	@DataProvider(name = "externalBalanceChangePositiveAmounts")
	public Object[][] externalBalanceChangePositiveAmounts() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.VOID_GAMING_STAKE, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_BUY_CHIPS, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.CASINO.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "0.12", "0.12", "0", "0"},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "1", "1", "0", "0"},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_CASINO, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.LIVE_CASINO.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_LIVE_CASINO, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.POKER_SELL_CHIPS, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_WIN, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
			{ProductId.POKER.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_POKER, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0"},
		};
	}
	
	@DataProvider(name = "externalBalanceChangeErrors")
	public Object[][] externalBalanceChangeErrors() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.VOID_GAMING_STAKE, regulatedGameId, cmscoreGameId, "0.1", "-0.1", "0", "0", "Requested transfer amounts do not add up", 1006},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_BUY_CHIPS, regulatedGameId, cmscoreGameId, "0.2", "-0.1", "0", "0", "Requested transfer amounts do not add up", 1006},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId, "0.1", "-0.1", "0", "0", "Requested transfer amounts do not add up", 1006},
			{ProductId.GAMES.getId(), TransactionType.VOID_GAMING_STAKE, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.BINGO.getId(), TransactionType.VOID_POKER_BUY_CHIPS, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SLOTS.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SPORTSBOOK.getId(), TransactionType.VOID_POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.GAMES.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.BINGO.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "0.12", "0.12", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SLOTS.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "1", "1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SPORTSBOOK.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_CASINO, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.GAMES.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_LIVE_CASINO, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.BINGO.getId(), TransactionType.POKER_SELL_CHIPS, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SLOTS.getId(), TransactionType.POKER_TOURNAMENT_WIN, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SPORTSBOOK.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_POKER, regulatedGameId, cmscoreGameId, "0.1", "0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.GAMES.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.BINGO.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SLOTS.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SPORTSBOOK.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.GAMES.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.BINGO.getId(), TransactionType.POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SLOTS.getId(), TransactionType.POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.SPORTSBOOK.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER, regulatedGameId, cmscoreGameId, "-0.1", "-0.1", "0", "0", "product_id must be for a Casino or Poker product", 1011},
			{ProductId.CASINO.getId(), TransactionType.VOID_GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Void stakes must use a positive real_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_BUY_CHIPS, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Void stakes must use a positive real_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Void stakes must use a positive real_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Void stakes must use a positive real_amount", 1006},
			{ProductId.CASINO.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Returns must use a positive real_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "-0.12", "0.12", "0", "0", "Returns must use a positive real_amount", 1006},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GAMING_RETURN, regulatedGameId, cmscoreGameId, "-1", "1", "0", "0", "Returns must use a positive real_amount", 1006},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_CASINO, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Returns must use a positive real_amount", 1006},
			{ProductId.LIVE_CASINO.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_LIVE_CASINO, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Returns must use a positive real_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.POKER_SELL_CHIPS, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Returns must use a positive real_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_WIN, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Returns must use a positive real_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_POKER, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Returns must use a positive real_amount", 1006},
			{ProductId.CASINO.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.2", "0.1", "0", "0", "Stakes must use a negative total_amount", 1006},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Stakes must use a negative total_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Stakes must use a negative total_amount", 1006},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Stakes must use a negative total_amount", 1006},
			{ProductId.LIVE_CASINO.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Stakes must use a negative total_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Stakes must use a negative total_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Stakes must use a negative total_amount", 1006},
			{ProductId.POKER.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER, regulatedGameId, cmscoreGameId, "-0.1", "0.1", "0", "0", "Stakes must use a negative total_amount", 1006}
		};
	}
	
	@DataProvider(name = "externalBalanceChangeMissingParameters")
	public Object[][] externalBalanceChangeMissingParameters() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.VOID_GAMING_STAKE, "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_BUY_CHIPS, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_REBUY, "user_id", "Missing parameter: user_id", 7},
			{ProductId.CASINO.getId(), TransactionType.VOID_GAMING_STAKE, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_BUY_CHIPS, "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, "token", "Missing parameter: token", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_REBUY, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.CASINO.getId(), TransactionType.VOID_GAMING_STAKE, "action_type_id", "Invalid action_type_id", 1011},
			{ProductId.CASINO.getId(), TransactionType.GAMING_RETURN, "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.POKER.getId(), TransactionType.GAMING_RETURN, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GAMING_RETURN, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_CASINO, "user_id", "Missing parameter: user_id", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_LIVE_CASINO, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_SELL_CHIPS, "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_WIN, "token", "Missing parameter: token", 7},
			{ProductId.POKER.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_POKER, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.CASINO.getId(), TransactionType.GAMING_RETURN, "action_type_id", "Invalid action_type_id", 1011},
			{ProductId.CASINO.getId(), TransactionType.GAMING_STAKE, "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GAMING_STAKE, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.POKER.getId(), TransactionType.GAMING_STAKE, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO, "user_id", "Missing parameter: user_id", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO,  "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_ENTRY, "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_REBUY, "token", "Missing parameter: token", 7},
			{ProductId.POKER.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.CASINO.getId(), TransactionType.GAMING_STAKE, "action_type_id", "Invalid action_type_id", 1011}
		};
	}
	
	@DataProvider(name = "handleGbtMissingParameters")
	public Object[][] handleGbtMissingParameters() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.VOID_STAKE, "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.GAMES.getId(), TransactionType.VOID_GAMING_STAKE, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_BUY_CHIPS, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_REBUY, "user_id", "Missing parameter: user_id", 7},
			{ProductId.BINGO.getId(), TransactionType.VOID_STAKE, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.SLOTS.getId(), TransactionType.VOID_GAMING_STAKE, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.SPORTSBOOK.getId(), TransactionType.VOID_STAKE, "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, "token", "Missing parameter: token", 7},
			{ProductId.SPORTSBOOK.getId(), TransactionType.VOID_GAMING_STAKE, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.VOID_STAKE, "action_type_id", "Invalid action_type_id", 1011},
			{ProductId.CASINO.getId(), TransactionType.RETURN, "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.GAMES.getId(), TransactionType.FREE_SPIN_RETURN, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.GAMES.getId(), TransactionType.GOLDEN_CHIP_RETURN, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.GAMES.getId(), TransactionType.GAMING_RETURN, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_SELL_CHIPS, "user_id", "Missing parameter: user_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_WIN, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.RETURN, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.SLOTS.getId(), TransactionType.GAMING_RETURN, "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.SPORTSBOOK.getId(), TransactionType.RETURN, "token", "Missing parameter: token", 7},
			{ProductId.CASINO.getId(), TransactionType.FREE_SPIN_RETURN, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.CASINO.getId(), TransactionType.GOLDEN_CHIP_RETURN, "action_type_id", "Invalid action_type_id", 1011},
			{ProductId.GAMES.getId(), TransactionType.GAMING_STAKE, "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.CASINO.getId(), TransactionType.STAKE, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GOLDEN_CHIP_STAKE, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.GAMES.getId(), TransactionType.FREE_SPIN_STAKE, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_BUY_CHIPS, "user_id", "Missing parameter: user_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_ENTRY, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_REBUY,  "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.BINGO.getId(), TransactionType.STAKE, "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.GAMES.getId(), TransactionType.STAKE, "token", "Missing parameter: token", 7},
			{ProductId.SLOTS.getId(), TransactionType.STAKE, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.SPORTSBOOK.getId(), TransactionType.STAKE, "action_type_id", "Invalid action_type_id", 1011}
		};
	}
	
	@DataProvider(name = "handleStakeMissingParameters")
	public Object[][] handleStakeMissingParameters() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.STAKE, "token", "Missing parameter: token", 7},
			{ProductId.GAMES.getId(), TransactionType.FREE_SPIN_STAKE, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.GOLDEN_CHIP_STAKE, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.SPORTSBOOK.getId(), TransactionType.GAMING_STAKE, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO, "user_id", "Missing parameter: user_id", 7},
			{ProductId.LIVE_CASINO.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_BUY_CHIPS, "cmscore_game_id", "Missing parameter: cmscore_game_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_ENTRY, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_REBUY,  "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.POKER.getId(), TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER,  "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.BINGO.getId(), TransactionType.STAKE, "currency_id", "Missing parameter: currency_id", 7},
		};
	}
	
	@DataProvider(name = "handleInstantGamesStakeMissingParameters")
	public Object[][] handleInstantGamesStakeMissingParameters() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_STAKE, "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_STAKE, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_STAKE, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_STAKE, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_STAKE, "user_id", "Missing parameter: user_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_STAKE, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_STAKE, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_STAKE,  "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_STAKE,  "token", "Missing parameter: token", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_STAKE, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_STAKE, "action_type_id", "Invalid action_type_id", 1011},
		};
	}
	
	@DataProvider(name = "handleReturnMissingParameters")
	public Object[][] handleReturnMissingParameters() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.RETURN, "token", "Missing parameter: token", 7},
			{ProductId.CASINO.getId(), TransactionType.FREE_SPIN_RETURN, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.CASINO.getId(), TransactionType.GOLDEN_CHIP_RETURN, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_CASINO, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.CASINO.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_LIVE_CASINO, "user_id", "Missing parameter: user_id", 7},
			{ProductId.GAMES.getId(), TransactionType.GAMING_RETURN, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_SELL_CHIPS, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.POKER.getId(), TransactionType.POKER_TOURNAMENT_WIN,  "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.POKER.getId(), TransactionType.TRANSFER_FROM_PLAYTECH_BONUS_POKER,  "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.BINGO.getId(), TransactionType.RETURN, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.CASINO.getId(), TransactionType.GOLDEN_CHIP_RETURN, "source_bet365_games_transaction_id", "Missing parameter: source_bet365_games_transaction_id", 7},
			{ProductId.GAMES.getId(), TransactionType.RETURN, "action_type_id", "Invalid action_type_id", 1011},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_RETURN, "token", "Missing parameter: token", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_RETURN, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_RETURN, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_RETURN, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_RETURN, "user_id", "Missing parameter: user_id", 7},
			{ProductId.CASINO.getId(), TransactionType.INSTANT_GAMES_RETURN, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_RETURN, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_RETURN,  "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_RETURN,  "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_RETURN, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_RETURN, "source_bet365_games_transaction_id", "Missing parameter: source_bet365_games_transaction_id", 7},
			{ProductId.GAMES.getId(), TransactionType.INSTANT_GAMES_RETURN, "action_type_id", "Invalid action_type_id", 1011},
		};
	}
	
	@DataProvider(name = "handlePrizeMissingParameters")
	public Object[][] handlePrizeMissingParameters() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.GAMING_PRIZE_AWARD, "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.GAMES.getId(), TransactionType.GAMING_PRIZE_AWARD, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.CASINO.getId(), TransactionType.GAMING_PRIZE_AWARD, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.GAMES.getId(), TransactionType.GAMING_PRIZE_AWARD, "user_id", "Missing parameter: user_id", 7},
			{ProductId.POKER.getId(), TransactionType.GAMING_PRIZE_AWARD, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.SLOTS.getId(), TransactionType.GAMING_PRIZE_AWARD,  "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.POKER.getId(), TransactionType.GAMING_PRIZE_AWARD,  "token", "Missing parameter: token", 7},
			{ProductId.BINGO.getId(), TransactionType.GAMING_PRIZE_AWARD, "currency_id", "Missing parameter: currency_id", 7},
		};
	}
	
	@DataProvider(name = "handleVoidStake")
	public Object[][] handleVoidStake() {
		return new Object[][] {
			{ProductId.CASINO.getId(), TransactionType.VOID_STAKE, "token", "Missing parameter: token", 7},
			{ProductId.GAMES.getId(), TransactionType.VOID_GAMING_STAKE, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_BUY_CHIPS, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_ENTRY, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_POKER_TOURNAMENT_REBUY, "user_id", "Missing parameter: user_id", 7},
			{ProductId.BINGO.getId(), TransactionType.VOID_STAKE, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_STAKE, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_GAMING_STAKE,  "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.POKER.getId(), TransactionType.VOID_STAKE,  "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.BINGO.getId(), TransactionType.VOID_GAMING_STAKE, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.GAMES.getId(), TransactionType.VOID_STAKE, "action_type_id", "Invalid action_type_id", 1011},
			{ProductId.CASINO.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "token", "Missing parameter: token", 7},
			{ProductId.GAMES.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "game_round_id", "Missing parameter: game_round_id", 7},
			{ProductId.CASINO.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "partner_timestamp_utc", "Missing parameter: partner_timestamp_utc", 7},
			{ProductId.GAMES.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "partner_transaction_id", "Missing parameter: partner_transaction_id", 7},
			{ProductId.CASINO.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "user_id", "Missing parameter: user_id", 7},
			{ProductId.GAMES.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "regulated_game_id", "Missing parameter: regulated_game_id", 7},
			{ProductId.CASINO.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "partner_id", "Missing parameter: partner_id", 7},
			{ProductId.GAMES.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE,  "provider_region_id", "Missing parameter: provider_region_id", 7},
			{ProductId.CASINO.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE,  "flake_id", "Missing parameter: flake_id", 7},
			{ProductId.GAMES.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "currency_id", "Missing parameter: currency_id", 7},
			{ProductId.CASINO.getId(), TransactionType.VOID_INSTANT_GAMES_STAKE, "action_type_id", "Invalid action_type_id", 1011},
		};
	}
	
	@DataProvider(name = "invalidTransferAmountProvider")
	public Object[][] getinvalidTransferAmounts() {
		return new Object[][] {
			{TransactionType.STAKE, regulatedGameId, cmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.FREE_SPIN_STAKE, regulatedGameId, cmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.GOLDEN_CHIP_STAKE, regulatedGameId, cmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.GAMING_STAKE, regulatedGameId, cmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_CASINO, anyRegulatedGameId, anyCmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_LIVE_CASINO, anyRegulatedGameId, anyCmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.POKER_BUY_CHIPS, anyRegulatedGameId, anyCmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.POKER_TOURNAMENT_ENTRY, regulatedGameId, cmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.POKER_TOURNAMENT_REBUY, regulatedGameId, cmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()},
			{TransactionType.TRANSFER_TO_PLAYTECH_BONUS_POKER, anyRegulatedGameId, anyCmscoreGameId, "1.00", "1.00", ServiceErrors.Balance.INVALID_TRANSFER_AMOUNT.getCode()}
			};
	}
	
	@DataProvider(name = "getUserBalance")
	public Object[][] getUserBalance() {
		return new Object[][] {
			{ProductId.GAMES, UsersId.GOSERVICE1, "0", "0", "0", false},
			{ProductId.GAMES, UsersId.GOSERVICE2, "80", "56", "0", true},
			{ProductId.CASINO, UsersId.GO_SVC_TESTS01, "70", "30", "30", true},
			{ProductId.LIVE_CASINO, UsersId.GO_SVC_TESTS01, "70", "0", "0", false},
			{ProductId.LIVE_CASINO_NATIVE, UsersId.GO_SVC_TESTS01, "70", "0", "0", false},
			{ProductId.POKER, UsersId.GOSERVICE2, "80", "0", "0", false},
			{ProductId.BINGO, UsersId.GOSERVICE2, "80", "0", "0", false},
			{ProductId.CASINO, UsersId.GOSERVICE3, "100", "30", "0", true},
			{ProductId.LIVE_CASINO, UsersId.GOSERVICE3, "100", "0", "0", true},
			{ProductId.GAMES, UsersId.GOSERVICE3, "100", "0", "0", false},
			{ProductId.POKER, UsersId.GO_SVC_TESTS02, "164.72", "0", "0", true},
			{ProductId.GAMES, UsersId.NOT_EXISTING, "0", "0", "0", false},
		};
	}
	
	@DataProvider(name = "getUserBalanceNotFoundUser")
	public Object[][] getUserBalanceNotFoundUser() {
		return new Object[][] {
			{ProductId.GAMES, UsersId.NOT_EXISTING, "0", "0", "0", false},
			{ProductId.CASINO, UsersId.NOT_EXISTING, "0", "0", "0", true},
			{ProductId.LIVE_CASINO, UsersId.NOT_EXISTING, "0", "0", "0", false},
			{ProductId.POKER, UsersId.NOT_EXISTING, "0", "0", "0", false},
			{ProductId.BINGO, UsersId.NOT_EXISTING, "0", "0", "0", false},
		};
	}
	
	
}
