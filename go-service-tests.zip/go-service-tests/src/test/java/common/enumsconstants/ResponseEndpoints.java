package common.enumsconstants;

import common.Config;
import common.CustomErrorResponse;
import common.testtoken.response.CreateSlotsSessionTestResp;
import common.testtoken.response.CreateUserSessionTestResp;
import tests.balanceservice.response.AdjustBalanceResp;
import tests.balanceservice.response.GetLatestTransactionByTransactionTypeIdResp;
import tests.balanceservice.response.GetTransactionByIdResp;
import tests.balanceservice.response.GetTransactionsByGameRoundResp;
import tests.balanceservice.response.GetTransactionsByPartnerTransactionIdResp;
import tests.balanceservice.response.GetUserBalanceResp;
import tests.balanceservice.response.QueueManualVoidReturnResp;
import tests.cbsbalanceservice.response.GetCbsTransactionResp;
import tests.cbsbalanceservice.response.GetCbsTransactionsResp;
import tests.cbsbalanceservice.response.GetCbsUserBalanceResp;
import tests.common.response.ResultOKResp;
import tests.gamelaunchtokenservice.response.GenerateGameLaunchUrlResp;
import tests.gamelaunchtokenservice.response.GetGameLaunchDetailsResp;
import tests.gameplaylimitservice.response.ApplyReturnResp;

import tests.gameplaylimitservice.response.GetCurrentSummaryResp;
import tests.gameplaylimitservice.response.RevertReturnResp;
import tests.gameplaylimitservice.response.RevertSpendResp;
import tests.gameroundservice.response.GameRoundResp;
import tests.gameroundservice.response.InsertRngDetailsResp;
import tests.gamesservice.response.ChannelExistsResp;
import tests.gamesservice.response.GetApiAccountByUsernameResp;
import tests.gamesservice.response.GetChannelsByPartnerIdResp;
import tests.gamesservice.response.GetCurrencyCodeExcludedRegulatedGameIdsResp;
import tests.gamesservice.response.GetGamesPartnerByPartnerHashResp;
import tests.gamesservice.response.GetProductGamesByGameTokenResp;
import tests.gamesservice.response.GetRegulatedGameByIdResp;
import tests.gamesservice.response.GetRegulatedGameIdsByPropertyValueResp;
import tests.gamesservice.response.GetRegulatedZoneByCountryGroupIdResp;
import tests.gamesservice.response.ListOfRegulatedGamesResp;
import tests.gamingbonusadminservice.response.ActiveDepositBonusQueryCommandResp;
import tests.gamingbonusadminservice.response.ExportClaimedByVersionCommandResp;
import tests.gamingbonusadminservice.response.ExportCreditButNotClaimedCommandResp;
import tests.gamingbonusadminservice.response.GetClaimedAndCompletedBonusCountCommandResp;
import tests.gamingbonusadminservice.response.GetUsersForBonusActionsCommandResp;
import tests.gamingbonusservice.response.ActiveBonusQueryResp;
import tests.gamingbonusservice.response.ActiveRingFencedBonusesQueryResp;
import tests.gamingbonusservice.response.BonusProgressAmountQueryResp;
import tests.gamingbonusservice.response.BonusTypeQueryResp;
import tests.gamingbonusservice.response.CheckBonusEligibilityCommandResp;
import tests.gamingbonusservice.response.DepositBonusQueryResp;
import tests.gamingbonusservice.response.GameInPromotionCommandResp;
import tests.gamingbonusservice.response.GetBonusTemplatesForAccountManagerQueryResp;
import tests.gamingbonusservice.response.GetClosedBonusesQueryResp;
import tests.gamingbonusservice.response.UserBonusListQueryResp;
import tests.gbtenabledservice.response.GbtEnabledProductsPerCountryResp;
import tests.gbtenabledservice.response.IsGbtEnabledResp;
import tests.jackpotdetailsservice.response.RecordjackpotdetailsResp;
import tests.netpositionservice.response.GetNetPositionResp;
import tests.playtechbalanceservice.response.GetBonusBalancesForProductResp;
import tests.prizeservice.response.GetPrizeResp;
import tests.prizeservice.response.InsertPrizeResp;
import tests.promotionsservice.response.AdjustGoldenChipsResp;
import tests.promotionsservice.response.FreeSpinGameConfigResp;
import tests.promotionsservice.response.FreeSpinInfoResp;
import tests.promotionsservice.response.FreeSpinTransactionResp;
import tests.promotionsservice.response.GetCurrencyConversionMultipliersResp;
import tests.promotionsservice.response.GetFreeSpinTokenByTransactionIdResp;
import tests.promotionsservice.response.GetGoldenChipPromotionGameConfigurationsResp;
import tests.promotionsservice.response.GetGoldenChipUserPromotionDetailsResp;
import tests.promotionsservice.response.GetGoldenChipsByPromotionTokenResp;
import tests.promotionsservice.response.GetGoldenChipsByTransactionResp;
import tests.promotionsservice.response.GetTransactionIdsForFreeSpinResp;
import tests.promotionsservice.response.TryCloseUserPromotionResp;
import tests.realitycheckservice.response.ApplyRealityCheckDecisionResp;
import tests.realitycheckservice.response.AuditRealityCheckEventResp;
import tests.realitycheckservice.response.GetRealityCheckDetailsResp;
import tests.slotsservice.response.GameSessionBalanceResp;
import tests.slotsservice.response.GameSessionResp;
import tests.slotsservice.response.GetSlotsTransactionResp;
import tests.slotsservice.response.GetSlotsTransactionsResp;
import tests.slotsservice.response.HasOpenGameRoundsResp;
import tests.slotsservice.response.ResultResp;
import tests.swedenwinlossservice.response.UpdateBetBucketAmountResp;
import tests.tokenservice.response.CreatePublicTokenResp;
import tests.tokenservice.response.GetCurrentlyPlayingTokenResp;
import tests.tokenservice.response.InvalidateTokenByTokenResp;
import tests.tokenservice.response.TokenResp;
import tests.userservice.response.GetCoreDataResp;
import tests.userservice.response.GetItalyDataResp;
import tests.userservice.response.GetUserHasTransferredToGamingWalletResp;
import tests.userservice.response.GetUserListUsernameAndCurrencyByUserIdsResp;
import tests.userservice.response.GetUserResp;
import tests.userservice.response.GetUsersAffiliateCodeResp;
import tests.userservice.response.GetUsersDateCreatedResp;
import tests.userservice.response.GetUsersEmailAddressResp;
import tests.userservice.response.GetUsersLanguageResp;
import tests.userservice.response.GetVipLevelResp;
import tests.userservice.response.SetUserResp;

public enum ResponseEndpoints {
	
	getCurrencyConversionMultipliersSuccess(GetCurrencyConversionMultipliersResp.class, "GetCurrencyConversionMultipliers", Config.promotionsPort),
	getCurrencyConversionMultipliersError(CustomErrorResponse.class, "GetCurrencyConversionMultipliers", Config.promotionsPort),
	freeSpinGameConfigSuccess(FreeSpinGameConfigResp.class, "FreeSpinGameConfig", Config.promotionsPort),
	freeSpinGameConfigError(CustomErrorResponse.class, "FreeSpinGameConfig", Config.promotionsPort),
	tryCloseUserPromotionSuccess(TryCloseUserPromotionResp.class, "TryCloseUserPromotion", Config.promotionsPort),
	tryCloseUserPromotionError(CustomErrorResponse.class, "TryCloseUserPromotion", Config.promotionsPort),
	freeSpinTransactionSuccess(FreeSpinTransactionResp.class, "FreeSpinTransaction", Config.promotionsPort),
	freeSpinTransactionError(CustomErrorResponse.class, "FreeSpinTransaction", Config.promotionsPort),
	getFreeSpinTokenByTransactionIdSuccess(GetFreeSpinTokenByTransactionIdResp.class, "GetFreeSpinTokenByTransactionId", Config.promotionsPort),
	getFreeSpinTokenByTransactionIdError(CustomErrorResponse.class, "GetFreeSpinTokenByTransactionId", Config.promotionsPort),
	getTransactionIdsForFreeSpinSuccess(GetTransactionIdsForFreeSpinResp.class, "GetTransactionIdsForFreeSpin", Config.promotionsPort),
	getTransactionIdsForFreeSpinError(CustomErrorResponse.class, "GetTransactionIdsForFreeSpin", Config.promotionsPort),
	freeSpinInfoSuccess(FreeSpinInfoResp.class, "freespininfo", Config.promotionsPort),
	freeSpinInfoError(CustomErrorResponse.class, "freespininfo", Config.promotionsPort),
	adjustGoldenChipsSuccess(AdjustGoldenChipsResp.class, "AdjustGoldenChips", Config.promotionsPort),
	adjustGoldenChipsError(CustomErrorResponse.class, "AdjustGoldenChips", Config.promotionsPort),
	getGoldenChipsByTransactionSuccess(GetGoldenChipsByTransactionResp.class, "getgoldenchipsbytransaction", Config.promotionsPort),
	getGoldenChipsByTransactionError(CustomErrorResponse.class, "getgoldenchipsbytransaction", Config.promotionsPort),
	getGoldenChipsByPromotionTokenSuccess(GetGoldenChipsByPromotionTokenResp.class, "getgoldenchipsbypromotiontoken", Config.promotionsPort),
	getGoldenChipsByPromotionTokenError(CustomErrorResponse.class, "getgoldenchipsbypromotiontoken", Config.promotionsPort),
	getGoldenChipPromotionGameConfigurationsSuccess(GetGoldenChipPromotionGameConfigurationsResp.class, "getgoldenchippromotiongameconfigurations", Config.promotionsPort),
	getGoldenChipPromotionGameConfigurationsError(CustomErrorResponse.class, "getgoldenchippromotiongameconfigurations", Config.promotionsPort),
	getGoldenChipUserPromotionDetailsSuccess(GetGoldenChipUserPromotionDetailsResp.class, "GetGoldenChipUserPromotionDetails", Config.promotionsPort),
	getGoldenChipUserPromotionDetailsError(CustomErrorResponse.class, "GetGoldenChipUserPromotionDetails", Config.promotionsPort),
	recordJackpotDetailsSuccess(RecordjackpotdetailsResp.class, "recordjackpotdetails", Config.jackpotDetailsPort),
	recordJackpotDetailsError(CustomErrorResponse.class, "recordjackpotdetails", Config.jackpotDetailsPort),
	getVipLevelSuccess(GetVipLevelResp.class, "getVipLevel", Config.userPort),
	getVipLevelError(CustomErrorResponse.class, "getVipLevel", Config.userPort),
	getUserListUsernameAndCurrencyByUserIdsSuccess(GetUserListUsernameAndCurrencyByUserIdsResp.class, "getUserListUsernameAndCurrencyByUserIds", Config.userPort),
	getUserListUsernameAndCurrencyByUserIdsError(CustomErrorResponse.class, "getUserListUsernameAndCurrencyByUserIds", Config.userPort),
	setUserHasLaunchedGameSuccess(SetUserResp.class, "setUserHasLaunchedGame", Config.userPort),
	setUserHasLaunchedGameError(CustomErrorResponse.class, "setUserHasLaunchedGame", Config.userPort),
	setUserClaimedFreeSpinsSuccess(SetUserResp.class, "setUserClaimedFreeSpins", Config.userPort),
	setUserClaimedFreeSpinsError(CustomErrorResponse.class, "setUserClaimedFreeSpins", Config.userPort),
	getCoreDataByUserNameError(CustomErrorResponse.class, "getCoreDataByUsername", Config.userPort),
	getCoreDataByUserNameSuccess(GetCoreDataResp.class, "getCoreDataByUsername", Config.userPort),
	getUsersEmailAddressSuccess(GetUsersEmailAddressResp.class, "getUsersEmailAddress", Config.userPort),
	getUsersEmailAddressError(CustomErrorResponse.class, "getUsersEmailAddress", Config.userPort),
	getUsersAffiliateCodeSuccess(GetUsersAffiliateCodeResp.class, "getUsersAffiliateCode", Config.userPort),
	getUsersAffiliateCodeError(CustomErrorResponse.class, "getUsersAffiliateCode", Config.userPort),
	getCoreDataByGamingIdError(CustomErrorResponse.class, "getCoreDataByGamingId", Config.userPort),
	getCoreDataByGamingIdSuccess(GetCoreDataResp.class, "getCoreDataByGamingId", Config.userPort),
	getCoreDataByUserIdError(CustomErrorResponse.class, "getCoreDataByUserId", Config.userPort),
	getCoreDataByUserIdSuccess(GetCoreDataResp.class, "getCoreDataByUserId", Config.userPort),
	getUsersDateCreatedSuccess(GetUsersDateCreatedResp.class, "getUsersDateCreated", Config.userPort),
	getUsersDateCreatedError(CustomErrorResponse.class, "getUsersDateCreated", Config.userPort),
	getUserByIdSuccess(GetUserResp.class, "getUserById", Config.userPort),
	getUserByIdError(CustomErrorResponse.class, "getUserById", Config.userPort),
	getUserByGamingIdSuccess(GetUserResp.class, "getUserByGamingId", Config.userPort),
	getUserByGamingIdError(CustomErrorResponse.class, "getUserByGamingId", Config.userPort),
	getUserByUsernameSuccess(GetUserResp.class, "getUserByUsername", Config.userPort),
	getUserByUsernameError(CustomErrorResponse.class, "getUserByUsername", Config.userPort),
	getUserHasTransferredToGamingWalletSuccess(GetUserHasTransferredToGamingWalletResp.class, "getUserHasTransferredToGamingWallet", Config.userPort),
	getUserHasTransferredToGamingWalletError(CustomErrorResponse.class, "getUserHasTransferredToGamingWallet", Config.userPort),
	getUsersLanguageSuccess(GetUsersLanguageResp.class, "getUsersLanguage", Config.userPort),
	getUsersLanguageError(CustomErrorResponse.class, "getUsersLanguage", Config.userPort),
	getItalyDataSuccess(GetItalyDataResp.class, "getItalyData", Config.userPort),
	getItalyDataError(CustomErrorResponse.class, "getItalyData", Config.userPort),
	getRegulatedGameIdsByPropertyValueSuccess(GetRegulatedGameIdsByPropertyValueResp.class, "GetRegulatedGameIdsByPropertyValue", Config.gamesPort),
	getRegulatedGameIdsByPropertyValueError(CustomErrorResponse.class, "GetRegulatedGameIdsByPropertyValue", Config.gamesPort),
	getRegulatedZoneByCountryGroupIdSuccess(GetRegulatedZoneByCountryGroupIdResp.class, "GetRegulatedZoneByCountryGroupId", Config.gamesPort),
	getRegulatedZoneByCountryGroupIdError(CustomErrorResponse.class, "GetRegulatedZoneByCountryGroupId", Config.gamesPort),
	getApiAccountByUsernameSuccess(GetApiAccountByUsernameResp.class, "GetApiAccountByUsername", Config.gamesPort),
	getApiAccountByUsernameError(CustomErrorResponse.class, "GetApiAccountByUsername", Config.gamesPort),
	channelExistsSuccess(ChannelExistsResp.class, "ChannelExists", Config.gamesPort),
	channelExistsError(CustomErrorResponse.class, "ChannelExists", Config.gamesPort),
	getChannelsByPartnerIdSuccess(GetChannelsByPartnerIdResp.class, "GetChannelsByPartnerId", Config.gamesPort),
	getChannelsByPartnerIdError(CustomErrorResponse.class, "GetChannelsByPartnerId", Config.gamesPort),
	insertRngDetails(InsertRngDetailsResp.class, "InsertRngDetails", Config.gameRoundPort),
	getGameRoundById(GameRoundResp.class, "GetGameRoundById", Config.gameRoundPort),
	getGameRoundByPartnerGameRoundId(GameRoundResp.class, "GetGameRoundByPartnerGameRoundId", Config.gameRoundPort),
	getGameRound(GameRoundResp.class, "GetGameRound", Config.gameRoundPort),
	createGameRound(GameRoundResp.class, "CreateGameRound", Config.gameRoundPort),
	closeGameRoundByBet365GameRoundId(GameRoundResp.class, "CloseGameRoundByBet365GameRoundId", Config.gameRoundPort),
	getGamesPartnerByPartnerHashSuccess(GetGamesPartnerByPartnerHashResp.class, "GetGamesPartnerByPartnerHash", Config.gamesPort),
	getGamesPartnerByPartnerHashError(CustomErrorResponse.class, "GetGamesPartnerByPartnerHash", Config.gamesPort),
	getRegulatedGameByIdSuccess(GetRegulatedGameByIdResp.class, "GetRegulatedGameById", Config.gamesPort),
	getRegulatedGameByIdError(CustomErrorResponse.class, "GetRegulatedGameById", Config.gamesPort),
	getRegulatedGamesByProviderGameReferenceSuccess(ListOfRegulatedGamesResp.class, "GetRegulatedGamesByProviderGameReference", Config.gamesPort),
	getRegulatedGamesByProviderGameReferenceError(CustomErrorResponse.class, "GetRegulatedGamesByProviderGameReference", Config.gamesPort),
	getLatestTransactionByTransactionTypeId(GetLatestTransactionByTransactionTypeIdResp.class, "GetLatestTransactionByTransactionTypeId", Config.balancePort),
	getRegulatedGamesByPrivatePartnerGameIdSuccess(ListOfRegulatedGamesResp.class, "GetRegulatedGamesByPrivatePartnerGameId", Config.gamesPort),
	getRegulatedGamesByPrivatePartnerGameIdError(CustomErrorResponse.class, "GetRegulatedGamesByPrivatePartnerGameId", Config.gamesPort),
	getCurrencyCodeExcludedRegulatedGameIdsSuccess(GetCurrencyCodeExcludedRegulatedGameIdsResp.class, "GetCurrencyCodeExcludedRegulatedGameIds", Config.gamesPort),
	getCurrencyCodeExcludedRegulatedGameIdsError(CustomErrorResponse.class, "GetCurrencyCodeExcludedRegulatedGameIds", Config.gamesPort),
	getProductGamesByGameTokenSuccess(GetProductGamesByGameTokenResp.class, "GetProductGamesByGameToken", Config.gamesPort),
	getProductGamesByGameTokenError(CustomErrorResponse.class, "GetProductGamesByGameToken", Config.gamesPort),
	getTransactionById(GetTransactionByIdResp.class, "GetTransactionById", Config.balancePort),
	getTransactionByIdError(CustomErrorResponse.class, "GetTransactionById", Config.balancePort),
	queueManualVoidReturn(QueueManualVoidReturnResp.class, "QueueManualVoidReturn", Config.balancePort),
	queueManualVoidReturnError(CustomErrorResponse.class, "QueueManualVoidReturn", Config.balancePort),
	getUserBalanceSuccess(GetUserBalanceResp.class, "GetUserBalance", Config.balancePort),
	getUserBalanceError(CustomErrorResponse.class, "GetUserBalance", Config.balancePort),
	adjustBalance(AdjustBalanceResp.class, "adjustBalance", Config.balancePort),
	adjustBalanceError(CustomErrorResponse.class, "adjustBalance", Config.balancePort),
	getTransactionsByGameRoundSuccess(GetTransactionsByGameRoundResp.class, "getTransactionsByGameRound", Config.balancePort),
	getTransactionsByGameRoundError(CustomErrorResponse.class, "getTransactionsByGameRound", Config.balancePort),
	getTransactionsByPartnerTransactionID(GetTransactionsByPartnerTransactionIdResp.class, "GetTransactionsByPartnerTransactionID", Config.balancePort),
	createPublicTokenSuccess(CreatePublicTokenResp.class, "CreatePublicToken", Config.tokenPort),
	createPublicTokenError(CustomErrorResponse.class, "CreatePublicToken", Config.tokenPort),
	createSlotsSessionTokenSuccess(CreateSlotsSessionTestResp.class, "createslotstoken-test", Config.sessionTestPort),
	createPrivateTokenSuccess(TokenResp.class, "CreatePrivateToken", Config.tokenPort),
	createPrivateTokenError(CustomErrorResponse.class, "CreatePrivateToken", Config.tokenPort),
	setCurrentlyPlayingTokenSuccess(ResultOKResp.class, "SetCurrentlyPlayingToken", Config.tokenPort),
	setCurrentlyPlayingTokenError(CustomErrorResponse.class, "SetCurrentlyPlayingToken", Config.tokenPort),
	getCurrentlyPlayingTokenSuccess(GetCurrentlyPlayingTokenResp.class, "GetCurrentlyPlayingToken", Config.tokenPort),
	getCurrentlyPlayingTokenError(CustomErrorResponse.class, "GetCurrentlyPlayingToken", Config.tokenPort),
	invalidateTokenByTokenSuccess(InvalidateTokenByTokenResp.class, "InvalidateTokenByToken", Config.tokenPort),
	invalidateTokenByTokenError(CustomErrorResponse.class, "InvalidateTokenByToken", Config.tokenPort),
	getTokenByTokenSuccess(TokenResp.class, "GetTokenByToken", Config.tokenPort),
	getTokenByTokenError(CustomErrorResponse.class, "GetTokenByToken", Config.tokenPort),
	insertPrizeSuccess(InsertPrizeResp.class, "InsertPrize", Config.prizePort),
	postIsEnabledSuccess(IsGbtEnabledResp.class, "isGbtEnabled",  ""),
	//GBT Enabled Service
	postGbtEnabledProductsPerCountrySuccess(GbtEnabledProductsPerCountryResp.class, "GbtEnabledProductsPerCountry", ""),
	gbtEnabledProductsPerCountryQueryError(CustomErrorResponse.class, "GbtEnabledProductsPerCountry", ""),
	gbtEnabledRequestError(CustomErrorResponse.class, "isGbtEnabled", ""),
	insertPrizeError(CustomErrorResponse.class, "InsertPrize", Config.prizePort),
	getPrizeSuccess(GetPrizeResp.class, "GetPrize", Config.prizePort),
	getPrizeError(CustomErrorResponse.class, "GetPrize", Config.prizePort),
	updateBetBucketAmountSuccess(UpdateBetBucketAmountResp.class, "UpdateBetBucketAmount", Config.swedenWinLossPort),
	updateBetBucketAmountError(CustomErrorResponse.class, "UpdateBetBucketAmount", Config.swedenWinLossPort),
	auditRealityCheckEventSuccess(AuditRealityCheckEventResp.class, "AuditRealityCheckEvent", Config.realityCheckPort),
	auditRealityCheckEventError(CustomErrorResponse.class, "AuditRealityCheckEvent", Config.realityCheckPort),
	getRealityCheckDetailsSuccess(GetRealityCheckDetailsResp.class, "GetRealityCheckDetails", Config.realityCheckPort),
	getRealityCheckDetailsError(CustomErrorResponse.class, "GetRealityCheckDetails", Config.realityCheckPort),
	applyRealityCheckDecisionSuccess(ApplyRealityCheckDecisionResp.class, "ApplyRealityCheckDecision", Config.realityCheckPort),
	applyRealityCheckDecisionError(CustomErrorResponse.class, "ApplyRealityCheckDecision", Config.realityCheckPort),
	createUserSessionTestSuccess(CreateUserSessionTestResp.class, "CreateUserSession-Test", Config.sessionTestPort),
	startSessionSuccess(ResultOKResp.class, "StartSession", Config.netpositionPort),
	startSessionError(CustomErrorResponse.class, "StartSession", Config.netpositionPort),
	getNetPositionSuccess(GetNetPositionResp.class, "GetNetPosition", Config.netpositionPort),
	getNetPositionError(CustomErrorResponse.class, "GetNetPosition", Config.netpositionPort),
	handleTransactionsSuccess(ResultOKResp.class, "HandleTransactions", Config.netpositionPort),
	handleTransactionsError(CustomErrorResponse.class, "HandleTransactions", Config.netpositionPort),
	recordPokerGameSessionSuccess(ResultOKResp.class, "RecordPokerGameSession", Config.pokerTournamentsPort),
	recordPokerGameSessionError(CustomErrorResponse.class, "RecordPokerGameSession", Config.pokerTournamentsPort),
	recordPokerTournamentDetailsSuccess(ResultOKResp.class, "RecordPokerTournamentDetails", Config.pokerTournamentsPort),
	recordPokerTournamentDetailsError(CustomErrorResponse.class, "RecordPokerTournamentDetails", Config.pokerTournamentsPort),
	getCbsUserBalanceSuccess(GetCbsUserBalanceResp.class, "GetUserBalance", Config.cbsBalancePort),
	getCbsUserBalanceError(CustomErrorResponse.class, "GetUserBalance", Config.cbsBalancePort),
	cbsAdjustBalanceSuccess(GetCbsTransactionResp.class, "AdjustBalance", Config.cbsBalancePort),
	cbsAdjustBalanceError(CustomErrorResponse.class, "AdjustBalance", Config.cbsBalancePort),
	getTransactionsByGameroundSuccess(GetCbsTransactionsResp.class, "GetTransactionsByGameround", Config.cbsBalancePort),
	getTransactionsByGameroundError(ResultOKResp.class, "GetTransactionsByGameround", Config.cbsBalancePort),
	getCbsTransactionByIdSuccess(GetCbsTransactionResp.class, "GetTransactionById", Config.cbsBalancePort),
	getCbsTransactionByIdError(CustomErrorResponse.class, "GetTransactionById", Config.cbsBalancePort),
	getCbsTransactionByGameRoundError(CustomErrorResponse.class, "GetTransactionsByGameround", Config.cbsBalancePort),
	getTransactionsByPartnerTransactionIDSuccess(GetCbsTransactionsResp.class, "GetTransactionsByPartnerTransactionID", Config.cbsBalancePort),
	getTransactionsByPartnerTransactionIDError(CustomErrorResponse.class, "GetTransactionsByPartnerTransactionID", Config.cbsBalancePort),
	getLatestTransactionByTransactionTypeIdSuccess(GetCbsTransactionResp.class, "GetLatestTransactionByTransactionTypeId", Config.cbsBalancePort),
	getLatestTransactionByTransactionTypeIdError(CustomErrorResponse.class, "GetLatestTransactionByTransactionTypeId", Config.cbsBalancePort),
	gameRoundStakeCommandSuccess(ResultOKResp.class, "GameRoundStakeCommand", ""),
	gameRoundStakeCommandError(CustomErrorResponse.class, "GameRoundStakeCommand", ""),
	gameRoundEndCommandSuccess(ResultOKResp.class, "GameRoundEndCommand", ""),
	gameRoundEndCommandError(CustomErrorResponse.class, "GameRoundEndCommand", ""),
	addCreditedUserSuccess(ResultOKResp.class, "AddCreditedUser", ""),
	addCreditedUserError(CustomErrorResponse.class, "AddCreditedUser", ""),
	bonusTypeQuerySuccess(BonusTypeQueryResp.class, "BonusTypeQuery", ""),
	bonusTypeQueryError(CustomErrorResponse.class, "BonusTypeQuery", ""),
	getTermsAndConditionsQuerySuccess(ResultOKResp.class, "GetTermsAndConditionsQuery", ""),
	getTermsAndConditionsQueryError(CustomErrorResponse.class, "GetTermsAndConditionsQuery", ""),
	bonusNotInterestedCommandSuccess(ResultOKResp.class, "BonusNotInterestedCommand", ""),
	bonusNotInterestedCommandError(CustomErrorResponse.class, "BonusNotInterestedCommand", ""),
	bonusClaimCommandSuccess(ResultOKResp.class, "BonusClaimCommand", ""),
	bonusClaimCommandError(CustomErrorResponse.class, "BonusClaimCommand", ""),
	acknowledgeCashBonusCommandSuccess(ResultOKResp.class, "AcknowledgeCashBonusCommand", ""),
	acknowledgeCashBonusCommandError(CustomErrorResponse.class, "AcknowledgeCashBonusCommand", ""),
	
	userBonusListQuerySuccess(UserBonusListQueryResp.class, "UserBonusListQuery", ""),
	userBonusListQueryError(CustomErrorResponse.class, "UserBonusListQuery", ""),
	getClosedBonusesQuerySuccess(GetClosedBonusesQueryResp.class, "GetClosedBonusesQuery", ""),
	getClosedBonusesQueryError(CustomErrorResponse.class, "GetClosedBonusesQuery", ""),
	activeBonusQuerySuccess(ActiveBonusQueryResp.class, "ActiveBonusQuery", ""),
	activeBonusQueryError(CustomErrorResponse.class, "ActiveBonusQuery", ""),
	
	getBonusTemplatesForAccountManagerQuerySuccess(GetBonusTemplatesForAccountManagerQueryResp.class, "GetBonusTemplatesForAccountManagerQuery", ""),
	getBonusTemplatesForAccountManagerQueryError(CustomErrorResponse.class, "GetBonusTemplatesForAccountManagerQuery", ""),
	depositBonusQuerySuccess(DepositBonusQueryResp.class, "DepositBonusQuery", ""),
	depositBonusQueryError(CustomErrorResponse.class, "DepositBonusQuery", ""),
	checkBonusEligibilityCommandSuccess(CheckBonusEligibilityCommandResp.class, "CheckBonusEligibilityCommand", ""),
	checkBonusEligibilityCommandError(CustomErrorResponse.class, "CheckBonusEligibilityCommand", ""),
	gameInPromotionCommandSuccess(GameInPromotionCommandResp.class, "GameInPromotionCommand", ""),
	gameInPromotionCommandError(CustomErrorResponse.class, "GameInPromotionCommand", ""),
	bonusProgressAmountQuerySuccess(BonusProgressAmountQueryResp.class, "BonusProgressAmountQuery", ""),
	bonusProgressAmountQueryError(CustomErrorResponse.class, "BonusProgressAmountQuery", ""),
	bonusCancelByUserCommandSuccess(ResultOKResp.class, "BonusCancelByUserCommand", ""),
	bonusCancelByUserCommandError(CustomErrorResponse.class, "BonusCancelByUserCommand", ""),
	bonusCreditAndClaimCommandSuccess(ResultOKResp.class, "BonusCreditAndClaimCommand", ""),
	bonusCreditAndClaimCommandError(CustomErrorResponse.class, "BonusCreditAndClaimCommand", ""),
	activeRingFencedBonusesQuerySuccess(ActiveRingFencedBonusesQueryResp.class, "ActiveRingFencedBonusesQuery", ""),
	activeRingFencedBonusesQueryError(CustomErrorResponse.class, "ActiveRingFencedBonusesQuery", ""),
	manualBonusCreditAndClaimCommandSuccess(ResultOKResp.class, "ManualBonusCreditAndClaimcommand", ""),
	manualBonusCreditAndClaimCommandError(CustomErrorResponse.class, "ManualBonusCreditAndClaimcommand", ""),
	//Gaming Bonus Admin Service
	getUsersForBonusActionsCommandSuccess(GetUsersForBonusActionsCommandResp.class, "getUsersForBonusActionsCommand", ""),
	getUsersForBonusActionsCommandError(CustomErrorResponse.class, "getUsersForBonusActionsCommand", ""),
	addCreditedUsersCommandSuccess(ResultOKResp.class, "addcrediteduserscommand", ""),
	addCreditedUsersCommandError(CustomErrorResponse.class, "addcrediteduserscommand", ""),
	specificBonusRedeemByAdminCommandSuccess(ResultOKResp.class, "specificbonusredeembyadmincommand", ""),
	specificBonusRedeemByAdminCommandError(CustomErrorResponse.class, "specificbonusredeembyadmincommand", ""),
	specificBonusCancelByAdminCommandSuccess(ResultOKResp.class, "specificbonuscancelbyadmincommand", ""),
	specificBonusCancelByAdminCommandError(CustomErrorResponse.class, "specificbonuscancelbyadmincommand", ""),
	activeDepositBonusQueryCommandSuccess(ActiveDepositBonusQueryCommandResp.class, "activedepositbonusquerycommand", ""),
	activeDepositBonusQueryCommandError(CustomErrorResponse.class, "activedepositbonusquerycommand", ""),
	getClaimedAndCompletedBonusCountCommandSuccess(GetClaimedAndCompletedBonusCountCommandResp.class, "getclaimedandcompletedbonuscountcommand", ""),
	getClaimedAndCompletedBonusCountCommandError(CustomErrorResponse.class, "getclaimedandcompletedbonuscountcommand", ""),
	gameWeightingTemplateUpdateCommandSuccess(ResultOKResp.class, "gameweightingtemplateupdatecommand", ""),
	gameWeightingTemplateUpdateCommandError(CustomErrorResponse.class, "gameweightingtemplateupdatecommand", ""),
	exportClaimedByVersionCommandSuccess(ExportClaimedByVersionCommandResp.class, "exportclaimedbyversioncommand", ""),
	exportClaimedByVersionCommandError(CustomErrorResponse.class, "exportclaimedbyversioncommand", ""),
	exportCreditButNotClaimedCommandSuccess(ExportCreditButNotClaimedCommandResp.class, "exportcreditbutnotclaimedcommand", ""),
	exportCreditButNotClaimedCommandError(CustomErrorResponse.class, "exportcreditbutnotclaimedcommand", ""),
	insertGamePositionsCommandSuccess(ResultOKResp.class, "insertgamepositionscommand", ""),
	insertGamePositionsCommandError(CustomErrorResponse.class, "insertgamepositionscommand", ""),
	bonusTemplateUpdateCommandSuccess(ResultOKResp.class, "bonusTemplateUpdateCommand", ""),
	bonusTemplateUpdateCommandError(CustomErrorResponse.class, "bonusTemplateUpdateCommand", ""),
	bonusClaimByAdminCommandSuccess(ResultOKResp.class, "bonusClaimByAdminCommand", ""),
	bonusClaimByAdminCommandError(CustomErrorResponse.class, "bonusClaimByAdminCommand", ""),
	// Slots service
	getActiveGameSessionSuccess(GameSessionResp.class, "GetActiveGameSession", Config.slotsPort),
	getActiveGameSessionError(CustomErrorResponse.class, "GetActiveGameSession", Config.slotsPort),
	getGameSessionSuccess(GameSessionResp.class, "GetGameSession", Config.slotsPort),
	getGameSessionError(CustomErrorResponse.class, "GetGameSession", Config.slotsPort),
	getGameSessionBalanceSuccess(GameSessionBalanceResp.class, "GetGameSessionBalance", Config.slotsPort),
	getGameSessionBalanceError(CustomErrorResponse.class, "GetGameSessionBalance", Config.slotsPort),
	getSlotsTransactionsByPartnerTransactionIDSuccess(GetSlotsTransactionsResp.class, "GetTransactionsByPartnerTransactionID", Config.slotsPort),
	getSlotsTransactionsByPartnerTransactionIDError(CustomErrorResponse.class, "GetTransactionsByPartnerTransactionID", Config.slotsPort),
	getSlotsTransactionsByGameRoundSuccess(GetSlotsTransactionsResp.class, "GetTransactionsByGameround", Config.slotsPort),
	getSlotsTransactionsByGameRoundError(CustomErrorResponse.class, "GetTransactionsByGameround", Config.slotsPort),
	getSlotsTransactionByIdSuccess(GetSlotsTransactionResp.class, "GetTransactionByID", Config.slotsPort),
	getSlotsTransactionByIdError(CustomErrorResponse.class, "GetTransactionByID", Config.slotsPort),
	getLatestSlotsTransactionByTransactionTypeIdSuccess(GetSlotsTransactionResp.class, "GetLatestTransactionByTransactionTypeId", Config.slotsPort),
	getLatestSlotsTransactionByTransactionTypeIdError(CustomErrorResponse.class, "GetLatestTransactionByTransactionTypeId", Config.slotsPort),
	slotsAdjustBalanceSuccess(GetSlotsTransactionResp.class, "AdjustBalance", Config.slotsPort),
	slotsAdjustBalanceError(CustomErrorResponse.class, "AdjustBalance", Config.slotsPort),
	linkGameSessionToGameRoundSuccess(ResultResp.class, "LinkGameSessionToGameRound", Config.slotsPort),
	linkGameSessionToGameRoundError(CustomErrorResponse.class, "LinkGameSessionToGameRound", Config.slotsPort),
	linkGameSessionToTokenSuccess(ResultResp.class, "LinkGameSessionToToken", Config.slotsPort),
	linkGameSessionToTokenError(CustomErrorResponse.class, "LinkGameSessionToToken", Config.slotsPort),
	slotsQueueManualVoidReturnSuccess(ResultResp.class, "QueueManualVoidReturn", Config.slotsPort),
	slotsQueueManualVoidReturnError(CustomErrorResponse.class, "QueueManualVoidReturn", Config.slotsPort),
	markClosedGameRoundSuccess(ResultResp.class, "MarkClosedGameRound", Config.slotsPort),
	markClosedGameRoundError(CustomErrorResponse.class, "MarkClosedGameRound", Config.slotsPort),
	hasOpenGameRoundsSuccess(HasOpenGameRoundsResp.class, "HasOpenGameRounds", Config.slotsPort),
	hasOpenGameRoundsError(CustomErrorResponse.class, "HasOpenGameRounds", Config.slotsPort),
	//GenerateGameLaunchUrl;
	generateGameLaunchUrlSuccess(GenerateGameLaunchUrlResp.class, "GenerateGameLaunchUrl", ""),
	generateGameLaunchUrlError(CustomErrorResponse.class, "GenerateGameLaunchUrl", ""),
	getGameLaunchDetailsSuccess(GetGameLaunchDetailsResp.class, "GetGameLaunchDetails", ""),
	getGameLaunchDetailsError(CustomErrorResponse.class, "GetGameLaunchDetails", ""),
	//Gameplay Limits Service
	getCurrentSummaryError(CustomErrorResponse.class, "GetCurrentSummary", Config.gameplayLimitsPort),
	getCurrentSummarySuccess(GetCurrentSummaryResp.class, "GetCurrentSummary", Config.gameplayLimitsPort),
    RevertSpendSuccess(RevertSpendResp.class, "revertspend", Config.gameplayLimitsPort),
    RevertSpendError(CustomErrorResponse.class, "revertspend", Config.gameplayLimitsPort),
	applyReturnSuccess(ApplyReturnResp.class, "ApplyReturn", Config.gameplayLimitsPort),
	applyReturnError(CustomErrorResponse.class, "ApplyReturn", Config.gameplayLimitsPort),
	revertReturnSuccess(RevertReturnResp.class, "RevertReturn", Config.gameplayLimitsPort),
	revertReturnError(CustomErrorResponse.class, "RevertReturn", Config.gameplayLimitsPort),
	//Playtech Balance Service
	getBonusBalancesForProductSuccess(GetBonusBalancesForProductResp.class, "GetBonusBalancesForProduct", ""),
	getBonusBalancesForProductError(CustomErrorResponse.class, "GetBonusBalancesForProduct", "");
	
	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;
	private String port;
	
	<T> ResponseEndpoints(Class<T> cls, String endpoint, String port) {
		this.respClass = cls;
		this.endPoint = endpoint;
		this.port = port;
	}
	
	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

	public String getPort() {
		return port;
	}

}
