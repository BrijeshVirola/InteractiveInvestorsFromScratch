package common.enumsconstants;

public interface Errors {
	
	int getCode();
	String getMessage();

}
