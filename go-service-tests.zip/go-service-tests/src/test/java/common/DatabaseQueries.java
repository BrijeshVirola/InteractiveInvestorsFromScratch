package common;
import java.util.HashMap;
import java.util.Map;

import com.bet365.dbIntegration.SqlQueries;

import tests.pokertournamentsservice.request.PokerGameSessionDB;
import tests.pokertournamentsservice.request.PokerTournamentsDB;

public class DatabaseQueries {

	/**
	 * SQL to return userID
	 * @param userName
	 * @param print
	 * @return
	 */
	public static Integer getUserIdFromUserTable(String userName) {
		String query = "SELECT TOP 1 USERID "
				+ "FROM [User] WITH (NOLOCK) "
				+ "WHERE UserName = '%s'";
		
		String formattedQuery = String.format(query, userName);
		
		String output = SqlQueries.executeAQuery(formattedQuery).trim();
		return Integer.parseInt(output);
	}
	
	/**
	 * SQL to verify if BonusTemplateVersionId exists
	 * @param bonusTemplateVersionId
	 * @return
	 */
	public static Boolean verifyIfExistsBonusTemplateVersionId(Integer bonusTemplateVersionId) {
		
		String query = "SELECT CASE WHEN EXISTS (SELECT BonusTemplateVersionId "
				+ "FROM GamingBonusAPI.dbo.BonusTemplateVersion WITH (NOLOCK) "
				+ "WHERE bonusTemplateVersionId = '%s') "
				+ "THEN 'TRUE' "
				+ "ELSE 'FALSE' END";
		
		String formattedQuery = String.format(query, bonusTemplateVersionId);
		
		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", "GamingBonusAPI", formattedQuery).trim();
		return new Boolean(output);
	}
	
	/**
	 * Get GameWeight from GameWeightTemplateMapping
	 * <p>Server: MN2GAMSQL0001U0, Database: GamingBonusAPI</p>
	 * @param gameWeightTemplateId
	 * @param regulatedGameId
	 * @return
	 */
	public static int getGameWeighFromGameWeightTemplateMapping(int gameWeightTemplateId, int regulatedGameId) {
		
		String query = "SELECT GameWeight"
				+ " FROM [GamingBonusAPI].[dbo].[GameWeightTemplateMapping] WITH(NOLOCK)"
				+ " WHERE GameWeightTemplateId = '%s'"
				+ " AND RegulatedGameId = '%s';";
		
		String formattedQuery = String.format(query, gameWeightTemplateId, regulatedGameId);
		
		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", "GamingBonusAPI", formattedQuery).trim();
		return Integer.parseInt(output);
	}
	
	/**
	 * SQL to return last UserBonusId
	 * @param userId
	 * @return
	 */
	public static Integer getLastUserBonusIdFromUserBonus(Integer userId) {
		
		String query = "SELECT TOP 1 UserBonusId "
				+ "FROM GamingBonusAPI.dbo.UserBonus WITH (NOLOCK) "
				+ "WHERE UserId = '%s' ORDER BY UserBonusId desc;";
		
		String formattedQuery = String.format(query, userId);
		
		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", "GamingBonusAPI", formattedQuery).trim();
		return Integer.parseInt(output);
	}

	public static PokerTournamentsDB getPokerTournamentDetails(Long flakeId) {
		
		String query = "SELECT * FROM [gam_pokertournaments].[dbo].[PokerTournaments] WITH (NOLOCK) WHERE TransactionFlakeId ='%s'";
		
		String formattedQuery = String.format(query, flakeId);
		
		String output = SqlQueries.executeAQuery("UATGAMINGSQL", 
									"gam_pokertournaments", 
									formattedQuery);
		
		String[] outputData = output.trim().split("\t");
		
		PokerTournamentsDB data = new PokerTournamentsDB();
		
		data.setTournamentId(outputData[1]);
		data.setFeeAmount(Double.parseDouble(outputData[2]));
		data.setDisplayAmount(Double.parseDouble(outputData[4]));
		data.setTransactionFlakeId(Long.parseLong(outputData[0]));
		data.setFeeCurrencyId(Integer.parseInt(outputData[3]));
		data.setDisplayCurrencyId(Integer.parseInt(outputData[5]));
		return data;
	}
	
	public static PokerGameSessionDB getPokerGameSession(Long gameRoundSno) {
		
		String query = "SELECT * FROM [gam_pokertournaments].[dbo].[PokerGameSession] WITH (NOLOCK) WHERE GameRoundSNO ='%s'";
		
		String formattedQuery = String.format(query, gameRoundSno);
		
		String output = SqlQueries.executeAQuery("UATGAMINGSQL", 
									"gam_pokertournaments", 
									formattedQuery);
		
		String[] outputData = output.trim().split("\t");
		
		PokerGameSessionDB data = new PokerGameSessionDB();
		
		data.setCasino(outputData[4]);
		data.setClientPlatform(outputData[2]);
		data.setClientType(outputData[1]);
		data.setGameRoundSno(Long.parseLong(outputData[0]));
		data.setGameType(outputData[3]);
		data.setRakeAmount(Double.parseDouble(outputData[5]));
		return data;
	}
	
	/**
	 * Get details of BonusTemplateGamePosition
	 * @param bonusTemplateId
	 * @param gameTokenId
	 * @return
	 */
	public static Map<String, Integer> getBonusTemplateGamePosition(int bonusTemplateId, int gameTokenId) {
		
		String query = "SELECT * FROM [GamingBonusAPI].[dbo].[BonusTemplateGamePositions] WITH(NOLOCK)"
				+ " WHERE BonusTemplateId = '%s'"
				+ " AND GameTokenId = '%s';";
		
		String formattedQuery = String.format(query, bonusTemplateId, gameTokenId);
		
		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", "GamingBonusAPI", formattedQuery);
		output = output.trim();
		
		String[] outputData = output.split("\t");
		
		Map<String, Integer> data = new HashMap<>();
		
		data.put("BonusTemplateGamePositionsId", Integer.parseInt(outputData[0]));
		data.put("BonusTemplateId", Integer.parseInt(outputData[1]));
		data.put("RegulatedZoneId", Integer.parseInt(outputData[2]));
		data.put("Position", Integer.parseInt(outputData[3]));
		data.put("GameTokenId", Integer.parseInt(outputData[4]));
		data.put("ProductId", Integer.parseInt(outputData[5]));
		return data;
	}
	
	/**
	 * Get last bonus template game positions id.
	 * @return
	 */
	public static int getLastBonusTemplateGamePositionsId() {
		
		String query = "SELECT TOP 1 BonusTemplateGamePositionsId"
				+ " FROM [GamingBonusAPI].[dbo].[BonusTemplateGamePositions] WITH(NOLOCK)"
				+ " ORDER BY BonusTemplateGamePositionsId desc;";
		
		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", "GamingBonusAPI", query).trim();

		return Integer.parseInt(output);
	}
	
	/**
	 * SQL to return SakuraTokenSNO
	 * @param gameSessionId
	 * @return SakuraTokenSNO
	 */
	public static int getSakuraTokenSNOByGameSessionId(String gameSessionId) {
		String query = "SELECT TOP 1 SakuraTokenSNO "
				+ "FROM SakuraSlotsSessionTokens WITH (NOLOCK) " 
				+ "WHERE GameSessionID = '%s'";

		String formattedQuery = String.format(query, gameSessionId);

		String output = SqlQueries.executeAQuery("MN2GAMSQL0001U0", "Bet365_Games_Logical_V3", formattedQuery).trim();
		return Integer.parseInt(output);
	}
}
