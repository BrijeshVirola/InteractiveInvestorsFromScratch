package common.RetryTestFailures;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;

/**
 * In this class are implemented the methods that clean up duplicate failures after using the re-run logic
 * @author petarpetrov
 *
 */
public class CleanUpDuplicate {


	/** removes the duplicate test runs
	 * @param testContext
	 * @return
	 */
	public static int cleanUpDuplicateFailures(ITestContext testContext) {
		int removedFailures = 0;

		final Set<ITestResult> failedTests = testContext.getFailedTests().getAllResults();

		if (!failedTests.isEmpty()) {

			// collect all id's from passed test
			final Set<String> passedTestIds = new HashSet<>();
			final Set<ITestResult> passedTests = testContext.getPassedTests().getAllResults();

			for (ITestResult result : passedTests) {
				final String testId = CleanUpDuplicate.getId(result);
				passedTestIds.add(testId);
			}


			// check which failed test results should be removed
			final List<String> resultsToBeRemoved = new ArrayList<>();
			final Set<String> failedTestIds = new HashSet<>();

			for (ITestResult result : failedTests) {
				final String testId = CleanUpDuplicate.getId(result);
				// check if this is the first fail of the test or the test is passed before we mark the result for deletion		
				if (failedTestIds.contains(testId) || passedTestIds.contains(testId)) {
					resultsToBeRemoved.add(testId);
				} else {
					failedTestIds.add(testId);
				}
			}

			// finally delete all duplicate failures (if any)
			final int duplicateFailures = resultsToBeRemoved.size();
			System.out.println("Test IDs to be removed: " + resultsToBeRemoved);
			if (duplicateFailures > 0) {
				for (ITestResult result : testContext.getFailedTests().getAllResults()) {
					final String testId = CleanUpDuplicate.getId(result);

					if (resultsToBeRemoved.contains(testId)) {
						testContext.getFailedTests().removeResult(result);

						resultsToBeRemoved.remove(testId);
						removedFailures++;
						System.out.println("Removing from the report test: " + testId);
					} 
				}
			}

			System.out.println("Finished cleaning up duplicate failures. Removed " + removedFailures);
		}
		return removedFailures;
	}

	/**
	 * removes the skipped test runs
	 * @param testContext
	 */
	public static void cleanUpSkippedTests(ITestContext testContext) {

		Set<ITestResult> skippedTests = testContext.getSkippedTests().getAllResults();
		for (ITestResult skippedTest : skippedTests) {
			ITestNGMethod method = skippedTest.getMethod();
			if (testContext.getSkippedTests().getResults(method).size() > 0) {
				skippedTests.remove(skippedTest);
			} else {
				if (testContext.getPassedTests().getResults(method).size() > 0) {
					skippedTests.remove(skippedTest);
				}
				if (testContext.getFailedTests().getResults(method).size() > 0) {
					skippedTests.remove(skippedTest);
				}
			}
		}

	}
	
	/**
	 * @param result
	 * @return the ID of the test case
	 */
	public static String getId(ITestResult result) {

		String testId = result.getMethod().getMethodName();
		
		if (result.getParameters().length > 0) {

			String dataProviderValue = String.valueOf(result.getParameters()[0]);
			String testIdDataProvider = testId + " : " + dataProviderValue;
			return testIdDataProvider;
			
		} else {
			return testId;
		}
	}

}
