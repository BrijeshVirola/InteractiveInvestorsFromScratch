package common.RetryTestFailures;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;

/**
 * If this class is used as listener in the xml then the failed tests will be re run
 * @author petarpetrov
 *
 */
public class AnnotationTransformer implements IAnnotationTransformer {

	@SuppressWarnings("rawtypes")
	@Override
	public void transform(ITestAnnotation annotation, Class testClass, Constructor testConstructor, Method testMethod) { 
		annotation.setRetryAnalyzer(RetryAnalyzer.class);
	}

}