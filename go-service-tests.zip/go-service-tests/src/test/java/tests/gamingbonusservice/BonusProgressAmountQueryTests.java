package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.gamingbonusservice.request.BonusProgressAmountQueryReq;
import tests.gamingbonusservice.response.BonusProgressAmountQueryResp;
import tests.gamingbonusservice.response.BonusProgressAmountQueryResult;

public class BonusProgressAmountQueryTests extends BaseClassSetup {
	
	@Test(description = "Make a request to BonusProgressAmountQuery. Positive scenario.")
	public void bonusProgressAmountQuery_Positive_Scenario() throws InterruptedException {
		
		String idForBonusProgressAmountQuery = UUID.randomUUID().toString();
		
		BonusProgressAmountQueryReq requestBonusProgressAmountQuery = new BonusProgressAmountQueryReq.Builder()
																		.defaults()
																		.id(idForBonusProgressAmountQuery)
																		.build();
		
		BonusProgressAmountQueryResp actualResponse =  BaseRequest.getResponse(requestBonusProgressAmountQuery, ResponseEndpoints.bonusProgressAmountQuerySuccess);

		BonusProgressAmountQueryResult bonusProgressAmountQueryResult = new BonusProgressAmountQueryResult.Builder()
																			.defaults()
																			.build();
		
		BonusProgressAmountQueryResp expectedResponse = new BonusProgressAmountQueryResp.Builder()
															.defaults()
															.addResult(bonusProgressAmountQueryResult)
															.id(idForBonusProgressAmountQuery)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
	}
	
	@Test(description = "Make a request to bonusProgressAmountQuery. Missing user_id parameter.")
	public void bonusProgressAmountQuery_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		BonusProgressAmountQueryReq request = new BonusProgressAmountQueryReq.Builder()
										.defaults()
										.userId(null)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.bonusProgressAmountQueryError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to bonusProgressAmountQuery. Missing userbonus_id parameter.")
	public void bonusProgressAmountQuery_MissingUserBonusId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		BonusProgressAmountQueryReq request = new BonusProgressAmountQueryReq.Builder()
										.defaults()
										.userBonusId(null)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.bonusProgressAmountQueryError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: userbonus_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to bonusProgressAmountQuery. Wrong method.")
	public void bonusProgressAmountQuery_Wrong_Method() {
		
		BonusProgressAmountQueryReq request = new BonusProgressAmountQueryReq.Builder()
										.defaults()
										.id(null)
										.method("INVALID_METHOD_NAME")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.bonusProgressAmountQueryError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
}

