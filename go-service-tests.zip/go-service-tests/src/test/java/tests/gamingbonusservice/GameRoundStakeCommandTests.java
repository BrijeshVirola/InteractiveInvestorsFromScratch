package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusservice.request.GameRoundStakeCommandReq;

public class GameRoundStakeCommandTests extends BaseClassSetup {
	
	@Test(description = "Make a request to GameRoundStakeCommand. Positive scenario.")
	public void gameRoundStakeCommand_Positive_Scenario() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GameRoundStakeCommandReq request = new GameRoundStakeCommandReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		ResultOKResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.gameRoundStakeCommandSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
	}
	
	@Test(description = "Make a request to gameRoundStakeCommand. Unknown transaction_id parameter.")
	public void gameRoundStakeCommand_UnknownTransactionIs_Parameter() {
		
		Long unknownTransactionId = 999999L;
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GameRoundStakeCommandReq request = new GameRoundStakeCommandReq.Builder()
										.defaults()
										.transactionId(unknownTransactionId)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.gameRoundStakeCommandError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Error in fetching game round data. No transaction was found.")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to gameRoundStakeCommand. Missing transaction_id parameter.")
	public void gameRoundStakeCommand_MissingTransactionId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GameRoundStakeCommandReq request = new GameRoundStakeCommandReq.Builder()
										.defaults()
										.transactionId(null)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.gameRoundStakeCommandError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: transaction_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to gameRoundStakeCommand. Wrong method.")
	public void gameRoundStakeCommand_Wrong_Method() {
		
		GameRoundStakeCommandReq request = new GameRoundStakeCommandReq.Builder()
										.defaults()
										.id(null)
										.method("INVALID_METHOD_NAME")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.gameRoundStakeCommandError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
}

