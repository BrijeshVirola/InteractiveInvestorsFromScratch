package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusservice.request.AddCreditedUserReq;

public class AddCreditedUserTests extends BaseClassSetup {
	
	@Test(description = "Make a request to AddCreditedUser. Positive scenario.")
	public void addCreditedUser_Positive_Scenario() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		AddCreditedUserReq request = new AddCreditedUserReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		ResultOKResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.addCreditedUserSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
	}
	
	@Test(description = "Make a request to addCreditedUser. Unknown user_id parameter.")
	public void addCreditedUser_UnknownUserId_Parameter() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		AddCreditedUserReq request = new AddCreditedUserReq.Builder()
										.defaults()
										.userId(UsersId.NOT_EXISTING)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.addCreditedUserError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Could not retrieve UserData")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to addCreditedUser. Missing user_id parameter.")
	public void addCreditedUser_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		AddCreditedUserReq request = new AddCreditedUserReq.Builder()
										.defaults()
										.userId(null)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.addCreditedUserError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to addCreditedUser. Missing bonustemplate_id parameter.")
	public void addCreditedUser_MissingBonusTemplateId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		AddCreditedUserReq request = new AddCreditedUserReq.Builder()
										.defaults()
										.bonusTemplateId(null)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.addCreditedUserError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: bonustemplate_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to addCreditedUser. Missing amount parameter.")
	public void addCreditedUser_MissingAmount_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		AddCreditedUserReq request = new AddCreditedUserReq.Builder()
										.defaults()
										.amount(null)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.addCreditedUserError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: amount")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to addCreditedUser. Missing creditedby parameter.")
	public void addCreditedUser_MissingCreditedBy_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		AddCreditedUserReq request = new AddCreditedUserReq.Builder()
										.defaults()
										.creditedBy(null)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.addCreditedUserError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: creditedby")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to addCreditedUser. bonus template does not support users country parameter.")
	public void addCreditedUser_CountryBonusemplateMismatch_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		AddCreditedUserReq request = new AddCreditedUserReq.Builder()
										.defaults()
										.bonusTemplateId(124)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.addCreditedUserError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("The user's country is not supported for this bonus template")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to addCreditedUser. Wrong method.")
	public void addCreditedUser_Wrong_Method() {
		
		AddCreditedUserReq request = new AddCreditedUserReq.Builder()
										.defaults()
										.id(null)
										.method("INVALID_METHOD_NAME")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.addCreditedUserError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
}