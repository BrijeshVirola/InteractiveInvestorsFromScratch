package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusservice.request.BonusCancelByUserCommandReq;
import tests.gamingbonusservice.request.ManualBonusCreditAndClaimCommandReq;
import tests.gamingbonusservice.response.ActiveBonusResult;
import tests.gamingbonusservice.response.EligibleGame;

public class ManualBonusCreditAndClaimCommandTests extends BaseClassSetup {
	
	@Test(description = "Make a request to ManualBonusCreditAndClaimCommand. Positive scenario.")
	public void manualBonusCreditAndClaimCommand_Positive_Scenario() throws InterruptedException {
	
		Integer testUserId = 4505797;
		Integer productId = 4;
		Integer bonusTemplateId = 137;
		Double amount = 0.0;
		
		ActiveBonusResult expectedBonusResult = new ActiveBonusResult.Builder()
				.defaults()
				.bonusTemplateId(bonusTemplateId)
				.templateName("UkComDepositPreWager01")
				.bonusTypeId(5)
				.amountPence(0)
				.userBonusStatusId(15)
				.maximumBonus(0)
				.currency("CHF")
				.isClaimed(false)
				.addEligibleGame(new EligibleGame.Builder().gametokenId(11813).build())
				.addEligibleGame(new EligibleGame.Builder().gametokenId(15826).build())
				.addEligibleGame(new EligibleGame.Builder().gametokenId(10601).build())
				.addEligibleGame(new EligibleGame.Builder().gametokenId(10892).build())
				.isRedeemed(false)
				.depositMatched(true)
				.moreGamesAvailable(true)
				.acknowledged(true)
				.build();
	
		ActiveBonusResult actualNewlyCreatedUserBonus = Utils.createActiveBonusAndVerifyThenReturnBonusDetails(testUserId, expectedBonusResult.bonustemplate_id, productId, expectedBonusResult, amount);
	
		String idForManualBonusCreditAndClaimCommand = UUID.randomUUID().toString();
		
		ManualBonusCreditAndClaimCommandReq requestManualBonusCreditAndClaimCommand = new ManualBonusCreditAndClaimCommandReq.Builder()
										.defaults()
										.id(idForManualBonusCreditAndClaimCommand)
										.build();
		
		ResultOKResp actualResponse =  BaseRequest.getResponse(requestManualBonusCreditAndClaimCommand, ResponseEndpoints.manualBonusCreditAndClaimCommandSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
															.defaults()
															.id(idForManualBonusCreditAndClaimCommand)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
		
		String idForBonusCancelByUserCommand = UUID.randomUUID().toString();
		
		BonusCancelByUserCommandReq requestBonusCancelByUserCommand = new BonusCancelByUserCommandReq.Builder()
				.defaults()
				.userId(testUserId)
				.userBonusId(actualNewlyCreatedUserBonus.userbonus_id)
				.id(idForBonusCancelByUserCommand)
				.build();

		ResultOKResp actualBonusCancelByUserCommandResponse =  BaseRequest.getResponse(requestBonusCancelByUserCommand, ResponseEndpoints.bonusCancelByUserCommandSuccess);

		ResultOKResp expectedBonusCancelByUserCommandResponse = new ResultOKResp.Builder()
											.defaults()
											.id(idForBonusCancelByUserCommand)
											.build();

		assertReflectionEquals(expectedBonusCancelByUserCommandResponse, actualBonusCancelByUserCommandResponse);	
	}
	
	@Test(description = "Make a request to manualBonusCreditAndClaimCommand. Unsupported bonus.")
	public void manualBonusCreditAndClaimCommand_UnsupportedBonus() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		ManualBonusCreditAndClaimCommandReq request = new ManualBonusCreditAndClaimCommandReq.Builder()
										.defaults()
										.productId(1)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.manualBonusCreditAndClaimCommandError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Unsupported bonus implementation")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to manualBonusCreditAndClaimCommand. Missing user_id parameter.")
	public void manualBonusCreditAndClaimCommand_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		ManualBonusCreditAndClaimCommandReq request = new ManualBonusCreditAndClaimCommandReq.Builder()
										.defaults()
										.userId(null)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.manualBonusCreditAndClaimCommandError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to manualBonusCreditAndClaimCommand. Wrong method.")
	public void manualBonusCreditAndClaimCommand_Wrong_Method() {
		
		ManualBonusCreditAndClaimCommandReq request = new ManualBonusCreditAndClaimCommandReq.Builder()
										.defaults()
										.id(null)
										.method("INVALID_METHOD_NAME")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.manualBonusCreditAndClaimCommandError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
}
