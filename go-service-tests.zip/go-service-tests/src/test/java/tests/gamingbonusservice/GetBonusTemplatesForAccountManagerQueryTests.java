package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.gamingbonusservice.request.GetBonusTemplatesForAccountManagerQueryReq;
import tests.gamingbonusservice.response.GetBonusTemplatesForAccountManagerQueryResp;
import tests.gamingbonusservice.response.GetBonusTemplatesForAccountManagerQueryResult;

public class GetBonusTemplatesForAccountManagerQueryTests extends BaseClassSetup {
	
	@Test(description = "Make a request to GetBonusTemplatesForAccountManagerQuery. Positive scenario.")
	public void GetBonusTemplatesForAccountManagerQuery_Positive_Scenario() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetBonusTemplatesForAccountManagerQueryReq request = new GetBonusTemplatesForAccountManagerQueryReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		GetBonusTemplatesForAccountManagerQueryResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getBonusTemplatesForAccountManagerQuerySuccess);

		GetBonusTemplatesForAccountManagerQueryResult result = new GetBonusTemplatesForAccountManagerQueryResult.Builder()
																.defaults()
																.build();

		GetBonusTemplatesForAccountManagerQueryResp expectedResponse = new GetBonusTemplatesForAccountManagerQueryResp.Builder()
															.defaults()
															.addResult(result)
															.id(idForRequestToBeEchoedBackInResponseId)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
	}
		
	@Test(description = "Make a request to GetBonusTemplatesForAccountManagerQuery. Missing product_id parameter.")
	public void GetBonusTemplatesForAccountManagerQuery_MissingProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetBonusTemplatesForAccountManagerQueryReq request = new GetBonusTemplatesForAccountManagerQueryReq.Builder()
										.defaults()
										.productId(null)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getBonusTemplatesForAccountManagerQueryError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: product_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to GetBonusTemplatesForAccountManagerQuery. Missing bonustype_id parameter.")
	public void GetBonusTemplatesForAccountManagerQuery_MissingBonusTypeId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetBonusTemplatesForAccountManagerQueryReq request = new GetBonusTemplatesForAccountManagerQueryReq.Builder()
										.defaults()
										.bonusTypeId(null)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getBonusTemplatesForAccountManagerQueryError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: bonustype_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to GetBonusTemplatesForAccountManagerQuery. Missing currency_id parameter.")
	public void GetBonusTemplatesForAccountManagerQuery_MissingCurrencyId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetBonusTemplatesForAccountManagerQueryReq request = new GetBonusTemplatesForAccountManagerQueryReq.Builder()
										.defaults()
										.currencyId(null)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getBonusTemplatesForAccountManagerQueryError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: currency_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
		
	@Test(description = "Make a request to GetBonusTemplatesForAccountManagerQuery. Missing country_id parameter.")
	public void GetBonusTemplatesForAccountManagerQuery_MissingCountryId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetBonusTemplatesForAccountManagerQueryReq request = new GetBonusTemplatesForAccountManagerQueryReq.Builder()
										.defaults()
										.countryId(null)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getBonusTemplatesForAccountManagerQueryError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: country_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to GetBonusTemplatesForAccountManagerQuery. Wrong method.")
	public void GetBonusTemplatesForAccountManagerQuery_Wrong_Method() {
		
		GetBonusTemplatesForAccountManagerQueryReq request = new GetBonusTemplatesForAccountManagerQueryReq.Builder()
										.defaults()
										.id(null)
										.method("INVALID_METHOD_NAME")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getBonusTemplatesForAccountManagerQueryError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
}