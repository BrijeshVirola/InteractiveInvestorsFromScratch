package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;

import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusservice.request.ActiveBonusQueryReq;
import tests.gamingbonusservice.request.AddCreditedUserReq;
import tests.gamingbonusservice.request.UserBonusListQueryReq;
import tests.gamingbonusservice.response.ActiveBonusQueryResp;
import tests.gamingbonusservice.response.ActiveBonusResult;
import tests.gamingbonusservice.response.BonusResult;
import tests.gamingbonusservice.response.EligibleGame;
import tests.gamingbonusservice.response.UserBonusListQueryResp;

public class Utils {
	
	public static BonusResult getBonusByDateAdded(Integer userId, String dateAddedToFind) {
		
		String idForUserBonusListQuery = UUID.randomUUID().toString();
		
		UserBonusListQueryReq requestUserBonusListQuery = new UserBonusListQueryReq.Builder()
				.defaults()
				.userId(userId)
				.id(idForUserBonusListQuery)
				.build();

		UserBonusListQueryResp actualUserBonusQueryListResponse =  BaseRequest.getResponse(requestUserBonusListQuery, ResponseEndpoints.userBonusListQuerySuccess);

		Assert.assertEquals(idForUserBonusListQuery, actualUserBonusQueryListResponse.getId());

		List<BonusResult> results = actualUserBonusQueryListResponse.getResults();

		BonusResult bonusResult = null;

		for (BonusResult result : results) {
			if (result.dateadded.equals(dateAddedToFind)) {
				bonusResult = result;
				break;
			}
		}
		
		return bonusResult;
	}
	
	public static void createBonus(Integer userId, Integer bonustemplateId, Double amount) {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		AddCreditedUserReq acuRequest = new AddCreditedUserReq.Builder()
										.defaults()
										.userId(userId)
										.bonusTemplateId(bonustemplateId)
										.amount(amount)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		ResultOKResp actualAcuResponse =  BaseRequest.getResponse(acuRequest, ResponseEndpoints.addCreditedUserSuccess);

		ResultOKResp expectedAcuResponse = new ResultOKResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.build();
		
		assertReflectionEquals(expectedAcuResponse, actualAcuResponse);	
	}
	
	public static BonusResult createBonusAndVerifyThenReturnBonusDetails(Integer userId, Integer bonusTemplateId, Integer productId, BonusResult expectedBonusResult, Double amount) throws InterruptedException {

		createBonus(userId, bonusTemplateId, amount);
		TimeUnit.SECONDS.sleep(10);
		String idForUserBonusListQuery = UUID.randomUUID().toString();
		
		UserBonusListQueryReq requestUserBonusListQuery = new UserBonusListQueryReq.Builder()
															.defaults()
															.userId(userId)
															.productId(productId)
															.id(idForUserBonusListQuery)
															.build();

		UserBonusListQueryResp actualUserBonusQueryListResponse =  BaseRequest.getResponse(requestUserBonusListQuery, ResponseEndpoints.userBonusListQuerySuccess);

		Assert.assertEquals(idForUserBonusListQuery, actualUserBonusQueryListResponse.getId());
		
		List<BonusResult> results = actualUserBonusQueryListResponse.getResults();
		
		BonusResult actualNewlyCreatedBonus = null;
		
		Instant mostRecent = Instant.parse("1970-01-01T00:00:00Z");
		for (BonusResult result : results) {
			Long duration = Duration.between(mostRecent, Instant.parse(result.dateadded)).toMillis();
			if (duration >= 0) {
				mostRecent = Instant.parse(result.dateadded);
				actualNewlyCreatedBonus = result;
			}
		}
		
		Assert.assertTrue(actualNewlyCreatedBonus != null);
		Assert.assertTrue(actualNewlyCreatedBonus.userbonus_id > 0);
		
		Assert.assertEquals(actualNewlyCreatedBonus.bonustemplate_id, expectedBonusResult.bonustemplate_id);
		Assert.assertEquals(actualNewlyCreatedBonus.bonustype_id, expectedBonusResult.bonustype_id);
		Assert.assertTrue(actualNewlyCreatedBonus.userbonus_id > 0);
		Assert.assertEquals(actualNewlyCreatedBonus.amount_pence, expectedBonusResult.amount_pence);
		Assert.assertEquals(actualNewlyCreatedBonus.ringfencedamount_pence, expectedBonusResult.ringfencedamount_pence);
		Assert.assertEquals(actualNewlyCreatedBonus.progressamount_pence, expectedBonusResult.progressamount_pence);
		Assert.assertEquals(actualNewlyCreatedBonus.completion_percentage, expectedBonusResult.completion_percentage);
		Assert.assertEquals(actualNewlyCreatedBonus.userbonusstatus_id, expectedBonusResult.userbonusstatus_id);
		Assert.assertEquals(actualNewlyCreatedBonus.minimumtransaction, expectedBonusResult.minimumtransaction);
		Assert.assertEquals(actualNewlyCreatedBonus.maximumbonus, expectedBonusResult.maximumbonus);
		
		Assert.assertEquals(actualNewlyCreatedBonus.bonustype, expectedBonusResult.bonustype);
		Assert.assertEquals(actualNewlyCreatedBonus.expiry, expectedBonusResult.expiry);
		Assert.assertEquals(actualNewlyCreatedBonus.currency, expectedBonusResult.currency);
		Assert.assertEquals(actualNewlyCreatedBonus.statusname, expectedBonusResult.statusname);
		Assert.assertEquals(actualNewlyCreatedBonus.templatename, expectedBonusResult.templatename);
		Assert.assertEquals(actualNewlyCreatedBonus.rolloverrequirement, expectedBonusResult.rolloverrequirement);
		Assert.assertEquals(actualNewlyCreatedBonus.createdby, expectedBonusResult.createdby);
		
		Assert.assertEquals(actualNewlyCreatedBonus.is_claimed, expectedBonusResult.is_claimed);
		Assert.assertEquals(actualNewlyCreatedBonus.is_expired, expectedBonusResult.is_expired);
		Assert.assertEquals(actualNewlyCreatedBonus.is_redeemed, expectedBonusResult.is_redeemed);
		Assert.assertEquals(actualNewlyCreatedBonus.notinterested, expectedBonusResult.notinterested);
		Assert.assertEquals(actualNewlyCreatedBonus.depositmatched, expectedBonusResult.depositmatched);
		Assert.assertEquals(actualNewlyCreatedBonus.is_cancellable, expectedBonusResult.is_cancellable);
		Assert.assertEquals(actualNewlyCreatedBonus.is_autocredited, expectedBonusResult.is_autocredited);
		
		return actualNewlyCreatedBonus;
		
	}
	
	public static class GameIdSorter implements Comparator<EligibleGame> 
	{
	    @Override
	    public int compare(EligibleGame game1, EligibleGame game2) {
	        return game2.getGameTokenId().compareTo(game1.getGameTokenId());
	    }
	}
	
	public static ActiveBonusResult createActiveBonusAndVerifyThenReturnBonusDetails(Integer userId, Integer bonusTemplateId, Integer productId, ActiveBonusResult expectedBonusResult, Double amount) {
		
		createBonus(userId, bonusTemplateId, amount);
		
		String idForActiveBonusQuery = UUID.randomUUID().toString();
		
		ActiveBonusQueryReq requestActiveBonusQuery = new ActiveBonusQueryReq.Builder()
				.defaults()
				.userId(userId)
				.productId(productId)
				.id(idForActiveBonusQuery)
				.build();

		ActiveBonusQueryResp actualActiveBonusQueryResp =  BaseRequest.getResponse(requestActiveBonusQuery, ResponseEndpoints.activeBonusQuerySuccess);

		Assert.assertEquals(idForActiveBonusQuery, actualActiveBonusQueryResp.getId());
		
		List<ActiveBonusResult> results = actualActiveBonusQueryResp.getResults();
		
		ActiveBonusResult actualNewlyCreatedBonus = null;
		
		Instant mostRecent = Instant.parse("1970-01-01T00:00:00Z");
		for (ActiveBonusResult result : results) {
			Long duration = Duration.between(mostRecent, Instant.parse(result.dateadded)).toMillis();
			if (duration >= 0) {
				mostRecent = Instant.parse(result.dateadded);
				actualNewlyCreatedBonus = result;
			}
		}
		
		Assert.assertTrue(actualNewlyCreatedBonus != null);
		Assert.assertTrue(actualNewlyCreatedBonus.userbonus_id > 0);
		
		Assert.assertEquals(actualNewlyCreatedBonus.bonustemplate_id, expectedBonusResult.bonustemplate_id);
		Assert.assertEquals(actualNewlyCreatedBonus.bonustype_id, expectedBonusResult.bonustype_id);
		Assert.assertTrue(actualNewlyCreatedBonus.userbonus_id > 0);
		Assert.assertEquals(actualNewlyCreatedBonus.amount_pence, expectedBonusResult.amount_pence);
		Assert.assertEquals(actualNewlyCreatedBonus.ringfencedamount_pence, expectedBonusResult.ringfencedamount_pence);
		Assert.assertEquals(actualNewlyCreatedBonus.progressamount_pence, expectedBonusResult.progressamount_pence);
		Assert.assertEquals(actualNewlyCreatedBonus.completion_percentage, expectedBonusResult.completion_percentage);
		Assert.assertEquals(actualNewlyCreatedBonus.userbonusstatus_id, expectedBonusResult.userbonusstatus_id);
		Assert.assertEquals(actualNewlyCreatedBonus.minimumtransaction, expectedBonusResult.minimumtransaction);
		Assert.assertEquals(actualNewlyCreatedBonus.maximumbonus, expectedBonusResult.maximumbonus);
		
		Assert.assertEquals(actualNewlyCreatedBonus.bonustype, expectedBonusResult.bonustype);
		
		Assert.assertEquals(actualNewlyCreatedBonus.currency, expectedBonusResult.currency);
		Assert.assertEquals(actualNewlyCreatedBonus.statusname, expectedBonusResult.statusname);
		Assert.assertEquals(actualNewlyCreatedBonus.templatename, expectedBonusResult.templatename);
		Assert.assertEquals(actualNewlyCreatedBonus.rolloverrequirement, expectedBonusResult.rolloverrequirement);
		Assert.assertEquals(actualNewlyCreatedBonus.createdby, expectedBonusResult.createdby);
		
		Assert.assertEquals(actualNewlyCreatedBonus.is_claimed, expectedBonusResult.is_claimed);
		Assert.assertEquals(actualNewlyCreatedBonus.is_expired, expectedBonusResult.is_expired);
		Assert.assertEquals(actualNewlyCreatedBonus.is_redeemed, expectedBonusResult.is_redeemed);
		Assert.assertEquals(actualNewlyCreatedBonus.notinterested, expectedBonusResult.notinterested);
		Assert.assertEquals(actualNewlyCreatedBonus.depositmatched, expectedBonusResult.depositmatched);
		
		Assert.assertEquals(actualNewlyCreatedBonus.priority, expectedBonusResult.priority);
		Assert.assertEquals(actualNewlyCreatedBonus.moregamesavailable, expectedBonusResult.moregamesavailable);
		Assert.assertEquals(actualNewlyCreatedBonus.gameinpromotion, expectedBonusResult.gameinpromotion);
		Assert.assertEquals(actualNewlyCreatedBonus.rolloverrequirement_pence, expectedBonusResult.rolloverrequirement_pence);
		Assert.assertEquals(actualNewlyCreatedBonus.wageringamount_pence, expectedBonusResult.wageringamount_pence);
		Assert.assertEquals(actualNewlyCreatedBonus.acknowledged, expectedBonusResult.acknowledged);
		Assert.assertEquals(actualNewlyCreatedBonus.rewardcash, expectedBonusResult.rewardcash);
		
		List<EligibleGame> actualGamesSorted = actualNewlyCreatedBonus.eligiblegames; 
		actualGamesSorted.sort(new Utils.GameIdSorter());
		
		List<EligibleGame> expectedGamesSorted = expectedBonusResult.eligiblegames; 
		expectedGamesSorted.sort(new Utils.GameIdSorter());
		
		Assert.assertEquals(actualGamesSorted.size(), expectedGamesSorted.size());
		
		for (int i=0; i<actualGamesSorted.size(); i++) {
			Assert.assertEquals(actualGamesSorted.get(i).getGameTokenId(), expectedGamesSorted.get(i).getGameTokenId());
		}
		Assert.assertEquals(actualNewlyCreatedBonus.subsequentbonusamount_pence, expectedBonusResult.subsequentbonusamount_pence);
		Assert.assertEquals(actualNewlyCreatedBonus.subsequentbonustype, expectedBonusResult.subsequentbonustype);
		
		//these times are usually the same but can randomly differ by 1 second
		Instant dateAdded = Instant.parse(actualNewlyCreatedBonus.dateadded);
		Instant expiry = Instant.parse(actualNewlyCreatedBonus.expiry);
		List<Instant> dates = new ArrayList<Instant>();
		dates.add(dateAdded);
		dates.add(expiry);
		dates.sort(Comparator.naturalOrder());
				
		if (expectedBonusResult.expiry.equals("0001-01-01T00:00:00Z")) {
			Assert.assertEquals(actualNewlyCreatedBonus.expiry, expectedBonusResult.expiry);
		}
		else {
			Assert.assertTrue(Duration.between(dates.get(0), dates.get(1)).toMillis() <= 1000);
		}
		
		return actualNewlyCreatedBonus;
	}
}
