package tests.gamingbonusservice.response;

import java.util.ArrayList;
import java.util.List;

public class ActiveBonusQueryResp {

	private String id;
	private List<ActiveBonusResult> result;
 
	private ActiveBonusQueryResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public String getId() {
		return this.id;
	}
	
	public List<ActiveBonusResult> getResults() {
		return this.result;
	}
	
	public static class Builder {
		private String id;
		private List<ActiveBonusResult> result = new ArrayList<ActiveBonusResult>();

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder addResult(ActiveBonusResult activeBonusResult) {
			this.result.add(activeBonusResult);
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			return this;
		}

		public ActiveBonusQueryResp build() {
			return new ActiveBonusQueryResp(this);
		}
	}
}