package tests.gamingbonusservice.response;

public class GetBonusTemplatesForAccountManagerQueryResult {	
	
	public Integer bonustemplate_id, bonustype_id, maximumbonusamount, minimumtransaction;
	public Boolean is_depositmatched;
	public String templatename, termsandconditions;
	
	private GetBonusTemplatesForAccountManagerQueryResult(Builder builder) {
		
		this.bonustemplate_id = builder.bonustemplate_id;
		this.templatename = builder.templatename;
		this.maximumbonusamount = builder.maximumbonusamount;
		this.minimumtransaction = builder.minimumtransaction;
		this.termsandconditions = builder.termsandconditions;
		this.is_depositmatched = builder.is_depositmatched;
	}

	public static class Builder {
		private Integer bonustemplate_id, maximumbonusamount, minimumtransaction;
		private Boolean is_depositmatched;
		private String templatename, termsandconditions;
		
		public Builder bonusTemplateId(Integer bonustemplate_id) {
			this.bonustemplate_id = bonustemplate_id;
			return this;
		}
				
		public Builder maximumBonusAmount(Integer maximumbonusamount) {
			this.maximumbonusamount = maximumbonusamount;
			return this;
		}
		
		public Builder minimumTransaction(Integer minimumtransaction) {
			this.minimumtransaction = minimumtransaction;
			return this;
		}
		
		public Builder termsAndConditions(String termsandconditions) {
			this.termsandconditions = termsandconditions;
			return this;
		}
		
		public Builder templateName(String templatename) {
			this.templatename = templatename;
			return this;
		}
		
		public Builder isDepositMatched(Boolean is_depositmatched) {
			this.is_depositmatched = is_depositmatched;
			return this;
		}
		
		public Builder defaults() {
			this.bonustemplate_id = 99;		
			this.templatename = "SC Cash1 UK";
			this.maximumbonusamount = 2460;
			this.minimumtransaction = 0;
			this.termsandconditions = "https://games011.b365uat.com/promotions/en/";
			this.is_depositmatched = false;
			return this;
		}

		public GetBonusTemplatesForAccountManagerQueryResult build() {
			return new GetBonusTemplatesForAccountManagerQueryResult(this);
		}
	}
}
