package tests.gamingbonusservice.response;

import java.util.ArrayList;
import java.util.List;

public class BonusProgressAmountQueryResp {

	private String id;
	private List<BonusProgressAmountQueryResult> result;
 
	private BonusProgressAmountQueryResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public String getId() {
		return this.id;
	}
	
	public List<BonusProgressAmountQueryResult> getResults() {
		return this.result;
	}
	
	public static class Builder {
		private String id;
		private List<BonusProgressAmountQueryResult> result = new ArrayList<BonusProgressAmountQueryResult>();

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder addResult(BonusProgressAmountQueryResult bonusResult) {
			this.result.add(bonusResult);
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			return this;
		}

		public BonusProgressAmountQueryResp build() {
			return new BonusProgressAmountQueryResp(this);
		}
	}
}