package tests.gamingbonusservice.response;

public class CheckBonusEligibilityCommandResp {

	@SuppressWarnings("unused")
	private String id;

	Result result;

	private CheckBonusEligibilityCommandResp(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}
	
	public static class Builder {
		Integer userbonus_id;
		Boolean maxbet_exceeded, exists;
		String id, maxbet;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder userBonusId(Integer userbonus_id) {
			this.userbonus_id = userbonus_id;
			return this;
		}

		public Builder maxbetExceeded(Boolean maxbet_exceeded) {
			this.maxbet_exceeded = maxbet_exceeded;
			return this;
		}

		public Builder exists(Boolean exists) {
			this.exists = exists;
			return this;
		}
		
		public Builder maxBet(String maxbet) {
			this.maxbet = maxbet;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			this.exists = true;
			this.userbonus_id = 7935;
			this.maxbet_exceeded = false;
			this.maxbet = "0";
			return this;
		}

		public CheckBonusEligibilityCommandResp build() {
			return new CheckBonusEligibilityCommandResp(this);
		}
	}
	
	private class Result {

		@SuppressWarnings("unused")
		Integer userbonus_id;
		@SuppressWarnings("unused")
		Boolean maxbet_exceeded, exists;
		@SuppressWarnings("unused")
		String maxbet;
		
		public Result(Builder builder) {
			
			this.userbonus_id = builder.userbonus_id;
			this.maxbet_exceeded = builder.maxbet_exceeded;
			this.exists = builder.exists;
			this.maxbet = builder.maxbet;
		}
	}
}
