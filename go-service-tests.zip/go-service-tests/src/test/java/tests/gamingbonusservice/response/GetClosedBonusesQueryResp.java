package tests.gamingbonusservice.response;

import java.util.ArrayList;
import java.util.List;

public class GetClosedBonusesQueryResp {

	private String id;
	private List<ClosedBonusResult> result;
 
	private GetClosedBonusesQueryResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public String getId() {
		return this.id;
	}
	
	public List<ClosedBonusResult> getResults() {
		return this.result;
	}
	
	public static class Builder {
		private String id;
		private List<ClosedBonusResult> result = new ArrayList<ClosedBonusResult>();

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder addResult(ClosedBonusResult bonusResult) {
			this.result.add(bonusResult);
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			return this;
		}

		public GetClosedBonusesQueryResp build() {
			return new GetClosedBonusesQueryResp(this);
		}
	}
}
