package tests.gamingbonusservice.response;

import java.util.ArrayList;
import java.util.List;

public class UserBonusListQueryResp {

	private String id;
	private List<BonusResult> result;
 
	private UserBonusListQueryResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public String getId() {
		return this.id;
	}
	
	public List<BonusResult> getResults() {
		return this.result;
	}
	
	public static class Builder {
		private String id;
		private List<BonusResult> result = new ArrayList<BonusResult>();

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder addResult(BonusResult bonusResult) {
			this.result.add(bonusResult);
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			return this;
		}

		public UserBonusListQueryResp build() {
			return new UserBonusListQueryResp(this);
		}
	}
}