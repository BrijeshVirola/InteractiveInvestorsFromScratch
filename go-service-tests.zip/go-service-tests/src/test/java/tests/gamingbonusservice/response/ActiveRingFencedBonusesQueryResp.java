package tests.gamingbonusservice.response;

import java.util.ArrayList;
import java.util.List;

public class ActiveRingFencedBonusesQueryResp {

	private String id;
	private List<ActiveRingFencedBonusesQueryResult> result;
 
	private ActiveRingFencedBonusesQueryResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public String getId() {
		return this.id;
	}
	
	public List<ActiveRingFencedBonusesQueryResult> getResults() {
		return this.result;
	}
	
	public static class Builder {
		private String id;
		private List<ActiveRingFencedBonusesQueryResult> result = new ArrayList<ActiveRingFencedBonusesQueryResult>();

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder addResult(ActiveRingFencedBonusesQueryResult activeRingFencedBonusesQueryResult) {
			this.result.add(activeRingFencedBonusesQueryResult);
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			return this;
		}

		public ActiveRingFencedBonusesQueryResp build() {
			return new ActiveRingFencedBonusesQueryResp(this);
		}
	}
}