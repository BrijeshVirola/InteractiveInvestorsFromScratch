package tests.gamingbonusservice.response;

public class ClosedBonusResult {	
	
	public Integer bonustemplate_id;
	public Integer bonustype_id;
	public Integer userbonus_id;
	public Integer amount_pence;
	public Integer ringfencedamount_pence;
	public Integer progressamount_pence;
	public Integer completion_percentage;
	public Integer userbonusstatus_id;
	public Integer minimumtransaction;
	public Integer maximumbonus;
	public Integer priority;
	public String bonustype, expiry, currency, statusname, templatename, rolloverrequirement, createdby, dateadded, qualifyingtransaction_amount, qualifyingtransaction_date, admin, bonuscloseddate;
	public Boolean is_claimed, is_expired, is_redeemed, notinterested, depositmatched, is_cancellable, is_autocredited;

	private ClosedBonusResult(Builder builder) {
		this.qualifyingtransaction_amount = builder.qualifyingtransaction_amount;
		this.qualifyingtransaction_date = builder.qualifyingtransaction_date;
		this.priority = builder.priority;
		this.admin = builder.admin;
		this.bonuscloseddate = builder.bonuscloseddate;
		this.bonustemplate_id = builder.bonustemplate_id;
		this.bonustype_id = builder.bonustype_id;
		this.userbonus_id = builder.userbonus_id;
		this.amount_pence = builder.amount_pence;
		this.ringfencedamount_pence = builder.ringfencedamount_pence;
		this.progressamount_pence = builder.progressamount_pence;
		this.completion_percentage = builder.completion_percentage;
		this.userbonusstatus_id = builder.userbonusstatus_id;
		this.minimumtransaction = builder.minimumtransaction;
		this.maximumbonus = builder.maximumbonus;
		
		this.bonustype = builder.bonustype;
		this.expiry = builder.expiry;
		this.currency = builder.currency;
		this.statusname = builder.statusname;
		this.templatename = builder.templatename;
		this.rolloverrequirement = builder.rolloverrequirement;
		this.createdby = builder.createdby;
		this.dateadded = builder.dateadded;
		
		this.is_claimed = builder.is_claimed;
		this.is_expired = builder.is_expired;
		this.is_redeemed = builder.is_redeemed;
		this.notinterested = builder.notinterested;
		this.depositmatched = builder.depositmatched;
		this.is_cancellable = builder.is_cancellable;
		this.is_autocredited = builder.is_autocredited;
	}

	public static class Builder {
		private Integer bonustemplate_id, bonustype_id, userbonus_id, amount_pence, ringfencedamount_pence, progressamount_pence, completion_percentage, userbonusstatus_id, minimumtransaction, maximumbonus, priority;
		private String bonustype, expiry, currency, statusname, templatename, rolloverrequirement, createdby, dateadded, qualifyingtransaction_amount, qualifyingtransaction_date, admin, bonuscloseddate;
		private Boolean is_claimed, is_expired, is_redeemed, notinterested, depositmatched, is_cancellable, is_autocredited;

		public Builder bonusTemplateId(Integer bonustemplate_id) {
			this.bonustemplate_id = bonustemplate_id;
			return this;
		}
		
		public Builder bonusTypeId(Integer bonustype_id) {
			this.bonustype_id = bonustype_id;
			return this;
		}
		
		public Builder userBonusId(Integer userbonus_id) {
			this.userbonus_id = userbonus_id;
			return this;
		}
		
		public Builder amountPence(Integer amount_pence) {
			this.amount_pence = amount_pence;
			return this;
		}
		
		public Builder ringFencedAmountPence(Integer ringfencedamount_pence) {
			this.ringfencedamount_pence = ringfencedamount_pence;
			return this;
		}
		
		public Builder progressAmountPence(Integer progressamount_pence) {
			this.progressamount_pence = progressamount_pence;
			return this;
		}
		
		public Builder completionPercentage(Integer completion_percentage) {
			this.completion_percentage = completion_percentage;
			return this;
		}
		
		public Builder userBonusStatusId(Integer userbonusstatus_id) {
			this.userbonusstatus_id = userbonusstatus_id;
			return this;
		}
		
		public Builder minimumTransaction(Integer minimumtransaction) {
			this.minimumtransaction = minimumtransaction;
			return this;
		}
		
		public Builder maximumBonus(Integer maximumbonus) {
			this.maximumbonus = maximumbonus;
			return this;
		}
		
		public Builder priority(Integer priority) {
			this.priority = priority;
			return this;
		}
		
		public Builder bonusType(String bonustype) {
			this.bonustype = bonustype;
			return this;
		}
		
		public Builder expiry(String expiry) {
			this.expiry = expiry;
			return this;
		}
		
		public Builder currency(String currency) {
			this.currency = currency;
			return this;
		}
		
		public Builder statusName(String statusname) {
			this.statusname = statusname;
			return this;
		}
		
		public Builder templateName(String templatename) {
			this.templatename = templatename;
			return this;
		}
		
		public Builder rolloverRequirement(String rolloverrequirement) {
			this.rolloverrequirement = rolloverrequirement;
			return this;
		}
		
		public Builder createdBy(String createdby) {
			this.createdby = createdby;
			return this;
		}
		
		public Builder dateAdded(String dateadded) {
			this.dateadded = dateadded;
			return this;
		}
		
		public Builder qualifyingTransactionAmount(String qualifyingtransaction_amount) {
			this.qualifyingtransaction_amount = qualifyingtransaction_amount;
			return this;
		}
		
		public Builder qualifyingTransactionDate(String qualifyingtransaction_date) {
			this.qualifyingtransaction_date = qualifyingtransaction_date;
			return this;
		}
		
		public Builder bonuscloseddate(String bonuscloseddate) {
			this.bonuscloseddate = bonuscloseddate;
			return this;
		}
		
		public Builder admin(String admin) {
			this.admin = admin;
			return this;
		}
		
		public Builder isClaimed(Boolean is_claimed) {
			this.is_claimed = is_claimed;
			return this;
		}
		
		public Builder isExpired(Boolean is_expired) {
			this.is_expired = is_expired;
			return this;
		}
		
		public Builder isRedeemed(Boolean is_redeemed) {
			this.is_redeemed = is_redeemed;
			return this;
		}
		
		public Builder notInterested(Boolean notinterested) {
			this.notinterested = notinterested;
			return this;
		}
		
		public Builder depositMatched(Boolean depositmatched) {
			this.depositmatched = depositmatched;
			return this;
		}
		
		public Builder isCancellable(Boolean is_cancellable) {
			this.is_cancellable = is_cancellable;
			return this;
		}
		
		public Builder isAutocredited(Boolean is_autocredited) {
			this.is_autocredited = is_autocredited;
			return this;
		}
		
		public Builder defaults() {
			this.bonustemplate_id = 305;
			this.bonustype_id = 3;
			this.userbonus_id = null;
			this.amount_pence = 1;
			this.ringfencedamount_pence = null;
			this.progressamount_pence = 0;
			this.completion_percentage = 0;
			this.userbonusstatus_id = 10;
			this.minimumtransaction = 0;
			this.maximumbonus = 100;
			this.priority = 0;
			
			this.bonustype = "Cash";
			this.expiry = "0001-01-01T00:00:00Z";
			this.currency = "GBP";
			this.statusname = "Redeemed";
			this.templatename = "PnnTestCash";
			this.rolloverrequirement = "0";
			this.createdby = "gaming bonus api automated tests";
			this.dateadded = null;
			this.qualifyingtransaction_amount = "0";
			this.qualifyingtransaction_date = "";
			this.admin = "";
			this.bonuscloseddate = null;
			
			this.is_claimed = true;
			this.is_expired = false;
			this.is_redeemed = true;
			this.notinterested = false;
			this.depositmatched = false;
			this.is_cancellable = false;
			this.is_autocredited = false;
			
			return this;
		}

		public ClosedBonusResult build() {
			return new ClosedBonusResult(this);
		}
	}
}
