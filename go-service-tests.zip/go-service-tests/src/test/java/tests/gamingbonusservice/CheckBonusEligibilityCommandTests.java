package tests.gamingbonusservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusservice.request.BonusCancelByUserCommandReq;
import tests.gamingbonusservice.request.BonusClaimCommandReq;
import tests.gamingbonusservice.request.CheckBonusEligibilityCommandReq;
import tests.gamingbonusservice.response.BonusResult;
import tests.gamingbonusservice.response.CheckBonusEligibilityCommandResp;

public class CheckBonusEligibilityCommandTests extends BaseClassSetup {

	@Test(description = "Make a request to CheckBonusEligibilityCommand. Positive scenario.")
	public void checkBonusEligibilityCommand_Positive_Scenario() throws InterruptedException {
		Integer testUserId = 4520316;
		Integer productId = 4;
		Double amount = 0.01;
		
		BonusResult expectedBonusResult = new BonusResult.Builder()
				.defaults()
				.bonusTemplateId(88)
				.maximumBonus(10)
				.templateName("Automation Pre-Wager with Threshold limit")
				.build();
		
		BonusResult actualNewlyCreatedUserBonus = Utils.createBonusAndVerifyThenReturnBonusDetails(testUserId, expectedBonusResult.bonustemplate_id, productId, expectedBonusResult, amount);
	
		String idForBonusClaimCommand = UUID.randomUUID().toString();
		
		BonusClaimCommandReq requestBonusClaimCommand = new BonusClaimCommandReq.Builder()
										.defaults()
										.userId(testUserId)
										.userBonusId(actualNewlyCreatedUserBonus.userbonus_id)
										.id(idForBonusClaimCommand)
										.build();
		
		ResultOKResp actualResponse =  BaseRequest.getResponse(requestBonusClaimCommand, ResponseEndpoints.bonusClaimCommandSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
															.defaults()
															.id(idForBonusClaimCommand)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		CheckBonusEligibilityCommandReq request = new CheckBonusEligibilityCommandReq.Builder()
										.defaults()
										.amount(amount)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();

		CheckBonusEligibilityCommandResp expectedEligibilityResponse = new CheckBonusEligibilityCommandResp.Builder()
												.defaults()
												.userBonusId(actualNewlyCreatedUserBonus.userbonus_id)
												.id(idForRequestToBeEchoedBackInResponseId)
												.build();

		CheckBonusEligibilityCommandResp actualEligibilityResponse = BaseRequest.getResponse(request, ResponseEndpoints.checkBonusEligibilityCommandSuccess);

		assertReflectionEquals(expectedEligibilityResponse, actualEligibilityResponse);
		
		String idForBonusCancelByUserCommand = UUID.randomUUID().toString();
		
		BonusCancelByUserCommandReq requestBonusCancelByUserCommand = new BonusCancelByUserCommandReq.Builder()
																			.defaults()
																			.userId(testUserId)
																			.userBonusId(actualNewlyCreatedUserBonus.userbonus_id)
																			.id(idForBonusCancelByUserCommand)
																			.build();

		ResultOKResp actualBonusCancelResponse =  BaseRequest.getResponse(requestBonusCancelByUserCommand, ResponseEndpoints.bonusCancelByUserCommandSuccess);

		ResultOKResp expectedBonusCancelResponse = new ResultOKResp.Builder()
											.defaults()
											.id(idForBonusCancelByUserCommand)
											.build();

		assertReflectionEquals(expectedBonusCancelResponse, actualBonusCancelResponse);	
	}
	
	@Test(description = "Make a request to checkBonusEligibilityCommand. Missing user_id parameter.")
	public void DepositBonusQuery_MissingUserId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		CheckBonusEligibilityCommandReq request = new CheckBonusEligibilityCommandReq.Builder()
										.defaults()
										.userId(null)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.checkBonusEligibilityCommandError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to checkBonusEligibilityCommand. Missing regulatedgame_id parameter.")
	public void DepositBonusQuery_MissingRegulatedGameId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		CheckBonusEligibilityCommandReq request = new CheckBonusEligibilityCommandReq.Builder()
										.defaults()
										.regulatedId(null)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.checkBonusEligibilityCommandError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Missing/invalid parameter: regulatedgame_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to checkBonusEligibilityCommand. Wrong method.")
	public void checkBonusEligibilityCommand_Wrong_Method() {

		CheckBonusEligibilityCommandReq request = new CheckBonusEligibilityCommandReq.Builder().defaults().id(null).method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actualResponse = BaseRequest.getResponse(request, ResponseEndpoints.checkBonusEligibilityCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder().code(6)
				.message("Incorrect method in request").id(null).build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

}