package tests.gamingbonusservice.request;

import java.util.HashMap;
import java.util.Map;

public class BonusCancelByUserCommandReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private BonusCancelByUserCommandReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
		this.params.put("userbonus_id", builder.userbonus_id);
		this.params.put("sports_product_id", builder.sports_product_id);
		this.params.put("iscancelledbywithdrawal", builder.iscancelledbywithdrawal);
		this.params.put("bonus_implementation", builder.bonus_implementation);
	}

	public static class Builder {
		private String method, id;
		private Integer user_id, userbonus_id, sports_product_id, bonus_implementation;
		private Boolean iscancelledbywithdrawal;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder userBonusId(Integer userbonus_id) {
			this.userbonus_id = userbonus_id;
			return this;
		}
		
		public Builder sportsProductId(Integer sports_product_id) {
			this.sports_product_id = sports_product_id;
			return this;
		}
		
		public Builder isCancelledByWithdrawal(Boolean iscancelledbywithdrawal) {
			this.iscancelledbywithdrawal = iscancelledbywithdrawal;
			return this;
		}
		
		public Builder bonusImplementation(Integer bonus_implementation) {
			this.bonus_implementation = bonus_implementation;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.method = "bonuscancelbyusercommand";
			this.user_id = 4641187;
			this.userbonus_id = 17059;
			this.sports_product_id = 3;
			this.iscancelledbywithdrawal = true;
			this.bonus_implementation = 2;
			return this;
		}

		public BonusCancelByUserCommandReq build() {
			return new BonusCancelByUserCommandReq(this);
		}
	}
}

