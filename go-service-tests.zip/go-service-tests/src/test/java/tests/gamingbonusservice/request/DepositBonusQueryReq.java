package tests.gamingbonusservice.request;

import java.util.HashMap;
import java.util.Map;

public class DepositBonusQueryReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private DepositBonusQueryReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("sports_product_id", builder.sports_product_id);
		this.params.put("user_id", builder.user_id);
	}

	public static class Builder {
		private String method, id;
		private Integer sports_product_id, user_id;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder sportsProductId(Integer sports_product_id) {
			this.sports_product_id = sports_product_id;
			return this;
		}
		
		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.user_id = 435343;
			this.sports_product_id = 3;
			this.method = "depositbonusquery";
			return this;
		}

		public DepositBonusQueryReq build() {
			return new DepositBonusQueryReq(this);
		}
	}
}

