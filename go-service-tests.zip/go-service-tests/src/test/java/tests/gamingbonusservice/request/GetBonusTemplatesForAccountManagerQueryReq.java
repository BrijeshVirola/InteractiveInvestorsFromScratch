package tests.gamingbonusservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetBonusTemplatesForAccountManagerQueryReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private GetBonusTemplatesForAccountManagerQueryReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("product_id", builder.product_id);
		this.params.put("bonustype_id", builder.bonustype_id);
		this.params.put("currency_id", builder.currency_id);
		this.params.put("country_id", builder.country_id);
	}

	public static class Builder {
		private String method, id;
		private Integer product_id, bonustype_id, currency_id, country_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder productId(Integer product_id) {
			this.product_id = product_id;
			return this;
		}
		
		public Builder bonusTypeId(Integer bonustype_id) {
			this.bonustype_id = bonustype_id;
			return this;
		}
		
		public Builder currencyId(Integer currency_id) {
			this.currency_id = currency_id;
			return this;
		}

		public Builder countryId(Integer country_id) {
			this.country_id = country_id;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.method = "getbonustemplatesforaccountmanagerquery";
			this.product_id = 4;
			this.bonustype_id = 3;
			this.currency_id = 64;
			this.country_id = 197;
			return this;
		}

		public GetBonusTemplatesForAccountManagerQueryReq build() {
			return new GetBonusTemplatesForAccountManagerQueryReq(this);
		}
	}
}

