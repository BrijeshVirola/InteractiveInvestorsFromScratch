package tests.gamingbonusservice.request;

import java.util.HashMap;
import java.util.Map;

public class GameRoundStakeCommandReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private GameRoundStakeCommandReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("transaction_id", builder.transaction_id);
	}

	public static class Builder {
		private String method, id;
		private Long transaction_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder transactionId(Long transaction_id) {
			this.transaction_id = transaction_id;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.method = "gameroundstakecommand";
			this.transaction_id = 8584986789678594L;
			return this;
		}

		public GameRoundStakeCommandReq build() {
			return new GameRoundStakeCommandReq(this);
		}
	}
}

