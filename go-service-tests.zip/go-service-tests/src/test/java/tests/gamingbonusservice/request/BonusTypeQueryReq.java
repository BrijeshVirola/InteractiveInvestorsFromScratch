package tests.gamingbonusservice.request;

import java.util.HashMap;
import java.util.Map;

public class BonusTypeQueryReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	@SuppressWarnings("unused")
	private Map<String, Object> params = new HashMap<>();

	private BonusTypeQueryReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
	}

	public static class Builder {
		private String method, id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.method = "bonustypequery";
			return this;
		}

		public BonusTypeQueryReq build() {
			return new BonusTypeQueryReq(this);
		}
	}
}

