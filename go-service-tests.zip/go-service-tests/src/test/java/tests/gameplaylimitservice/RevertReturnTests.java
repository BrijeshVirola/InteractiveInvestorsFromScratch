package tests.gameplaylimitservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;
import org.testng.Assert;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.ExpectedFailure;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.gameplaylimitservice.request.RevertReturnReq;
import tests.gameplaylimitservice.response.RevertReturnResp;


public class RevertReturnTests extends BaseClassSetup {

	@ExpectedFailure(jiraRef="PRJSAK-2399", action="commented the assertion, id field not echoed back see comments on PRJSAK-2399")
	@Test(description = "Make a request to AddCreditedUser. Positive scenario.")
	public void revertReturn_Positive_Scenario() throws InterruptedException {
		


		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		RevertReturnReq request = new RevertReturnReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		RevertReturnResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.revertReturnSuccess);

		String ExpectedTime = actualResponse.revertReturnDatetimeUtc();
		System.out.println(ExpectedTime);
		Assert.assertEquals(actualResponse.revertReturnDatetimeUtc(), ExpectedTime);
	//	Assert.assertEquals(actualResponse.id(), idForRequestToBeEchoedBackInResponseId);
	}
	
	@Test(description = "Make a request to RevertReturn. Missing user_id parameter.")
	public void revertReturn_UserId_Missing_Parameter() {

        String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
        RevertReturnReq request = new RevertReturnReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.userId(null)
										.build();
		
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.revertReturnError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: user_id is missing")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to RevertReturn. Missing return_amount parameter.")
	public void revertReturn_Return_Amount_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		RevertReturnReq request = new RevertReturnReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.returnAmount(null)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.revertReturnError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: return_amount must be > 0")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to RevertReturn. Wrong method.")
	public void revertReturn_Wrong_Method() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		RevertReturnReq request = new RevertReturnReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.method("INVALID_METHOD_NAME")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.revertReturnError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
