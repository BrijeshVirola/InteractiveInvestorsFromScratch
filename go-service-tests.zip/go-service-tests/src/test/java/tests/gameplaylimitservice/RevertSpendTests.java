package tests.gameplaylimitservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.util.TimeUtils;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.gameplaylimitservice.request.RevertSpendReq;
import tests.gameplaylimitservice.requestobjects.PerGroupLimitDetails;
import tests.gameplaylimitservice.response.RevertSpendResp;


public class RevertSpendTests extends BaseClassSetup {
	
	@DataProvider(name = "setWeekStartDaySuccess")
	public Object[][] setWeekStartDaySuccess() {
		return new Object[][] {
			{1}, {3}, {6}		
		};
	}

	@DataProvider(name = "setWeekStartDayFailure")
	public Object[][] setWeekStartDayFailure() {
		return new Object[][] {
			{-1}, {7}, {8}		
		};
	}
	
	@DataProvider(name = "bucketTypeRangeSuccess")
	public Object[][] bucketTypeRangeSuccess() {
		return new Object[][] {
			{"s"}, {"sessioning"}, {"sessionsessionsessio"}		
		};
	}
	
	@DataProvider(name = "groupIdentifierSuccess")
	public Object[][] groupIdentifierSuccess() {
		return new Object[][] {
			{"E"}, {"Ccg7teUAkhTD1DZGyD+arER@qnZ54WY2Ne+Ruv822e*$6KoFF4"}, {"1tkgYErm3*&=%PSMoNO$oWCE$nhjesBodxD6jdcNMk1Yv%&tF6gMsJNOg=PCZkQNqd&vNrZ2c189FeQrNAsySDhQwMrp=Z2tdYEO"},		
		};
	}
	
	@DataProvider(name = "localDateTimeSuccess")
	public Object[][] localDateTimeSuccess() {
		return new Object[][] {
			{-86400000000000L}, {86400000000000L}	
		};
	}
	
	@DataProvider(name = "localDateTimeFailure")
	public Object[][] localDateTimeFailure() {
		return new Object[][] {
			{-86400000000001L}, {86400000000001L}	
		};
	}
	@Test(description = "Make a request to RevertReturn. Positive scenario.")
	public void RevertReturn_Positive_Scenario() throws InterruptedException {
	
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();

		RevertSpendResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.RevertSpendSuccess);
	  
		Assert.assertEquals(actualResponse.id(), idForRequestToBeEchoedBackInResponseId);   

		String actualSpendDateTimeUtc = actualResponse.getRevertSpendDatetimeUtc();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String expectedDate = dateFormat.format(date);
		Format f = new SimpleDateFormat("HH:mm");
		String expectedResult = f.format(new Date());
		
	    Assert.assertTrue(actualSpendDateTimeUtc.contains(expectedDate));
		Assert.assertTrue(actualSpendDateTimeUtc.contains(expectedResult));
		
		
	}

	
	@Test(description = "Make a request to RevertSpend. Week Start Day parameter - Positive scenario.", dataProvider = "setWeekStartDaySuccess")
	public void RevertReturn_Week_Start_Day_Range_Parameter(Integer week_start_day) {


		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();


		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.weekStartDay(week_start_day)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();

		RevertSpendResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.RevertSpendSuccess);
	   // TimeUtils expectedTime = new TimeUtils();
	    
		Assert.assertEquals(actualResponse.id(), idForRequestToBeEchoedBackInResponseId);
		Assert.assertEquals(actualResponse.getRevertSpendDatetimeUtc(), false);
		String actualSpendDateTimeUtc = actualResponse.getRevertSpendDatetimeUtc();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String expectedDate = dateFormat.format(date);
		Format f = new SimpleDateFormat("HH:mm");
		String expectedResult = f.format(new Date());
		
	    Assert.assertTrue(actualSpendDateTimeUtc.contains(expectedDate));
		Assert.assertTrue(actualSpendDateTimeUtc.contains(expectedResult));
		

	}

	@Test(description = "Make a request to RevertSpend. Bucket_type - success range parameter for Per Group Limit Details - Positive Scenario.", dataProvider = "bucketTypeRangeSuccess")
	public void RevertSpend_Per_Group_Limit_Details_Bucket_Type_range_success_Parameter(String bucket_type) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.bucketType(bucket_type)
				.build();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();

		RevertSpendResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.RevertSpendSuccess);
	    
		Assert.assertEquals(actualResponse.id(), idForRequestToBeEchoedBackInResponseId);
		String actualSpendDateTimeUtc = actualResponse.getRevertSpendDatetimeUtc();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String expectedDate = dateFormat.format(date);
		Format f = new SimpleDateFormat("HH:mm");
		String expectedResult = f.format(new Date());
		
	    Assert.assertTrue(actualSpendDateTimeUtc.contains(expectedDate));
		Assert.assertTrue(actualSpendDateTimeUtc.contains(expectedResult));
		
		
	}
	
	
	@Test(description = "Make a request to RevertSpend. Group_identifier range parameter for Per Group Limit Details - Positive Scenario.", dataProvider = "groupIdentifierSuccess")
	public void RevertSpend_Per_Group_Limit_Details_group_identifier_range_success_Parameter(String group_identifier) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.groupIdentifier(group_identifier)
				.build();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();

		RevertSpendResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.RevertSpendSuccess);
	    
		Assert.assertEquals(actualResponse.id(), idForRequestToBeEchoedBackInResponseId);
		String actualSpendDateTimeUtc = actualResponse.getRevertSpendDatetimeUtc();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String expectedDate = dateFormat.format(date);
		Format f = new SimpleDateFormat("HH:mm");
		String expectedResult = f.format(new Date());
		
	    Assert.assertTrue(actualSpendDateTimeUtc.contains(expectedDate));
		Assert.assertTrue(actualSpendDateTimeUtc.contains(expectedResult));
		
	}

	
	@Test(description = "Make a request to RevertReturn - Min Revert Amount - 0.01. Positive scenario.")
	public void RevertReturn_Revert_Amount_0_01_Positive_Scenario() throws InterruptedException {
	
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.revertAmount(0.01)
				.build();

		RevertSpendResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.RevertSpendSuccess);
	    
		Assert.assertEquals(actualResponse.id(), idForRequestToBeEchoedBackInResponseId);
		Assert.assertNotNull(actualResponse.getRevertSpendDatetimeUtc());   
		String actualSpendDateTimeUtc = actualResponse.getRevertSpendDatetimeUtc();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String expectedDate = dateFormat.format(date);
		Format f = new SimpleDateFormat("HH:mm");
		String expectedResult = f.format(new Date());
		
	    Assert.assertTrue(actualSpendDateTimeUtc.contains(expectedDate));
		Assert.assertTrue(actualSpendDateTimeUtc.contains(expectedResult));
		
	}

	@Test(description = "Make a request to RevertSpend. Local Date Time - Range parameter - Positive Scenario.", dataProvider = "localDateTimeSuccess")
	public void RevertSpend_Local_Date_Utc_Offset_Range_Parameter_positive_scenario(Long local_date_utc_offset) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.localDateUtcOffset(local_date_utc_offset)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();

        RevertSpendResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.RevertSpendSuccess);
	    
		Assert.assertEquals(actualResponse.id(), idForRequestToBeEchoedBackInResponseId);
		Assert.assertNotNull(actualResponse.getRevertSpendDatetimeUtc());  
		String actualSpendDateTimeUtc = actualResponse.getRevertSpendDatetimeUtc();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String expectedDate = dateFormat.format(date);
		Format f = new SimpleDateFormat("HH:mm");
		String expectedResult = f.format(new Date());
		
	    Assert.assertTrue(actualSpendDateTimeUtc.contains(expectedDate));
		Assert.assertTrue(actualSpendDateTimeUtc.contains(expectedResult));
		
		 
}
	
		
	
	@Test(description = "Make a request to RevertSpend. Wrong method.")
	public void RevertSpend_Wrong_Method() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.RevertSpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
					
	}

	@Test(description = "Make a request to RevertSpend. Missing user_id parameter.")
	public void RevertSpend_UserId_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(null)
				.build();


		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.RevertSpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: user_id is missing")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to RevertReturn - Revert Amount - 0. Negative scenario.")
	public void RevertReturn_Revert_Amount_0_Negative_Scenario() throws InterruptedException {
	
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.revertAmount(0.00)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.RevertSpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: revert_amount must be > 0")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
  
		
	}


	@Test(description = "Make a request to RevertSpend. Week start day out of range parameter - Negative scenario.", dataProvider = "setWeekStartDayFailure")
	public void RevertReturn_Week_Start_Day_Out_Of_Range_Parameter(Integer week_start_day) {


		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();


		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.weekStartDay(week_start_day)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();

		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.RevertSpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: week_start_day must be between 0 and 6")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);


	}
	
	@Test(description = "Make a request to RevertSpend. Local time out of range - parameter.", dataProvider = "localDateTimeFailure")
	public void RevertSpend_Local_Date_Utc_Offset_Out_Of_Range_Parameter(Long local_date_utc_offset) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		RevertSpendReq request = new RevertSpendReq.Builder()
				.defaults()
				.localDateUtcOffset(local_date_utc_offset)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();


		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.RevertSpendError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: local_date_utc_offset must be between -86400000000000 and 86400000000000")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}


}
