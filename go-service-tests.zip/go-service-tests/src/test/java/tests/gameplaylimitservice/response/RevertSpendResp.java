package tests.gameplaylimitservice.response;


public class RevertSpendResp {

	@SuppressWarnings("unused")
	private String id;
	private Result result;

	private RevertSpendResp(Builder builder) {
		this.id = builder.id;	
		result = new Result(builder);
	}

	public String id() {
		return id;
	}
	
	public String getRevertSpendDatetimeUtc() {
		return result.revert_spend_datetime_utc;
	}
	
	
	public static class Builder {
		private String id;
		private String revert_spend_datetime_utc;
	
		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder getRevertSpendDatetimeUtc(String revert_spend_datetime_utc) {
			this.revert_spend_datetime_utc = revert_spend_datetime_utc;
			return this;
		}

		
		public Builder defaults() {
			this.id = "1";
			this.revert_spend_datetime_utc = "";
			return this;
		}

		public RevertSpendResp build() {
			return new RevertSpendResp(this);
		}
	}
	
	private class Result {

		String revert_spend_datetime_utc;


		public Result(Builder builder) {
			this.revert_spend_datetime_utc = builder.revert_spend_datetime_utc;

		}
	}
}

