package tests.gameplaylimitservice.response;


public class ApplyReturnResp{

	@SuppressWarnings("unused")
	private String id;
	private Result result;

	private ApplyReturnResp(Builder builder) {
		this.id = builder.id;	
		result = new Result(builder);
	}

	public String id() {
		return id;
	}
	
	public String applyReturnDatetimeUtc() {
		return result.apply_return_datetime_utc;
	}
	
	
	public static class Builder {
		private String id;
		private String apply_return_datetime_utc;
	
		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder applyReturnDatetimeUtc(String apply_return_datetime_utc) {
			this.apply_return_datetime_utc = apply_return_datetime_utc;
			return this;
		}

		
		public Builder defaults() {
			this.id = "1";
			this.apply_return_datetime_utc = "";
			return this;
		}

		public ApplyReturnResp build() {
			return new ApplyReturnResp(this);
		}
	}
	
	private class Result {

		String apply_return_datetime_utc;


		public Result(Builder builder) {
			this.apply_return_datetime_utc = builder.apply_return_datetime_utc;

		}
	}
}