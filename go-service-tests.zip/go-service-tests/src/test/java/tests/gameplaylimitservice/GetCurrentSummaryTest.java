package tests.gameplaylimitservice;


import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.gameplaylimitservice.request.GetCurrentSummaryReq;
import tests.gameplaylimitservice.requestobjects.PerGroupLimitDetails;
import tests.gameplaylimitservice.response.GetCurrentSummaryResp;
import tests.gameplaylimitservice.responseobjects.GameplaySummary;



public class GetCurrentSummaryTest extends BaseClassSetup {

	@DataProvider(name = "setWeekStartDay")
	public Object[][] setWeekStartDay() {
		return new Object[][] {
			{-1}, {7}, {8},		
		};
	}


	@Test(description = "Make a request to GetCurrentSummary. Positive scenario.")
	public void getCurrentSummary_Positive_Scenario() throws InterruptedException {
	
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentSummarySuccess);
	    
		GameplaySummary actualResult0 = actualResponse.getGameplaySummary(0);
		GameplaySummary actualResult1 = actualResponse.getGameplaySummary(1);
		GameplaySummary actualResult2 = actualResponse.getGameplaySummary(2);
		GameplaySummary actualResult3 = actualResponse.getGameplaySummary(3);
		
		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal("0")
				.returnTotal("0")
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal("0")
				.returnTotal("0")
				.build();	

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal("0")
				.returnTotal("0")
				.build();	

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal("0")
				.returnTotal("0")
				.build();


		assertReflectionEquals(expectedGameplaySummaryDay, actualResult0);
		assertReflectionEquals(expectedGameplaySummaryMonth, actualResult1);
		assertReflectionEquals(expectedGameplaySummaryWeek, actualResult2);
		assertReflectionEquals(expectedGameplaySummarySession, actualResult3);

		Assert.assertEquals(actualResponse.id(), idForRequestToBeEchoedBackInResponseId);
		Assert.assertNotNull(actualResponse.getCurrentSummaryDatetimeUtc());
        
		
	}
	
	@Test(description = "Make a request to GetCurrentSummary. Verify DateTime - Positive scenario.")
	public void getCurrentSummary_Verify_DateTime_Positive_Scenario() throws InterruptedException {
	
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();



		GetCurrentSummaryResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentSummarySuccess);

		GameplaySummary actualResult0 = actualResponse.getGameplaySummary(0);
		GameplaySummary actualResult1 = actualResponse.getGameplaySummary(1);
		GameplaySummary actualResult2 = actualResponse.getGameplaySummary(2);
		GameplaySummary actualResult3 = actualResponse.getGameplaySummary(3);
		
		GameplaySummary expectedGameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal("0")
				.returnTotal("0")
				.build();

		GameplaySummary expectedGameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal("0")
				.returnTotal("0")
				.build();	

		GameplaySummary expectedGameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal("0")
				.returnTotal("0")
				.build();	

		GameplaySummary expectedGameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal("0")
				.returnTotal("0")
				.build();

	
		Assert.assertEquals(actualResponse.id(), idForRequestToBeEchoedBackInResponseId);	
		String actualSpendDateTimeUtc = actualResponse.getCurrentSummaryDatetimeUtc();
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String expectedDate = dateFormat.format(date);
		Format f = new SimpleDateFormat("HH:mm");
		String expectedResult = f.format(new Date());
		
	    Assert.assertTrue(actualSpendDateTimeUtc.contains(expectedDate));
		Assert.assertTrue(actualSpendDateTimeUtc.contains(expectedResult));
		assertReflectionEquals(expectedGameplaySummaryDay, actualResult0);
		assertReflectionEquals(expectedGameplaySummaryMonth, actualResult1);
		assertReflectionEquals(expectedGameplaySummaryWeek, actualResult2);
		assertReflectionEquals(expectedGameplaySummarySession, actualResult3);

	}


	@Test(description = "Make a request to GetCurrentSummary. Wrong method.")
	public void getCurrentSummary_Wrong_Method() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("INVALID_METHOD_NAME")
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();



		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
		
			
	}

	@Test(description = "Make a request to GetCurrentSummary. Missing user_id parameter.")
	public void GetCurrentSummary_UserId_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(null)
				.build();


		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: user_id is missing")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	
	@Test(description = "Make a request to GetCurrentSummary. Max Value - spend_group_user_ids parameters - Positive scenario.")
	public void getCurrentSummary_Max_Value_spend_group_user_ids_Positive_Scenario() throws InterruptedException {



		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
			    .spendGroupDefaultsMax()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();



		GetCurrentSummaryResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentSummarySuccess);

		GameplaySummary gameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal("0")
				.returnTotal("0")
				.build();

		GameplaySummary gameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal("0")
				.returnTotal("0")
				.build();	

		GameplaySummary gameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal("0")
				.returnTotal("0")
				.build();	

		GameplaySummary gameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal("0")
				.returnTotal("0")
				.build();

		String expectedTime = actualResponse.getCurrentSummaryDatetimeUtc();

		GetCurrentSummaryResp expResponse =  new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addGameplaySummary(gameplaySummaryDay)
				.addGameplaySummary(gameplaySummaryMonth)
				.addGameplaySummary(gameplaySummaryWeek)                	
				.addGameplaySummary(gameplaySummarySession)
				.currentSummaryDatetimeUtc(expectedTime)
				.build();

		Assert.assertEquals(actualResponse.getCurrentSummaryDatetimeUtc(), expectedTime);
		Assert.assertEquals(actualResponse.id(), idForRequestToBeEchoedBackInResponseId);

		assertReflectionEquals(expResponse, actualResponse);

	}


	@Test(description = "Make a request to GetCurrentSummary. Missing spend_group_user_ids parameter.")
	public void GetCurrentSummary_Spend_Group_User_Ids_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addSpendGroupUserIds(null)
				.build();


		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: spend_group_user_ids is missing")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetCurrentSummary. Missing per_group_limit_details_bucket_type parameter.")
	public void GetCurrentSummary_Per_Group_Limit_Details_Bucket_Type_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.bucketType(null)
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();


		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: per_group_limit_details.bucket_type must be between 1 and 20 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetCurrentSummary. Max out of range per_group_limit_details_bucket_type parameter.")
	public void GetCurrentSummary_Per_Group_Limit_Details_Bucket_Type_Max_Out_Of_Range_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.bucketType("sessionsessionsession")
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();


		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: per_group_limit_details.bucket_type must be between 1 and 20 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}


	@Test(description = "Make a request to GetCurrentSummary. Missing per_group_limit_details_group_identifier parameter.")
	public void GetCurrentSummary_Per_Group_Limit_Details_Group_Identifier_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.groupIdentifier(null)
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();


		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: per_group_limit_details.group_identifier must be between 1 and 100 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to GetCurrentSummary. Max Out of range per_group_limit_details_group_identifier parameter.")
	public void GetCurrentSummary_Per_Group_Limit_Details_Group_Identifier_Max_Out_Of_Range_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.groupIdentifier("ka0S2o7r9d6yPx4PfM1X%HppOcn6+kCd4z%bjRz0!XGss07!U#VMXgam4A=X$D*YU4NFUtpSCzw=HuO1$MRaDg%4&2g$74h1%bgNN")
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();


		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: per_group_limit_details.group_identifier must be between 1 and 100 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
		
	}


	@Test(description = "Make a request to GetCurrentSummary. Week day out of range parameter.", dataProvider = "setWeekStartDay")
	public void GetCurrentSummary_Week_Day_Out_Of_Range_Parameter(Integer week_start_day) {

		System.out.println(week_start_day);
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.weekStartDay(week_start_day)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();


		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: week_start_day must be between 0 and 6")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	
	@Test(description = "Make a request to GetCurrentSummary. Local Date Time - Max Value parameter - Positive Scenario.")
	public void GetCurrentSummary_Local_Date_Utc_Offset_Max_Value_Positive_Scenario_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.localDateUtcOffset(86400000000000L)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentSummarySuccess);

		GameplaySummary gameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal("0")
				.returnTotal("0")
				.build();

		GameplaySummary gameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal("0")
				.returnTotal("0")
				.build();	

		GameplaySummary gameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal("0")
				.returnTotal("0")
				.build();	

		GameplaySummary gameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal("0")
				.returnTotal("0")
				.build();

		String expectedTime = actualResponse.getCurrentSummaryDatetimeUtc();

		GetCurrentSummaryResp expResponse =  new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addGameplaySummary(gameplaySummaryDay)
				.addGameplaySummary(gameplaySummaryMonth)
				.addGameplaySummary(gameplaySummaryWeek)                	
				.addGameplaySummary(gameplaySummarySession)
				.currentSummaryDatetimeUtc(expectedTime)
				.build();

		Assert.assertEquals(actualResponse.getCurrentSummaryDatetimeUtc(), expectedTime);
		Assert.assertEquals(actualResponse.id(), idForRequestToBeEchoedBackInResponseId);

		assertReflectionEquals(expResponse, actualResponse);
	}
	
	@Test(description = "Make a request to GetCurrentSummary. Local Date Time - Min Value parameter - Positive Scenario.")
	public void GetCurrentSummary_Local_Date_Utc_Offset_Min_Value_Positive_Scenario_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.localDateUtcOffset(-86400000000000L)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();

		GetCurrentSummaryResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentSummarySuccess);

		GameplaySummary gameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal("0")
				.returnTotal("0")
				.build();

		GameplaySummary gameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal("0")
				.returnTotal("0")
				.build();	

		GameplaySummary gameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal("0")
				.returnTotal("0")
				.build();	

		GameplaySummary gameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal("0")
				.returnTotal("0")
				.build();

		String expectedTime = actualResponse.getCurrentSummaryDatetimeUtc();

		GetCurrentSummaryResp expResponse =  new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addGameplaySummary(gameplaySummaryDay)
				.addGameplaySummary(gameplaySummaryMonth)
				.addGameplaySummary(gameplaySummaryWeek)                	
				.addGameplaySummary(gameplaySummarySession)
				.currentSummaryDatetimeUtc(expectedTime)
				.build();

		Assert.assertEquals(actualResponse.getCurrentSummaryDatetimeUtc(), expectedTime);
		Assert.assertEquals(actualResponse.id(), idForRequestToBeEchoedBackInResponseId);

		assertReflectionEquals(expResponse, actualResponse);
	}
	
	@Test(description = "Make a request to GetCurrentSummary. Local time out of range - Max parameter.")
	public void GetCurrentSummary_Local_Date_Utc_Offset_Out_Of_Range__Max_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.localDateUtcOffset(86400000000001L)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();


		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: local_date_utc_offset must be between -86400000000000 and 86400000000000")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetCurrentSummary. Local time out of range - Min parameter.")
	public void GetCurrentSummary_Local_Date_Utc_Offset_Out_Of_Range__Min_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.localDateUtcOffset(-86400000000001L)
				.id(idForRequestToBeEchoedBackInResponseId)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();


		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentSummaryError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Invalid parameter: local_date_utc_offset must be between -86400000000000 and 86400000000000")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetCurrentSummary. User Id - Max value parameter - Positive Scenario.")
	public void GetCurrentSummary_Max_Value_User_Id_Positive_Scenario_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
      
		PerGroupLimitDetails perGroupLimitDetails = new PerGroupLimitDetails.Builder()
				.defaults()
				.build();

		GetCurrentSummaryReq request = new GetCurrentSummaryReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.userId(2127283647)
				.addPerGroupLimitDetails(perGroupLimitDetails)
				.build();


		GetCurrentSummaryResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentSummarySuccess);

		GameplaySummary gameplaySummaryDay = new GameplaySummary.Builder()
				.defaults()
				.bucketType("day")
				.spendTotal("0")
				.returnTotal("0")
				.build();

		GameplaySummary gameplaySummaryMonth = new GameplaySummary.Builder()
				.defaults()
				.bucketType("month")
				.spendTotal("0")
				.returnTotal("0")
				.build();	

		GameplaySummary gameplaySummaryWeek = new GameplaySummary.Builder()
				.defaults()
				.bucketType("week")
				.spendTotal("0")
				.returnTotal("0")
				.build();	

		GameplaySummary gameplaySummarySession = new GameplaySummary.Builder()
				.defaults()
				.bucketType("session")
				.spendTotal("0")
				.returnTotal("0")
				.build();

		String expectedTime = actualResponse.getCurrentSummaryDatetimeUtc();

		GetCurrentSummaryResp expResponse =  new GetCurrentSummaryResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addGameplaySummary(gameplaySummaryDay)
				.addGameplaySummary(gameplaySummaryMonth)
				.addGameplaySummary(gameplaySummaryWeek)                	
				.addGameplaySummary(gameplaySummarySession)
				.currentSummaryDatetimeUtc(expectedTime)
				.build();

		Assert.assertEquals(actualResponse.getCurrentSummaryDatetimeUtc(), expectedTime);
		Assert.assertEquals(actualResponse.id(), idForRequestToBeEchoedBackInResponseId);

		assertReflectionEquals(expResponse, actualResponse);

	}
		
}



