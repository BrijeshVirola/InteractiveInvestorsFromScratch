package tests.gameplaylimitservice.request;

import tests.gameplaylimitservice.requestobjects.PerGroupLimitDetails;

public class RevertSpendReq {
	
	@SuppressWarnings("unused")
	private String Id;
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private Params params;
	
	
	public RevertSpendReq(Builder builder) {
		this.Id = builder.id;
		this.Method = builder.method;
		this.params = new Params(builder);
	}
	
	public static class Builder {

		private String id;
		private String method;
		private Integer user_id;
		public PerGroupLimitDetails per_group_limit_details;
		public Double revert_amount;
		public Long local_date_utc_offset;
		public Integer week_start_day;



		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder revertAmount(Double revert_amount) {
			this.revert_amount = revert_amount;
			return this;
		}


		public Builder addPerGroupLimitDetails(PerGroupLimitDetails perGroupLimitDetails) {

			this.per_group_limit_details = perGroupLimitDetails;
			return this;
		}



		public Builder localDateUtcOffset(Long local_date_utc_offset) {
			this.local_date_utc_offset = local_date_utc_offset;
			return this;
		}

		public Builder weekStartDay(Integer week_start_day) {
			this.week_start_day = week_start_day;
			return this;
		}

		public Builder defaults() {
			this.id = "Id";
			this.method = "revertspend";
			this.user_id = 1050979;
			this.revert_amount = 4.54;
			this.local_date_utc_offset = -10800000000000L;
			this.week_start_day = 0;
			return this;
		}

		public RevertSpendReq build() {
			return new RevertSpendReq(this);
		}
	}



	public class Params {

		private Integer user_id;
		private PerGroupLimitDetails per_group_limit_details;
		private Double revert_amount;
		private Long local_date_utc_offset;
		private Integer week_start_day;

		public Params(Builder builder) {
			this.user_id = builder.user_id;
			this.per_group_limit_details = builder.per_group_limit_details;
			this.revert_amount = builder.revert_amount;
			this.local_date_utc_offset = builder.local_date_utc_offset;
			this.week_start_day = builder.week_start_day;
		}
	}
}


