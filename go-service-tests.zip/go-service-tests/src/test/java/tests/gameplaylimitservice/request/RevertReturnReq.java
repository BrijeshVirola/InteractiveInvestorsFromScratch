package tests.gameplaylimitservice.request;

import java.util.HashMap;
import java.util.Map;


public class RevertReturnReq {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String method;

	private Map<String, Object> params = new HashMap<>();

	private RevertReturnReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
		this.params.put("revert_amount", builder.revert_amount);
		this.params.put("local_date_utc_offset", builder.local_date_utc_offset);
		this.params.put("week_start_day", builder.week_start_day);
	}

	public static class Builder {
		private String method, id;
		private Integer user_id, week_start_day;
		private Double revert_amount;
		private Long local_date_utc_offset;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder weekStartDay(Integer week_start_day) {
			this.week_start_day = week_start_day;
			return this;
		}
		
		public Builder returnAmount(Double revert_amount) {
			this.revert_amount = revert_amount;
			return this;
		}
		
		
		public Builder localDateUtcOffset(Long local_date_utc_offset) {
			this.local_date_utc_offset = local_date_utc_offset;
			return this;
		}

			
		public Builder defaults() {
			this.id = "Id";
			this.method = "revertreturn";
			this.user_id = 1030979;
			this.revert_amount = 4.54;
			this.local_date_utc_offset = -10800000000000L;
			this.week_start_day = 0;
			
			return this;
		}

		public RevertReturnReq build() {
			return new RevertReturnReq(this);
		}
	}
}
