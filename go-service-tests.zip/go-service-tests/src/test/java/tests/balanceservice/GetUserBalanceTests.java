package tests.balanceservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import common.enumsconstants.ProductId;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.balanceservice.request.GetUserBalanceReq;
import tests.balanceservice.response.GetUserBalanceResp;

public class GetUserBalanceTests  extends BaseClassSetup {
	
	@DataProvider()
	private Object[] userId_productId() {
		return new Object[] {"0", "null"};
	}

	@Test(description = "Get User Balance - Positive Scenario", dataProvider = "getUserBalance", dataProviderClass = DataProviders.class)
	public void getUserBalance_Positive_Scenario(
			ProductId productId,
			int userId,
			String balance,
			String bonus,
			String ring_fenced,
			boolean gbtBonus) {
		
		GetUserBalanceReq req = new GetUserBalanceReq.Builder()
				.defaults()
				.userId(userId)
				.productId(productId.getId())
				.hasGbtBonus(gbtBonus)
				.build();

		GetUserBalanceResp actUserBalanceResponse = BaseRequest.getResponse(req, ResponseEndpoints.getUserBalanceSuccess);
		GetUserBalanceResp expUserBalanceResponse = new GetUserBalanceResp(userId, balance, bonus, ring_fenced);

		assertReflectionEquals(expUserBalanceResponse, actUserBalanceResponse);
	}
	
	@Test(description = "Get User Balance - Missing parameter user_id", dataProvider = "userId_productId")
	public void getUserBalance_Missing_User_Id(String user_id) {
		
		String id = UUID.randomUUID().toString();
		Integer userId = user_id.equals("null") ? null : Integer.parseInt(user_id);
		
		GetUserBalanceReq req = new GetUserBalanceReq.Builder()
				.defaults()
				.id(id)
				.userId(userId)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(req, ResponseEndpoints.getUserBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Get User Balance - Missing product_id", dataProvider = "userId_productId")
	public void getUserBalance_Missing_Product_Id(String product_id) {
		
		String id = UUID.randomUUID().toString();
		Integer productId = product_id.equals("null") ? null : Integer.parseInt(product_id);
		
		GetUserBalanceReq req = new GetUserBalanceReq.Builder()
				.defaults()
				.id(id)
				.productId(productId)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(req, ResponseEndpoints.getUserBalanceError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: product_id")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}
