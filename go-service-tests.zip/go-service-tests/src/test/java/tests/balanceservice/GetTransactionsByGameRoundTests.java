package tests.balanceservice;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import common.TransactionType;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.balanceservice.request.AdjustBalanceReq;
import tests.balanceservice.request.GetTransactionsByGameRoundReq;
import tests.balanceservice.response.AdjustBalanceResp;
import tests.balanceservice.response.GetTransactionsByGameRoundResp;
import tests.gameroundservice.request.GameRoundRequest;
import tests.gameroundservice.response.GameRoundResp;

public class GetTransactionsByGameRoundTests extends BaseClassSetup {
	@Test(dataProvider = "group1TransactionTypeProvider", dataProviderClass = DataProviders.class)
	public void valid_GameRound_When_GetTransactionsByGameRound_ThenTheExpectedTransactionsAreReturned(TransactionType transactionType,
			int regulatedGameId,
			int cmscoreGameId) {
		String requestedPartnerGameRoundId = UUID.randomUUID().toString();
		String id = UUID.randomUUID().toString();

		int partnerId = 100;
		int providerRegionId = 20;
		GameRoundResp newGameRound = GameRoundRequest.createGameRound(UsersId.GO_SVC_TESTS, requestedPartnerGameRoundId, partnerId, regulatedGameId, providerRegionId);
		assertThat("Partner game round id", newGameRound.getResult().getPartnerGameRoundId(), equalTo(requestedPartnerGameRoundId));

		long gameRoundId = newGameRound.getResult().getId();

		AdjustBalanceReq adjBalanceReq = new AdjustBalanceReq.Builder()
				.defaults()
				.transactionType(transactionType)
				.regulatedGameId(regulatedGameId)
				.cmscoreGameId(cmscoreGameId)
				.realAmount("0")
				.totalAmount("0")
				.gameRoundId(gameRoundId)
				.userId(UsersId.GO_SVC_TESTS)
				.partnerId(newGameRound.getResult().getPartnerId())
				.bet365TransactionId(-1)
				.sourceBet365GamesTransactionIid(-1l)
				.build();

		AdjustBalanceResp adjBalanceResp = BaseRequest.getResponse(adjBalanceReq, ResponseEndpoints.adjustBalance);
		AdjustBalanceResp expResp = new AdjustBalanceResp(adjBalanceReq, adjBalanceResp, true);
		assertReflectionEquals(expResp, adjBalanceResp);
		
		GetTransactionsByGameRoundReq getTrnByGameRoundReq = new GetTransactionsByGameRoundReq(id, gameRoundId);
		
		GetTransactionsByGameRoundResp actTrnByGameRoundResp = BaseRequest.getResponse(
				getTrnByGameRoundReq, ResponseEndpoints.getTransactionsByGameRoundSuccess);
		GetTransactionsByGameRoundResp expTrnByGameRoundResp = new GetTransactionsByGameRoundResp(id, adjBalanceReq,
				adjBalanceResp);
		assertReflectionEquals(expTrnByGameRoundResp, actTrnByGameRoundResp);
		
		GameRoundResp closeResponse = GameRoundRequest.closeGameRoundBybet365GameRoundId(newGameRound);
		
		newGameRound.setEndDateAndCloseReason(closeResponse);

		assertReflectionEquals(newGameRound, closeResponse);
	}
	
	@Test(description = "getTransactionsByGameRound - Missing parameter game_round_id")
	public void getTransactionsByGameRound_Missing_Game_Round_Id() {
		
		String id = UUID.randomUUID().toString();
		
		GetTransactionsByGameRoundReq getTrnByGameRoundReq = new GetTransactionsByGameRoundReq(id, null);
		
		CustomErrorResponse actError = BaseRequest.getResponse(
				getTrnByGameRoundReq, ResponseEndpoints.getTransactionsByGameRoundError);
		
		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: game_round_id")
				.id(id)
				.build();

		assertReflectionEquals(expError, actError);
	}
}
