package tests.balanceservice.response;

import java.util.ArrayList;
import java.util.List;

import common.enumsconstants.Errors;
import domain.ErrorResponse;
import tests.balanceservice.request.AdjustBalanceReq;
import tests.balanceservice.responseobjects.TransactionResult;

public class GetTransactionsByPartnerTransactionIdResp extends ErrorResponse {
	
	@SuppressWarnings("unused")
	private String id = null;
	private List<TransactionResult> result;
	
	public GetTransactionsByPartnerTransactionIdResp(AdjustBalanceReq request, TransactionRecord transaction) {
		result = new ArrayList<TransactionResult>();
		result.add(new TransactionResult(request, transaction));
	}
	
	public void addTransaction(AdjustBalanceReq request, TransactionRecord transaction) {
		result.add(new TransactionResult(request, transaction));
	}
	
	public GetTransactionsByPartnerTransactionIdResp (Errors error) {
		super(error);
	}
}
