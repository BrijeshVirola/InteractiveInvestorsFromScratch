package tests.balanceservice.responseobjects;

public class GetUserBalanceResult {
	
	@SuppressWarnings("unused")
	private int user_id;
	@SuppressWarnings("unused")
	private String balance;
	@SuppressWarnings("unused")
	private String bonus;
	@SuppressWarnings("unused")
	private String ring_fenced;

	public GetUserBalanceResult(int user_id, String balance, String bonus, String ring_fenced) {
		this.user_id = user_id;
		this.balance = balance;
		this.bonus = bonus;
		this.ring_fenced = ring_fenced;
	}
}
