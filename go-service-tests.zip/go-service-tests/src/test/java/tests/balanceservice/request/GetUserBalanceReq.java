package tests.balanceservice.request;

import common.enumsconstants.ProductId;
import domain.ErrorResponse;

public class GetUserBalanceReq extends ErrorResponse {
	
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private GetUserBalanceParams Params;
	
	public GetUserBalanceReq(Builder builder) {
		ID = builder.id;
		Method = builder.method;
		Params = new GetUserBalanceParams(builder);
	}
	
	public static class Builder {
		
		private String id;
		private String method;
		private Integer user_id;
		private Integer product_id;
		private Boolean has_gbt_bonus;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder userId(Integer userId) {
			this.user_id = userId;
			return this;
		}
		
		public Builder productId(Integer productId) {
			this.product_id = productId;
			return this;
		}
		
		public Builder hasGbtBonus(Boolean hasGbtBonus) {
			this.has_gbt_bonus = hasGbtBonus;
			return this;
		}
		
		public Builder defaults() {
			method = "GetUserBalance";
			id = "defaultId";
			user_id = 4601572;
			product_id = ProductId.GAMES.getId();
			has_gbt_bonus = false;
			return this;
		}
		
		public GetUserBalanceReq build() {
			return new GetUserBalanceReq(this);
		}
	}
	
	private class GetUserBalanceParams {
		
		@SuppressWarnings("unused")
		private Integer user_id;
		@SuppressWarnings("unused")
		private Integer product_id;
		@SuppressWarnings("unused")
		private Boolean has_gbt_bonus;
		
		public GetUserBalanceParams(Builder builder) {
			this.user_id = builder.user_id;
			this.product_id = builder.product_id;
			this.has_gbt_bonus = builder.has_gbt_bonus;
		}
	}
}
