package tests.balanceservice.request;

import common.TransactionType;

public class GetLatestTransactionByTransactionTypeIdReq {

	@SuppressWarnings("unused")
	private String Method = "GetLatestTransactionByTransactionTypeId";
	@SuppressWarnings("unused")
	private GetLatestTransactionByTransactionTypeIdParams Params;

	public GetLatestTransactionByTransactionTypeIdReq(int userId, int providerRegionId,
			int partner_id, TransactionType transactionType) {
		Params = new GetLatestTransactionByTransactionTypeIdParams(userId, providerRegionId, partner_id, transactionType);
	}

	class GetLatestTransactionByTransactionTypeIdParams{

		@SuppressWarnings("unused")
		private int user_id, provider_region_id, partner_id, transaction_type_id;

		public GetLatestTransactionByTransactionTypeIdParams(int userId, int providerRegionId,
				int partner_id, TransactionType transactionType) {
			this.user_id = userId;
			this.provider_region_id = providerRegionId;
			this.partner_id = partner_id;
			this.transaction_type_id = transactionType.getValue();
		}
	}
}
