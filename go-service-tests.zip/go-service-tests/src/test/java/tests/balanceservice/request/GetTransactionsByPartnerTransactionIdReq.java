package tests.balanceservice.request;

public class GetTransactionsByPartnerTransactionIdReq {
	
	@SuppressWarnings("unused")
	private String Method = "GetTransactionsByPartnerTransactionID";
	@SuppressWarnings("unused")
	private GetTransactionsByPartnerTransactionIdParams Params;
	
	public GetTransactionsByPartnerTransactionIdReq(Integer userId, Integer providerRegionId,
			String partnerTransactionId) {
		Params = new GetTransactionsByPartnerTransactionIdParams(userId, providerRegionId, partnerTransactionId);
	}
	
	class GetTransactionsByPartnerTransactionIdParams {
		
		@SuppressWarnings("unused")
		private Integer user_id, provider_region_id;
		@SuppressWarnings("unused")
		private String partner_transaction_id;
		
		public GetTransactionsByPartnerTransactionIdParams(Integer userId, Integer providerRegionId,
				String partnerTransactionId) {
			this.user_id = userId;
			this.provider_region_id = providerRegionId;
			this.partner_transaction_id = partnerTransactionId;
		}
	}
}
