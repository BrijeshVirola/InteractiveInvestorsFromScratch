package tests.balanceservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.TransactionType;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.ServiceErrors;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.balanceservice.request.GetLatestTransactionByTransactionTypeIdReq;
import tests.balanceservice.response.GetLatestTransactionByTransactionTypeIdResp;

public class GetLatestTransactionByTransactionIdTests extends BaseClassSetup {
	@Test(description = "Get Latest Transaction By Transaction Id - Missing User Id 7")
	public void get_LatestTransactionByTransactionTypeId_Missing_UserId() {
		TransactionType transactionType = TransactionType.STAKE;
		
		int partnerId = 100;
		int providerRegionId = 20;
		GetLatestTransactionByTransactionTypeIdReq req = new GetLatestTransactionByTransactionTypeIdReq
				(0, providerRegionId, partnerId, transactionType);
		
		GetLatestTransactionByTransactionTypeIdResp actError = BaseRequest.getResponse(req, ResponseEndpoints.getLatestTransactionByTransactionTypeId);
		GetLatestTransactionByTransactionTypeIdResp expError =  new GetLatestTransactionByTransactionTypeIdResp(ServiceErrors.MISSING_REQUIRED_PARAM_USER_ID);
		
		assertReflectionEquals(expError, actError);
	}
	
	@Test(description = "Get Latest Transaction By Transaction Id - Missing Provider Region Id 7")
	public void get_LatestTransactionByTransactionTypeId_Missing_ProviderRegionId() {
		TransactionType transactionType = TransactionType.STAKE;
		
		int partnerId = 100;
		GetLatestTransactionByTransactionTypeIdReq req = new GetLatestTransactionByTransactionTypeIdReq
				(UsersId.GO_SVC_TESTS05, 0, partnerId, transactionType);
		
		GetLatestTransactionByTransactionTypeIdResp actError = BaseRequest.getResponse(req, ResponseEndpoints.getLatestTransactionByTransactionTypeId);
		GetLatestTransactionByTransactionTypeIdResp expError =  new GetLatestTransactionByTransactionTypeIdResp(ServiceErrors.MISSING_PROVIDER_REGION_ID);
		
		assertReflectionEquals(expError, actError);
	}
	
	@Test(description = "Get Latest Transaction By Transaction Id - Missing Partner Id 7")
	public void get_LatestTransactionByTransactionTypeId_Missing_PartnerId() {
		TransactionType transactionType = TransactionType.STAKE;
		
		GetLatestTransactionByTransactionTypeIdReq req = new GetLatestTransactionByTransactionTypeIdReq
				(UsersId.GO_SVC_TESTS05, 20, 0, transactionType);
		
		GetLatestTransactionByTransactionTypeIdResp actError = BaseRequest.getResponse(req, ResponseEndpoints.getLatestTransactionByTransactionTypeId);
		GetLatestTransactionByTransactionTypeIdResp expError =  new GetLatestTransactionByTransactionTypeIdResp(ServiceErrors.MISSING_REQUIRED_PARAM_PARTNER_ID);
		
		assertReflectionEquals(expError, actError);
	}
	
	@Test(description = "Get Latest Transaction By Transaction Id - Missing Transaction Type Id 7")
	public void get_LatestTransactionByTransactionTypeId_Missing_TransactionTypeId() {
		TransactionType transactionType = TransactionType.MISSING;
		
		int partnerId = 100;
		GetLatestTransactionByTransactionTypeIdReq req = new GetLatestTransactionByTransactionTypeIdReq
				(UsersId.GO_SVC_TESTS05, 20, partnerId, transactionType);
		
		GetLatestTransactionByTransactionTypeIdResp actError = BaseRequest.getResponse(req, ResponseEndpoints.getLatestTransactionByTransactionTypeId);
		GetLatestTransactionByTransactionTypeIdResp expError =  new GetLatestTransactionByTransactionTypeIdResp(ServiceErrors.MISSING_REQUIRED_PARAM_PARTNER_TRANSACTION_TYPE_ID);
		
		assertReflectionEquals(expError, actError);
	}
}
