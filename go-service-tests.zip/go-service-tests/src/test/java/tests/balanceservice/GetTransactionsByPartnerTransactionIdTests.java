package tests.balanceservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.Config;
import common.FlakeGenerator;
import common.TransactionType;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.ServiceErrors;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.balanceservice.request.AdjustBalanceReq;
import tests.balanceservice.request.GetTransactionsByPartnerTransactionIdReq;
import tests.balanceservice.response.AdjustBalanceResp;
import tests.balanceservice.response.GetTransactionsByPartnerTransactionIdResp;

public class GetTransactionsByPartnerTransactionIdTests extends BaseClassSetup {
	
	@DataProvider()
	private Object[] userId_providerRegionId() {
		return new Object[] {"0", "null"};
	}
	
	@Test(description = "Get Transactions By PartnerTransactionID - Stake and Return transactions")
	public void get_TransactionsByPartnerTransactionID() {
		
		//Create new stake transaction
		AdjustBalanceReq req = new AdjustBalanceReq
				.Builder()
				.defaults()
				.realAmount("0.00")
				.totalAmount("-0.15")
				.userId(UsersId.GO_SVC_TESTS04)
				.build();
		
		
		AdjustBalanceResp actResp = BaseRequest.getResponse(req, ResponseEndpoints.adjustBalance);

		String partner_transaction_id = actResp.getResult().getPartner_transaction_id();
		long getBet365_games_transaction_id = actResp.getResult().getBet365_games_transaction_id();
		
		int providerRegionId = 20;
		GetTransactionsByPartnerTransactionIdReq getTransactionsByPartnerTransactionID = new GetTransactionsByPartnerTransactionIdReq
				(UsersId.GO_SVC_TESTS04, providerRegionId, partner_transaction_id);
		
		GetTransactionsByPartnerTransactionIdResp actResponse = BaseRequest.getResponse(getTransactionsByPartnerTransactionID, ResponseEndpoints.getTransactionsByPartnerTransactionID);
		GetTransactionsByPartnerTransactionIdResp expResponse = new GetTransactionsByPartnerTransactionIdResp(req, actResp);
		assertReflectionEquals(expResponse, actResponse);
		
		//Create new return transaction
		long newFlakeId = FlakeGenerator.nextId(Config.nodeId);
		req = new AdjustBalanceReq.Builder()
				.defaults()
				.transactionType(TransactionType.RETURN)
				.realAmount("1.16")
				.totalAmount("1.16")
				.flakeId(newFlakeId)
				.sourceBet365GamesTransactionIid(getBet365_games_transaction_id)
				.partnerTransactionId(partner_transaction_id)
				.userId(UsersId.GO_SVC_TESTS04)
				.build();
		actResp = BaseRequest.getResponse(req, ResponseEndpoints.adjustBalance);

		partner_transaction_id = actResp.getResult().getPartner_transaction_id();

		getTransactionsByPartnerTransactionID = new GetTransactionsByPartnerTransactionIdReq(UsersId.GO_SVC_TESTS04, providerRegionId, partner_transaction_id);

		actResponse = BaseRequest.getResponse(getTransactionsByPartnerTransactionID, ResponseEndpoints.getTransactionsByPartnerTransactionID);
		expResponse.addTransaction(req, actResp);
		assertReflectionEquals(expResponse, actResponse);
	}
	
	@Test(description = "Get Transactions By PartnerTransactionID - Missing Partner Transaction 7")
	public void get_TransactionsByPartnerTransactionID_missing_PartnerTransaction() {
		
		GetTransactionsByPartnerTransactionIdReq req = new GetTransactionsByPartnerTransactionIdReq
				(UsersId.GO_SVC_TESTS04, 25, "");
		
		GetTransactionsByPartnerTransactionIdResp actError = BaseRequest.getResponse(req, ResponseEndpoints.getTransactionsByPartnerTransactionID);
		GetTransactionsByPartnerTransactionIdResp expError =  new GetTransactionsByPartnerTransactionIdResp(ServiceErrors.MISSING_REQUIRED_PARAM_PARTNER_TRANSACTION_ID);
		
		assertReflectionEquals(expError, actError);
	}
	
	@Test(description = "Get Transactions By PartnerTransactionID - Missing Provider Region 7", dataProvider = "userId_providerRegionId")
	public void get_TransactionsByPartnerTransactionID_missing_ProviderRegion(String provider_region_id) {
		
		
		Integer providerRegionID = provider_region_id.equals("null") ? null : Integer.parseInt(provider_region_id);
		GetTransactionsByPartnerTransactionIdReq req = new GetTransactionsByPartnerTransactionIdReq
				(UsersId.GO_SVC_TESTS04, providerRegionID, "Transaction9712519447389682");
		
		GetTransactionsByPartnerTransactionIdResp actError = BaseRequest.getResponse(req, ResponseEndpoints.getTransactionsByPartnerTransactionID);
		GetTransactionsByPartnerTransactionIdResp expError =  new GetTransactionsByPartnerTransactionIdResp(ServiceErrors.MISSING_PROVIDER_REGION_ID);
		
		assertReflectionEquals(expError, actError);
	}
	
	@Test(description = "Get Transactions By PartnerTransactionID - Missing User Id 7", dataProvider = "userId_providerRegionId")
	public void get_Transactions_ByPartnerTransactionID_missing_UserId(String user_id) {
		
		Integer userId = user_id.equals("null") ? null : Integer.parseInt(user_id);
		GetTransactionsByPartnerTransactionIdReq req = new GetTransactionsByPartnerTransactionIdReq
				(userId, 20, "Transaction9712519447389682");
		
		GetTransactionsByPartnerTransactionIdResp actError = BaseRequest.getResponse(req, ResponseEndpoints.getTransactionsByPartnerTransactionID);
		GetTransactionsByPartnerTransactionIdResp expError =  new GetTransactionsByPartnerTransactionIdResp(ServiceErrors.MISSING_REQUIRED_PARAM_USER_ID);
		
		assertReflectionEquals(expError, actError);
	}
}
