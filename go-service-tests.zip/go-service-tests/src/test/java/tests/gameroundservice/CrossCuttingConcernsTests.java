package tests.gameroundservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.enumsconstants.ServiceErrors;
import domain.BaseRequest;
import io.restassured.response.Response;
import tests.gameroundservice.response.GameRoundResp;

public class CrossCuttingConcernsTests extends BaseClassSetup {
	@Test(dataProvider = "methodNameProvider")
	public void request_Is_Get_Not_Post_When_MethodRequested_Then_TheExpectedErrorIsReturned(String method) {

		Response response = BaseRequest.callEmptyBodyRequest(baseUriGameRoundService, method,
				true, true, false);
		
		GameRoundResp actError = response.as(GameRoundResp.class);
		GameRoundResp expError =  new GameRoundResp(ServiceErrors.NOT_HTTP_POST);

		assertReflectionEquals(expError, actError);
	}

	@Test(dataProvider = "methodNameProvider")
	public void no_Accept_Header_Is_Set_When_MethodRequested_Then_TheExpectedErrorIsReturned(String method) {

		Response response = BaseRequest.callEmptyBodyRequest(baseUriGameRoundService, method, false, true, true);
		
		GameRoundResp actError = response.as(GameRoundResp.class);
		GameRoundResp expError =  new GameRoundResp(ServiceErrors.THE_ACCEPT_HEADER_WAS_MISSING_OR_INVALID);

		assertReflectionEquals(expError, actError);
	}

	@Test(dataProvider = "methodNameProvider")
	public void no_Content_Type_Header_Is_Set_When_MethodRequested_Then_TheExpectedErrorIsReturned(String method) {
		
		Response response = BaseRequest.callEmptyBodyRequest(baseUriGameRoundService, method, true, false, true);

		GameRoundResp actError = response.as(GameRoundResp.class);
		GameRoundResp expError =  new GameRoundResp(ServiceErrors.THE_CONTENT_TYPE_HEADER_WAS_MISSING_OR_INVALID);

		assertReflectionEquals(expError, actError);
	}

	@DataProvider(name = "methodNameProvider")
	public Object[] getMethodNames() {
		return new Object[] { "getgameroundbyid", "getgameround", "getgameroundbypartnergameroundid", "creategameround",
				"closegameroundbybet365gameroundid", "insertrngdetails", };
	}
}
