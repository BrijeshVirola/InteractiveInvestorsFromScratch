package tests.gameroundservice;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import common.BaseClassSetup;
import tests.gameroundservice.request.GameRoundRequest;
import tests.gameroundservice.response.GameRoundResp;

public class GameRoundTestsBase extends BaseClassSetup {
	
	protected GameRoundResp currentGameRound;
	protected int requestedUserId = 100017904;
	protected int requestedPartnerId = 100; // TODO(MB) Check CogenaWhiteLabelUK is valid
	protected int requestedRegulatedGameId = 6403;
	protected int requestedProviderRegionId = 20;
	
	@BeforeClass(alwaysRun = true)
	public void setup() {
		String requestedPartnerGameRoundId = UUID.randomUUID().toString();
		
		GameRoundResp response = GameRoundRequest.createGameRound(requestedUserId,
												   requestedPartnerGameRoundId,
												   requestedPartnerId,
												   requestedRegulatedGameId,
												   requestedProviderRegionId);
		
		assertThat("Partner game round id", response.getResult().getPartnerGameRoundId(), equalTo(requestedPartnerGameRoundId));
		currentGameRound = response;
	}

	@AfterClass(alwaysRun = true)
	public void teardown() {
		
		GameRoundResp closeResponse = GameRoundRequest.closeGameRoundBybet365GameRoundId(currentGameRound);
		currentGameRound.setEndDateAndCloseReason(closeResponse);
		
		assertReflectionEquals(currentGameRound, closeResponse);
	}
}
