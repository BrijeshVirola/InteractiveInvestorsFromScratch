package tests.gameroundservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.TimeUtils;
import common.enumsconstants.ServiceErrors;
import tests.gameroundservice.request.GameRoundRequest;
import tests.gameroundservice.response.GameRoundResp;

public class CreateGameRoundTests extends GameRoundTestsBase {
	@Test
	public void gameRoundId_Too_Long_When_CreateGameRound_Then_TheExpectedErrorIsReturned() {

		String partnerGameRoundId = "3583594F-4B88-4947-843B-A521AD5E496E-3583594F-4B88-4947-843B-A521AD5E496E-3583594F-4B88-4947-843B-A521AD5E496E";
		
		GameRoundResp response = GameRoundRequest.createGameRound(requestedUserId,
				partnerGameRoundId,
				requestedPartnerId,
				requestedRegulatedGameId,
				requestedProviderRegionId);
		
		GameRoundResp expResponse = new GameRoundResp(ServiceErrors.GameRound.PARTNER_GAME_ROUND_ID_LENGTH_OUT_OF_BOUNDS);
		
		assertReflectionEquals(expResponse, response);
	}

	@Test
	public void invalid_ChannelId_When_CreateGameRound_Then_TheExpectedErrorIsReturned() {

		String currentTime = TimeUtils.getCurrentTimeAsIsoString();
		String partnerGameRoundId = "Test-" + currentTime;
		int channelId = -10001;
		
		GameRoundResp response = GameRoundRequest.createGameRound(requestedUserId,
				partnerGameRoundId,
				requestedPartnerId,
				requestedRegulatedGameId,
				requestedProviderRegionId,
				channelId);
		
		GameRoundResp expResponse = new GameRoundResp(ServiceErrors.CHANNEL_ID_INVALID);
		
		assertReflectionEquals(expResponse, response);
	}
}
