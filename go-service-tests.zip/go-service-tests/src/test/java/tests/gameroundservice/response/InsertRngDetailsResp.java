package tests.gameroundservice.response;

import common.enumsconstants.Errors;
import domain.ErrorResponse;

public class InsertRngDetailsResp extends ErrorResponse {
	
	@SuppressWarnings("unused")
	private String id = null;
	@SuppressWarnings("unused")
	private String result;
	
	public InsertRngDetailsResp() {
		result = "OK";
	}
		
	public InsertRngDetailsResp(Errors error) {
		super(error);
	}

}
