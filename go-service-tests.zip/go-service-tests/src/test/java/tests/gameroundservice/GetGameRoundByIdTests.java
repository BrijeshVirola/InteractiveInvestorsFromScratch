package tests.gameroundservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import tests.gameroundservice.request.GameRoundRequest;
import tests.gameroundservice.response.GameRoundResp;

public class GetGameRoundByIdTests extends GameRoundTestsBase {
	
	@Test(description = "GameRound - GetGameRoundById.")
	public void valid_GameRound_When_GetGameRoundById_Then_TheExpectedResultsAreObtained() {

		GameRoundResp actGameRound = GameRoundRequest.getGameRoundById(currentGameRound.getResult().getId());
		
		assertReflectionEquals(currentGameRound, actGameRound);
	}
}
