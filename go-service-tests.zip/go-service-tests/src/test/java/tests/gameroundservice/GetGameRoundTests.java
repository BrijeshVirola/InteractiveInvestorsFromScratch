package tests.gameroundservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.enumsconstants.ServiceErrors;
import tests.gameroundservice.request.GameRoundRequest;
import tests.gameroundservice.response.GameRoundResp;

public class GetGameRoundTests extends GameRoundTestsBase {
	@Test(description = "GameRound - GetGameRound.")
	public void valid_GameRound_When_GetGameRound_Then_TheExpectedResultsAreObtained() {

		String bet365GameRoundId = currentGameRound.getResult().getBet365GameRoundId();
		GameRoundResp actGameRound = GameRoundRequest.getGameRound(requestedUserId, bet365GameRoundId);

		assertReflectionEquals(currentGameRound, actGameRound);
	}
	
	@Test
	public void invalid_UserId_When_GetGameRound_Then_TheExpectedErrorIsReturned() {

		String bet365GameRoundId = "3583594F-4B88-4947-843B-A521AD5E496E";
		int userId = 0;
		
		GameRoundResp actGameRound = GameRoundRequest.getGameRound(userId, bet365GameRoundId);
		GameRoundResp expGameRound = new GameRoundResp(ServiceErrors.MISSING_REQUIRED_PARAM_USER_ID);

		assertReflectionEquals(expGameRound, actGameRound);
	}
	
	@Test
	public void invalid_Bet365GameRoundId_When_GetGameRound_Then_TheExpectedErrorIsReturned() {

		int userId = 100017904;
		String invalidBet365GameRoundId = "dd849a40-231b-4ac8-94c2-864b58eb8759";
		
		GameRoundResp actGameRound = GameRoundRequest.getGameRound(userId, invalidBet365GameRoundId);
		GameRoundResp expGameRound = new GameRoundResp(ServiceErrors.GameRound.GAME_ROUND_NOT_FOUND);

		assertReflectionEquals(expGameRound, actGameRound);
	}
}
