package tests.gameroundservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import tests.gameroundservice.request.GameRoundRequest;
import tests.gameroundservice.response.InsertRngDetailsResp;

public class InsertRngDetailsTests extends GameRoundTestsBase {

	@Test
	public void valid_Inputs_When_InsertRngDetails_Then_TheExpectedResultsAreObtained() {
		
		long gameRoundId = 486;
		
		InsertRngDetailsResp actGameRound = GameRoundRequest.insertRngDetails(gameRoundId);
		InsertRngDetailsResp expGameRound = new InsertRngDetailsResp();
	
		assertReflectionEquals(expGameRound, actGameRound);
	}
}
