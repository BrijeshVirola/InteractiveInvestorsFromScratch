package tests.gameroundservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import tests.gameroundservice.request.GameRoundRequest;
import tests.gameroundservice.response.GameRoundResp;

public class GetGameRoundByPartnerGameRoundIdTests extends GameRoundTestsBase {
	@Test
	public void valid_Inputs_When_GetGameRoundByPartnerGameRoundId_Then_TheExpectedResultsAreObtained() {

		String partnerGameRoundId = currentGameRound.getResult().getPartnerGameRoundId();

		
		GameRoundResp actGameRound = GameRoundRequest.getGameRoundByPartnerGameRoundId(requestedUserId,
				partnerGameRoundId,
				requestedPartnerId,
				currentGameRound.getResult().getProviderRegionId());

		assertReflectionEquals(currentGameRound, actGameRound);
	}
}
