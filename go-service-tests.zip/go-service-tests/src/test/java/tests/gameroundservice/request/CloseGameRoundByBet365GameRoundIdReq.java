package tests.gameroundservice.request;

import common.TimeUtils;
import tests.gameroundservice.response.GameRoundResp;

public class CloseGameRoundByBet365GameRoundIdReq {
	
	@SuppressWarnings("unused")
	private String Method = "closegameroundbybet365gameroundid";
	@SuppressWarnings("unused")
	private String id = "1";
	@SuppressWarnings("unused")
	private CloseGameRoundByBet365GameRoundIdParams Params;
	
	public CloseGameRoundByBet365GameRoundIdReq(int userId, String bet365GameRoundId) {
		
		Params = new CloseGameRoundByBet365GameRoundIdParams(userId, bet365GameRoundId);
	}
	
	public CloseGameRoundByBet365GameRoundIdReq(GameRoundResp resp) {
		this(resp.getResult().getUserid(), resp.getResult().getBet365GameRoundId());
	}
	
	class CloseGameRoundByBet365GameRoundIdParams {
		
		@SuppressWarnings("unused")
		private int user_id, closed_reason_id;
		@SuppressWarnings("unused")
		private String bet365_game_round_id, partner_end_timestamp_utc;
		
		public CloseGameRoundByBet365GameRoundIdParams(int userId, String bet365GameRoundId) {
			
			this.user_id = userId;
			this.bet365_game_round_id = bet365GameRoundId;
			this.partner_end_timestamp_utc = TimeUtils.getCurrentTimeAsIsoString();
			this.closed_reason_id = 1;
		}
	}
}
