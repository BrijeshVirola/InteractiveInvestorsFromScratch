package tests.gameroundservice.request;

public class GetGameRoundByPartnerGameRoundIdReq {
	
	@SuppressWarnings("unused")
	private String Method = "getgameroundbypartnergameroundid";
	@SuppressWarnings("unused")
	private String id = "1";
	@SuppressWarnings("unused")
	private GetGameRoundByPartnerGameRoundIdParams Params;
	
	public GetGameRoundByPartnerGameRoundIdReq(int userId, String partnerGameRoundId, int partnerId, int providerRegionId) {
		Params = new GetGameRoundByPartnerGameRoundIdParams(userId, partnerGameRoundId, partnerId, providerRegionId);
	}
	
	class GetGameRoundByPartnerGameRoundIdParams {
		
		@SuppressWarnings("unused")
		private int user_id, partner_id, provider_region_id;
		@SuppressWarnings("unused")
		private String partner_game_round_id;
		
		public GetGameRoundByPartnerGameRoundIdParams(int userId, String partnerGameRoundId, int partnerId, int providerRegionId) {
			this.user_id = userId;
			this.partner_game_round_id = partnerGameRoundId;
			this.partner_id = partnerId;
			this.provider_region_id = providerRegionId;
		}
	}
}
