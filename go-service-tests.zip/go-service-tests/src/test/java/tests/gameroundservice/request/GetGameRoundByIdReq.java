package tests.gameroundservice.request;

public class GetGameRoundByIdReq {
	
	@SuppressWarnings("unused")
	private String Method = "getgameroundbyid";
	@SuppressWarnings("unused")
	private String id = "1";
	@SuppressWarnings("unused")
	private GetGameRoundByIdParams Params;
	
	public GetGameRoundByIdReq(int gameRoundId) {
		Params = new GetGameRoundByIdParams(gameRoundId);
	}
	
	class GetGameRoundByIdParams {
		
		@SuppressWarnings("unused")
		private long id;
		
		public GetGameRoundByIdParams(int gameRoundId) {
			this.id = gameRoundId;
		}
	}

}
