package tests.common.response;

public class ResultOKResp {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String result;
	
	private ResultOKResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public static class Builder {
		private String id, result;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder result(String result) {
			this.result = result;
			return this;
		}
		
		public Builder defaults() {
			this.id = "defaultTestId";
			this.result = "OK";
			return this;
		}
		
		public ResultOKResp build() {
			return new ResultOKResp(this);
		}	
	}
}
