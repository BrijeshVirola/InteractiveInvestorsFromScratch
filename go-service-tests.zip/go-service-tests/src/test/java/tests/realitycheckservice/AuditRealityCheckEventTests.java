package tests.realitycheckservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.realitycheckservice.request.AuditRealityCheckEventReq;
import tests.realitycheckservice.response.AuditRealityCheckEventResp;
public class AuditRealityCheckEventTests extends BaseClassSetup{
	
	@Test(description = "Make a request to AuditRealityCheckEvent. Positive scenario.")
	public void auditRealityCheckEvent_Positive_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		AuditRealityCheckEventReq request = new AuditRealityCheckEventReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		AuditRealityCheckEventResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.auditRealityCheckEventSuccess);
		
		AuditRealityCheckEventResp expectedResponse =  new AuditRealityCheckEventResp.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId)
											.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to AuditRealityCheckEvent for an unknown audit event")
	public void auditRealityCheckEvent_unknownAuditEvent_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		AuditRealityCheckEventReq request = new AuditRealityCheckEventReq.Builder()
										.defaults()
										.auditEvent("UNKNOWN")
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.auditRealityCheckEventError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1007)
				.message("Unknown audit event")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to AuditRealityCheckEvent. Missing user_id parameter.")
	public void auditRealityCheckEvent_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		AuditRealityCheckEventReq request = new AuditRealityCheckEventReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.userId(null)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.auditRealityCheckEventError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to auditRealityCheckEvent. Wrong method.")
	public void auditRealityCheckEvent_Wrong_Method() {
		
		AuditRealityCheckEventReq request = new AuditRealityCheckEventReq.Builder()
										.defaults()
										.id(null)
										.method("INVALID_METHOD_NAME")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.auditRealityCheckEventError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
