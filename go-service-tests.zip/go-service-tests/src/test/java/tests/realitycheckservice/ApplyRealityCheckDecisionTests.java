package tests.realitycheckservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.time.Duration;
import java.time.Instant;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import common.testtoken.response.CreateUserSessionTestResp;
import domain.BaseRequest;
import tests.realitycheckservice.request.ApplyRealityCheckDecisionReq;
import tests.realitycheckservice.request.GetRealityCheckDetailsReq;
import tests.realitycheckservice.response.ApplyRealityCheckDecisionResp;
import tests.realitycheckservice.response.GetRealityCheckDetailsResp;
public class ApplyRealityCheckDecisionTests extends BaseClassSetup{
	
	@Test(description = "Make a request to ApplyRealityCheckDecision. Choice of 'continue' and confirm it remains active. Positive scenario.")
	public void applyRealityCheckDecision_choiceOfContinue_Positive_Scenario() throws InterruptedException {
	    
		Integer intervalInMinutes = 1;
		Integer triggerNextRealityCheckInSeconds = 60;
		CreateUserSessionTestResp sessionResponse = Session.createSession(intervalInMinutes, triggerNextRealityCheckInSeconds);
		Instant sessionCreationTime = Instant.now();
		
		TimeUnit.SECONDS.sleep(3);
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		ApplyRealityCheckDecisionReq request = new ApplyRealityCheckDecisionReq.Builder()
										.defaults()
										.sessionId(sessionResponse.getSessionId())
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		
		ApplyRealityCheckDecisionResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.applyRealityCheckDecisionSuccess);
		ApplyRealityCheckDecisionResp expectedResponse = new ApplyRealityCheckDecisionResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
		
		GetRealityCheckDetailsReq checkDetailsRequest = new GetRealityCheckDetailsReq.Builder()
				.defaults()
				.sessionId(sessionResponse.getSessionId())
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		TimeUnit.SECONDS.sleep(3);
		GetRealityCheckDetailsResp actualCheckDetailsResponse =  BaseRequest.getResponse(checkDetailsRequest, ResponseEndpoints.getRealityCheckDetailsSuccess);

		Instant actionsCompleteTime = Instant.now().plusSeconds(1);// add 1 second to allow for rounding up to nearest second in the service
		Integer intervalInSeconds = intervalInMinutes * 60;
		Assert.assertEquals(actualCheckDetailsResponse.realityCheckStatus(), "NotDue", "reality_check_status assertion failure");
		Assert.assertEquals(actualCheckDetailsResponse.intervalInSecs(), intervalInSeconds, "interval_in_secs assertion failure");
		
		Integer secsSinceLogin = actualCheckDetailsResponse.secsSinceLogin();
		long timeSinceSessionCreated = Duration.between(sessionCreationTime, actionsCompleteTime).toMillis() / 1000;
		Assert.assertTrue(secsSinceLogin <= timeSinceSessionCreated, 
				"secs_since_login assertion failure, secs_since_login = " + secsSinceLogin + "timeSinceSessionCreated = " + timeSinceSessionCreated);
		Assert.assertTrue(secsSinceLogin >= 0, "secs_since_login was less than zero");
		Assert.assertTrue(secsSinceLogin > actualCheckDetailsResponse.secsSinceLastAlert(), "secs_since_login was not greater than secs_since_last_alert assertion failure");
		
		Integer sumOfAlertFields = actualCheckDetailsResponse.secsSinceLastAlert() + actualCheckDetailsResponse.secsUntilNextAlert();
		Assert.assertEquals(sumOfAlertFields, actualCheckDetailsResponse.intervalInSecs(), "alert field timings assertion failure");
		Assert.assertEquals(actualCheckDetailsResponse.id(), idForRequestToBeEchoedBackInResponseId, "id assertion failure");
		
	}
	
	@Test(description = "Make a request to ApplyRealityCheckDecision. Choice of 'Logout' and confirm session has ended. Positive scenario.")
	public void applyRealityCheckDecision_choiceOfLogout_Positive_Scenario() {
	    
		Integer intervalInMinutes = 1;
		Integer triggerNextRealityCheckInSeconds = 60;
		CreateUserSessionTestResp sessionResponse = Session.createSession(intervalInMinutes, triggerNextRealityCheckInSeconds);
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		ApplyRealityCheckDecisionReq request = new ApplyRealityCheckDecisionReq.Builder()
										.defaults()
										.choice("Logout")
										.sessionId(sessionResponse.getSessionId())
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		ApplyRealityCheckDecisionResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.applyRealityCheckDecisionSuccess);
		ApplyRealityCheckDecisionResp expectedResponse = new ApplyRealityCheckDecisionResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
		
		GetRealityCheckDetailsReq checkDetailsRequest = new GetRealityCheckDetailsReq.Builder()
															.defaults()
															.sessionId(sessionResponse.getSessionId())
															.id(idForRequestToBeEchoedBackInResponseId)
															.build();

		CustomErrorResponse actualCheckDetailsResponse =  BaseRequest.getResponse(checkDetailsRequest, ResponseEndpoints.getRealityCheckDetailsError);

		CustomErrorResponse expectedCheckDetailsResponse = new CustomErrorResponse.Builder()
																.code(1001)
																.message("Session not found")
																.id(idForRequestToBeEchoedBackInResponseId)
																.build();
		assertReflectionEquals(expectedCheckDetailsResponse, actualCheckDetailsResponse);
		
	}
	
	@Test(description = "Make a request to ApplyRealityCheckDecision for an unknown session")
	public void applyRealityCheckDecision_unknownSession_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		ApplyRealityCheckDecisionReq request = new ApplyRealityCheckDecisionReq.Builder()
										.defaults()
										.sessionId("UNKNOWN")
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.applyRealityCheckDecisionError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1001)
				.message("Session not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to ApplyRealityCheckDecision. Missing session_id parameter.")
	public void applyRealityCheckDecision_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString(); 
		
		ApplyRealityCheckDecisionReq request = new ApplyRealityCheckDecisionReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.sessionId(null)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.applyRealityCheckDecisionError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: session_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to ApplyRealityCheckDecision. Wrong method.")
	public void applyRealityCheckDecision_Wrong_Method() {
		
		ApplyRealityCheckDecisionReq request = new ApplyRealityCheckDecisionReq.Builder()
										.defaults()
										.id(null)
										.method("INVALID_METHOD_NAME")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.applyRealityCheckDecisionError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
