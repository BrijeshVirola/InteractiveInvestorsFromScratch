package tests.realitycheckservice.request;

import java.util.HashMap;
import java.util.Map;

public class AuditRealityCheckEventReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private AuditRealityCheckEventReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
		this.params.put("audit_event", builder.audit_event);
	}

	public static class Builder {
		private String id, method, audit_event;
		private Integer user_id;
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
	
		public Builder auditEvent(String audit_event) {
			this.audit_event = audit_event;
			return this;
		}
	
		public Builder defaults() {
			this.method = "AuditRealityCheckEvent";
			this.id = "1";
			this.user_id = 54633;
			this.audit_event = "Blocked";
			return this;
		}

		public AuditRealityCheckEventReq build() {
			return new AuditRealityCheckEventReq(this);
		}
	}
}

