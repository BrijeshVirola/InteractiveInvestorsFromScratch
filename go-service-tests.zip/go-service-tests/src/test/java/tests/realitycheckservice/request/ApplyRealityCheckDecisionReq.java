package tests.realitycheckservice.request;

import java.util.HashMap;
import java.util.Map;

public class ApplyRealityCheckDecisionReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private ApplyRealityCheckDecisionReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("session_id", builder.session_id);
		this.params.put("choice", builder.choice);
	}

	public static class Builder {
		private String id, method, session_id, choice;
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
	
		public Builder sessionId(String session_id) {
			this.session_id = session_id;
			return this;
		}
	
		public Builder choice(String choice) {
			this.choice = choice;
			return this;
		}
	
		public Builder defaults() {
			this.method = "ApplyRealityCheckDecision";
			this.id = "1";
			this.session_id = "thisFieldExpiresAfter24HoursYouWillNeedToCreateANewOne";
			this.choice = "Continue";
			return this;
		}

		public ApplyRealityCheckDecisionReq build() {
			return new ApplyRealityCheckDecisionReq(this);
		}
	}
}

