package tests.realitycheckservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetRealityCheckDetailsReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private GetRealityCheckDetailsReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("session_id", builder.session_id);
	}

	public static class Builder {
		private String id, method, session_id;
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
	
		public Builder sessionId(String session_id) {
			this.session_id = session_id;
			return this;
		}
	
		public Builder defaults() {
			this.method = "GetRealityCheckDetails";
			this.id = "1";
			this.session_id = "thisFieldExpiresAfter24HoursYouWillNeedToCreateANewOne";
			return this;
		}

		public GetRealityCheckDetailsReq build() {
			return new GetRealityCheckDetailsReq(this);
		}
	}
}

