package tests.realitycheckservice;

import common.enumsconstants.ResponseEndpoints;
import common.testtoken.request.CreateUserSessionTestReq;
import common.testtoken.response.CreateUserSessionTestResp;
import domain.BaseRequest;

public class Session {
	public static CreateUserSessionTestResp createSession(Integer intervalInMinutes, Integer triggerNextRealityCheckInSeconds) {
	
		CreateUserSessionTestReq createUserSessionTestRequest = new CreateUserSessionTestReq.Builder()
																	.defaults()
																	.realityCheckInterval(intervalInMinutes)
																	.realityCheckSecondsUntil(triggerNextRealityCheckInSeconds)
																	.build();

		CreateUserSessionTestResp sessionResponse = BaseRequest.getResponse(createUserSessionTestRequest, ResponseEndpoints.createUserSessionTestSuccess);
		
		return sessionResponse;
	}
}
