package tests.realitycheckservice.response;

public class GetRealityCheckDetailsResp {
	private String id;
	private Result result;

	private GetRealityCheckDetailsResp(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}

	public String id() {
		return id;
	}
	
	public String realityCheckStatus() {
		return result.reality_check_status;
	}
	
	public Integer intervalInSecs() {
		return result.interval_in_secs;
	}
	
	public Integer secsSinceLastAlert() {
		return result.secs_since_last_alert;
	}
	
	public Integer secsUntilNextAlert() {
		return result.secs_until_next_alert;
	}
	
	public Integer secsSinceLogin() {
		return result.secs_since_login;
	}
	
	public static class Builder {
		private String id, reality_check_status;
		private Integer interval_in_secs, secs_since_last_alert, secs_until_next_alert, secs_since_login;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder realityCheckStatus(String reality_check_status) {
			this.reality_check_status = reality_check_status;
			return this;
		}

		public Builder intervalInSecs(Integer interval_in_secs) {
			this.interval_in_secs = interval_in_secs;
			return this;
		}

		public Builder secsSinceLastAlert(Integer secs_since_last_alert) {
			this.secs_since_last_alert = secs_since_last_alert;
			return this;
		}

		public Builder secsUntilNextAlert(Integer secs_until_next_alert) {
			this.secs_until_next_alert = secs_until_next_alert;
			return this;
		}

		public Builder secsSinceLogin(Integer secs_since_login) {
			this.secs_since_login = secs_since_login;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			this.reality_check_status = "Due";
			this.interval_in_secs = 60000;
			this.secs_since_last_alert = 60057;
			this.secs_until_next_alert = 0;
			this.secs_since_login = 257;
			return this;
		}

		public GetRealityCheckDetailsResp build() {
			return new GetRealityCheckDetailsResp(this);
		}
	}

	private class Result {

		String reality_check_status;
		Integer interval_in_secs;
		Integer secs_since_last_alert;
		Integer secs_until_next_alert;
		Integer secs_since_login;

		public Result(Builder builder) {
			this.reality_check_status = builder.reality_check_status;
			this.interval_in_secs = builder.interval_in_secs;
			this.secs_since_last_alert = builder.secs_since_last_alert;
			this.secs_until_next_alert = builder.secs_until_next_alert;
			this.secs_since_login = builder.secs_since_login;
		}
	}
}