package tests.realitycheckservice.response;

public class AuditRealityCheckEventResp {
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String result;
	
	private AuditRealityCheckEventResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}

	public static class Builder {
		private String id;
		private String result;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder result(String result) {
			this.result = result;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.result = "OK";
			return this;
		}
		
		public AuditRealityCheckEventResp build() {
			return new AuditRealityCheckEventResp(this);
		}
	}
}
