package tests.realitycheckservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.time.Duration;
import java.time.Instant;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import common.testtoken.response.CreateUserSessionTestResp;
import domain.BaseRequest;
import tests.realitycheckservice.request.GetRealityCheckDetailsReq;
import tests.realitycheckservice.response.GetRealityCheckDetailsResp;
public class GetRealityCheckDetailsTests extends BaseClassSetup{
	
	@Test(description = "Make a request to GetRealityCheckDetails. Check status not yet due. Positive scenario.")
	public void getRealityCheckDetails_checkStatusNotDue_Positive_Scenario() throws InterruptedException {

		Integer intervalInMinutes = 1;
		Integer triggerNextRealityCheckInSeconds = 60;
		CreateUserSessionTestResp sessionResponse = Session.createSession(intervalInMinutes, triggerNextRealityCheckInSeconds);
		Instant loginRequestTime = Instant.now();
		
		String sessionId = sessionResponse.getSessionId();

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetRealityCheckDetailsReq request = new GetRealityCheckDetailsReq.Builder()
										.defaults()
										.sessionId(sessionId)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		GetRealityCheckDetailsResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getRealityCheckDetailsSuccess);
		
		Instant actionsCompleteTime = Instant.now().plusSeconds(1); // allow for rounding up to nearest second in the service
		Integer intervalInSeconds = intervalInMinutes * 60;
		Integer intervalInSecsResp = actualResponse.intervalInSecs();
		Integer secsSinceLoginResp = actualResponse.secsSinceLogin();
		Integer secsSinceLastAlertResp = actualResponse.secsSinceLastAlert();
		Integer secsUntilNextAlertResp = actualResponse.secsUntilNextAlert();
		String realityCheckStatusResp = actualResponse.realityCheckStatus();
		Integer sumOfAlerts = secsSinceLastAlertResp + secsUntilNextAlertResp;
		long timeSinceStartOfLoginRequest = Duration.between(loginRequestTime, actionsCompleteTime).toMillis() / 1000;
		
		Assert.assertEquals(realityCheckStatusResp, "NotDue", "reality_check_status assertion failure");
		Assert.assertEquals(intervalInSecsResp, intervalInSeconds, "interval_in_secs assertion failure");
		Assert.assertTrue(secsSinceLoginResp <= timeSinceStartOfLoginRequest, "secs_since_login assertion failure");
		Assert.assertTrue(secsSinceLoginResp >= 0, "secs_since_login assertion failure");
		Assert.assertEquals(secsSinceLoginResp, secsSinceLastAlertResp, "secs_since_login and secs_since_last_alert are not equal assertion failure");
		Assert.assertTrue(intervalInSecsResp >= secsUntilNextAlertResp, "interval_in_seconds greater than secs_until_next_alert assertion failure");
		Assert.assertEquals(sumOfAlerts, intervalInSecsResp);
		Assert.assertEquals(actualResponse.id(), idForRequestToBeEchoedBackInResponseId);
	}
	
	@Test(description = "Make a request to GetRealityCheckDetails. Check status due. Positive scenario.")
	public void getRealityCheckDetails_checkStatusDue_Positive_Scenario() throws InterruptedException {

		Integer intervalInMinutes = 1;
		Integer triggerNextRealityCheckInSeconds = 1;
		CreateUserSessionTestResp sessionResponse = Session.createSession(intervalInMinutes, triggerNextRealityCheckInSeconds);
		
		Instant loginRequestTime = Instant.now();
		
		TimeUnit.SECONDS.sleep(2);// wait for the trigger to change the state to change to DUE
		
		String sessionId = sessionResponse.getSessionId();

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetRealityCheckDetailsReq request = new GetRealityCheckDetailsReq.Builder()
										.defaults()
										.sessionId(sessionId)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		
		GetRealityCheckDetailsResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getRealityCheckDetailsSuccess);
		
		Instant actionsCompleteTime = Instant.now().plusSeconds(1); // allow for rounding up to nearest second in the service
		Integer intervalInSeconds = intervalInMinutes * 60;
		Integer intervalInSecsResp = actualResponse.intervalInSecs();
		Integer secsSinceLoginResp = actualResponse.secsSinceLogin();
		Integer secsSinceLastAlertResp = actualResponse.secsSinceLastAlert();
		Integer secsUntilNextAlertResp = actualResponse.secsUntilNextAlert();
		String realityCheckStatusResp = actualResponse.realityCheckStatus();
		long timeSinceStartOfLoginRequest = Duration.between(loginRequestTime, actionsCompleteTime).toMillis() / 1000;
		
		Assert.assertEquals(realityCheckStatusResp, "Due", "reality_check_status assertion failure");
		Assert.assertEquals(intervalInSecsResp, intervalInSeconds, "interval_in_secs assertion failure");
		Assert.assertTrue(secsSinceLoginResp <= timeSinceStartOfLoginRequest, "secs_since_login assertion failure");
		Assert.assertTrue(secsSinceLoginResp >= 0, "secs_since_login assertion failure");
		Assert.assertTrue(secsSinceLastAlertResp >= intervalInSecsResp, "secs_since_last_alert >= secs_since_last_alert assertion failure");
		Assert.assertTrue(secsUntilNextAlertResp == 0 , "secs_until_next_alert was zero assertion failure");
		Assert.assertEquals(actualResponse.id(), idForRequestToBeEchoedBackInResponseId);
	}
	
	@Test(description = "Make a request to GetRealityCheckDetails for an unknown session")
	public void getRealityCheckDetails_unknownSession_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString(); 
		
		GetRealityCheckDetailsReq request = new GetRealityCheckDetailsReq.Builder()
										.defaults()
										.sessionId("UNKNOWN")
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getRealityCheckDetailsError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1001)
				.message("Session not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to getRealityCheckDetails. Missing session_id parameter.")
	public void getRealityCheckDetails_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString(); 
		
		GetRealityCheckDetailsReq request = new GetRealityCheckDetailsReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.sessionId(null)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getRealityCheckDetailsError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: session_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to getRealityCheckDetails. Wrong method.")
	public void getRealityCheckDetails_Wrong_Method() {

		GetRealityCheckDetailsReq request = new GetRealityCheckDetailsReq.Builder()
										.defaults()
										.id(null)
										.method("INVALID_METHOD_NAME")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getRealityCheckDetailsError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
