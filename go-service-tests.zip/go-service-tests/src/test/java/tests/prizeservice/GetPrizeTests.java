package tests.prizeservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.prizeservice.request.GetPrizeReq;
import tests.prizeservice.request.InsertPrizeReq;
import tests.prizeservice.response.GetPrizeResp;
import tests.prizeservice.response.InsertPrizeResp;
public class GetPrizeTests extends BaseClassSetup{
	
	@Test(description = "Make a request to get prize. Positive scenario.")
	public void getPrize_Positive_Scenario() {

		String idForRequestToBeEchoedBackInResponseId1 = UUID.randomUUID().toString();
		
		InsertPrizeReq insertPrizeRequest = new InsertPrizeReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId1)
										.build();
		
		InsertPrizeResp actualInsertPrizeResponse =  BaseRequest.getResponse(insertPrizeRequest, ResponseEndpoints.insertPrizeSuccess);
		
		InsertPrizeResp expectedInsertPrizeResponse =  new InsertPrizeResp.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId1)
											.build();
		
		assertReflectionEquals(expectedInsertPrizeResponse, actualInsertPrizeResponse);
		
		String idForRequestToBeEchoedBackInResponseId2 = UUID.randomUUID().toString();
		
		GetPrizeReq getPrizeRequest = new GetPrizeReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId2)
										.build();
		
		GetPrizeResp actualGetPrizeResponse =  BaseRequest.getResponse(getPrizeRequest, ResponseEndpoints.getPrizeSuccess);
		
		GetPrizeResp expectedGetPrizeResponse =  new GetPrizeResp.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId2)
											.build();
		
		assertReflectionEquals(expectedGetPrizeResponse, actualGetPrizeResponse);
	}
	
	@Test(description = "Make a request to get prize for a prize that does not exist and so will not be found scenario.")
	public void getPrize_PrizeNotFound_Scenario() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetPrizeReq request = new GetPrizeReq.Builder()
										.defaults()
										.externalPrizeId("UNKNOWN_PRIZE")
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getPrizeError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Prize not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to get prize. Missing parameter.")
	public void GetPrize_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetPrizeReq request = new GetPrizeReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.partnerId(null)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getPrizeError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: partner_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to get prize. Wrong method.")
	public void GetPrize_Wrong_Method() {

		GetPrizeReq request = new GetPrizeReq.Builder()
										.defaults()
										.id(null)
										.method("INVALID_METHOD_NAME")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getPrizeError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
