package tests.prizeservice.response;

public class InsertPrizeResp {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String result;
	
	private InsertPrizeResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public static class Builder {
		private String id, result;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder result(String result) {
			this.result = result;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.result = "OK";
			return this;
		}
		
		public InsertPrizeResp build() {
			return new InsertPrizeResp(this);
		}	
	}
}
