package tests.prizeservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.prizeservice.request.InsertPrizeReq;
import tests.prizeservice.response.InsertPrizeResp;

public class InsertPrizeTests extends BaseClassSetup {
	
	@Test(description = "Make a request to insert prize. Positive scenario.")
	public void insertPrize_Positive_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		InsertPrizeReq request = new InsertPrizeReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		InsertPrizeResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.insertPrizeSuccess);
		
		InsertPrizeResp expectedResponse =  new InsertPrizeResp.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId)
											.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to insert prize. Missing bet365_games_transaction_id parameter.")
	public void InsertPrize_Missing_Parameter() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		InsertPrizeReq request = new InsertPrizeReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.bet365GamesTransactionId(null)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.insertPrizeError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: bet365_games_transaction_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to insert prize. Wrong method.")
	public void InsertPrize_Wrong_Method() {
		
		InsertPrizeReq request = new InsertPrizeReq.Builder()
										.defaults()
										.id(null)
										.method("INVALID_METHOD_NAME")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.insertPrizeError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
