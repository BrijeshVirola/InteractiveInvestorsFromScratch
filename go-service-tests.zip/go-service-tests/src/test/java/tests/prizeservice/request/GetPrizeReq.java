package tests.prizeservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetPrizeReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private GetPrizeReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("external_prize_id", builder.external_prize_id);
		this.params.put("partner_id", builder.partner_id);
	}

	public static class Builder {
		private String method, id, external_prize_id;
		private Integer partner_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder externalPrizeId(String external_prize_id) {
			this.external_prize_id = external_prize_id;
			return this;
		}

		public Builder partnerId(Integer partner_id) {
			this.partner_id = partner_id;
			return this;
		}

		public Builder defaults() {
			this.method = "GetPrize";
			this.id = "1";
			this.external_prize_id = "TestExternalPrizeId-2021-10-01";
			this.partner_id = 100;
			return this;
		}

		public GetPrizeReq build() {
			return new GetPrizeReq(this);
		}
	}
}
