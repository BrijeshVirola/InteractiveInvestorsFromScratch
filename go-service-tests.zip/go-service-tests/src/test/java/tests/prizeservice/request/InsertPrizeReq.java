package tests.prizeservice.request;

import java.util.HashMap;
import java.util.Map;

public class InsertPrizeReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private InsertPrizeReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
		this.params.put("user_ticket_count", builder.user_ticket_count);
		this.params.put("formatted_amount", builder.formatted_amount);
		this.params.put("jackpot_id", builder.jackpot_id);
		this.params.put("bet365_games_transaction_id", builder.bet365_games_transaction_id);
		this.params.put("external_prize_id", builder.external_prize_id);
		this.params.put("partner_prize_reference", builder.partner_prize_reference);
		this.params.put("partner_id", builder.partner_id);
		this.params.put("partner_date_time_utc", builder.partner_date_time_utc);
		this.params.put("prize_awarded_date_time_utc", builder.prize_awarded_date_time_utc);
	}

	public static class Builder {
		private String method, id, formatted_amount, external_prize_id, partner_prize_reference, partner_date_time_utc,
				prize_awarded_date_time_utc;
		private Integer user_id, user_ticket_count, jackpot_id, partner_id;
		private Long bet365_games_transaction_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder userTicketCount(Integer user_ticket_count) {
			this.user_ticket_count = user_ticket_count;
			return this;
		}

		public Builder formattedAmount(String formatted_amount) {
			this.formatted_amount = formatted_amount;
			return this;
		}

		public Builder jackpotId(Integer jackpot_id) {
			this.jackpot_id = jackpot_id;
			return this;
		}

		public Builder bet365GamesTransactionId(Long bet365_games_transaction_id) {
			this.bet365_games_transaction_id = bet365_games_transaction_id;
			return this;
		}

		public Builder externalPrizeId(String external_prize_id) {
			this.external_prize_id = external_prize_id;
			return this;
		}

		public Builder partnerPrizeReference(String partner_prize_reference) {
			this.partner_prize_reference = partner_prize_reference;
			return this;
		}

		public Builder partnerId(Integer partner_id) {
			this.partner_id = partner_id;
			return this;
		}

		public Builder partnerDateTimeUTC(String partner_date_time_utc) {
			this.partner_date_time_utc = partner_date_time_utc;
			return this;
		}

		public Builder prizeAwardedDateTimeUTC(String prize_awarded_date_time_utc) {
			this.prize_awarded_date_time_utc = prize_awarded_date_time_utc;
			return this;
		}

		public Builder defaults() {
			this.method = "InsertPrize";
			this.id = "1";
			this.user_id = 100020624;
			this.user_ticket_count = 100;
			this.formatted_amount = "�10.00";
			this.jackpot_id = 1007;
			this.bet365_games_transaction_id = 2202746218L;
			this.external_prize_id = "TestExternalPrizeId-2021-10-01";
			this.partner_prize_reference = "20211001-01";
			this.partner_id = 100;
			this.partner_date_time_utc = "2021-10-01T14:03:30.000Z";
			this.prize_awarded_date_time_utc = "2021-10-01T14:03:30.000Z";
			return this;
		}

		public InsertPrizeReq build() {
			return new InsertPrizeReq(this);
		}
	}
}
