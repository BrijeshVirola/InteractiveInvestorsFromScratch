package tests.tokenservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.tokenservice.request.GetCurrentlyPlayingTokenReq;
import tests.tokenservice.request.SetCurrentlyPlayingTokenReq;
import tests.tokenservice.response.GetCurrentlyPlayingTokenResp;

public class GetCurrentlyPlayingTokenTests extends BaseClassSetup {

	@Test(description = "Make a request to GetCurrentlyPlayingToken. Guid token.")
	public void getCurrentlyPlayingTokenGuid() {
		
		String id = UUID.randomUUID().toString();
		String token = UUID.randomUUID().toString();
		Integer userId = 1000581961;
		
		SetCurrentlyPlayingTokenReq setTokenRequest = new SetCurrentlyPlayingTokenReq.Builder()
				.defaults()
				.token(token)
				.userId(userId)
				.build();

		BaseRequest.getResponse(setTokenRequest, ResponseEndpoints.setCurrentlyPlayingTokenSuccess);

		GetCurrentlyPlayingTokenReq request = new GetCurrentlyPlayingTokenReq.Builder()
				.defaults()
				.id(id)
				.userId(userId)
				.build();

		GetCurrentlyPlayingTokenResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentlyPlayingTokenSuccess);
		GetCurrentlyPlayingTokenResp expectedResponse = new GetCurrentlyPlayingTokenResp.Builder()
				.defaults()
				.id(id)
				.token(token)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to GetCurrentlyPlayingToken. Not Guid token")
	public void getCurrentlyPlayingToken_Not_Guid() {
		
		String id = UUID.randomUUID().toString();
		String token = "notGuidToken@test1";
		Integer userId = 1000581963;
		
		SetCurrentlyPlayingTokenReq setTokenRequest = new SetCurrentlyPlayingTokenReq.Builder()
				.defaults()
				.token(token)
				.userId(userId)
				.build();

		BaseRequest.getResponse(setTokenRequest, ResponseEndpoints.setCurrentlyPlayingTokenSuccess);

		GetCurrentlyPlayingTokenReq request = new GetCurrentlyPlayingTokenReq.Builder()
				.defaults()
				.id(id)
				.userId(userId)
				.build();

		GetCurrentlyPlayingTokenResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentlyPlayingTokenSuccess);
		GetCurrentlyPlayingTokenResp expectedResponse = new GetCurrentlyPlayingTokenResp.Builder()
				.defaults()
				.id(id)
				.token(token)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to GetCurrentlyPlayingToken. User has no currently playing token")
	public void getCurrentlyPlayingToken_Not_Currently_Playing_Token() {
		
		String id = UUID.randomUUID().toString();
		Integer userId = 1000581962;

		GetCurrentlyPlayingTokenReq request = new GetCurrentlyPlayingTokenReq.Builder()
				.defaults()
				.id(id)
				.userId(userId)
				.build();

		CustomErrorResponse actualError =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentlyPlayingTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1001)
				.message("User has no currently playing token")
				.id(id)
				.build();

		assertReflectionEquals(expectedError,actualError);
	}

	@Test(description = "Make a request to GetCurrentlyPlayingToken with missing parameter user_id")
	public void getCurrentlyPlayingToken_Missing_User_Id() {

		String id = UUID.randomUUID().toString();

		GetCurrentlyPlayingTokenReq request = new GetCurrentlyPlayingTokenReq.Builder()
				.defaults()
				.id(id)
				.userId(null)
				.build();

		CustomErrorResponse actualError =  BaseRequest.getResponse(request, ResponseEndpoints.getCurrentlyPlayingTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(id)
				.build();

		assertReflectionEquals(expectedError,actualError);
	}

	@Test(description = "Make a request to GetCurrentlyPlayingToken with invalid method.")
	public void getCurrentlyPlayingToken_Invalid_Method() {

		String id = UUID.randomUUID().toString();

		GetCurrentlyPlayingTokenReq getRequest = new GetCurrentlyPlayingTokenReq.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build(); 

		CustomErrorResponse actualError =  BaseRequest.getResponse(getRequest, ResponseEndpoints.getCurrentlyPlayingTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to SetCurrentlyPlayingToken with too long token.")
	public void setCurrentlyPlayingToken_Too_Long_Token() {

		String id = UUID.randomUUID().toString();

		SetCurrentlyPlayingTokenReq getRequest = new SetCurrentlyPlayingTokenReq.Builder()
				.defaults()
				.id(id)
				.token("04248278-ae63-4e4a-8748-5ae1ec72bf1111111111111111111111111111111111111111111111111111111111111111111")
				.build(); 

		CustomErrorResponse actualError =  BaseRequest.getResponse(getRequest, ResponseEndpoints.setCurrentlyPlayingTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1007)
				.message("Supplied token is too long (100 chars max)")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}

