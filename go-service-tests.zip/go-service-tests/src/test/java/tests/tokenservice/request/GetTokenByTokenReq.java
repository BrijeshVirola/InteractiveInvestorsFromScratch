package tests.tokenservice.request;

import tests.tokenservice.requestobjects.GetTokenByTokenParams;

public class GetTokenByTokenReq {
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private GetTokenByTokenParams Params;

	private GetTokenByTokenReq(Builder builder) {
		this.Method = builder.method;
		this.ID = builder.id;
		this.Params = builder.params;
	}
	
	public static class Builder {
		private String method;
		private String id;
		private GetTokenByTokenParams params;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder params(GetTokenByTokenParams  params) {
			this.params = params;
			return this;
		}

		public Builder defaults() {
			this.method = "gettokenbytoken";
			this.id = "test_id";
			this.params = new GetTokenByTokenParams 
					.Builder()
					.defaults()
					.token("")
					.build();
			return this;
		}
		
		public GetTokenByTokenReq build() {
			return new GetTokenByTokenReq(this);
		}
	}
}
