package tests.tokenservice.request;

import tests.tokenservice.requestobjects.CreatePublicTokenParams;

public class CreatePublicTokenReq {

	@SuppressWarnings("unused")
	private String Method;

	@SuppressWarnings("unused")
	private String ID;

	private CreatePublicTokenParams params;
	
	private CreatePublicTokenReq(Builder builder) {
		this.Method = builder.method;
		this.ID = builder.id;
		this.params = builder.parameters;
	}
	
	public CreatePublicTokenParams getParams() {
		return this.params;
	}
	
	public static class Builder {
		private String method;
		private String id;
		private CreatePublicTokenParams parameters;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder params(CreatePublicTokenParams params) {
			this.parameters = params;
			return this;
		}

		public Builder defaults() {
			this.method = "createpublictoken";
			this.id = "test_id";
			this.parameters = new CreatePublicTokenParams
					.Builder()
					.defaults()
					.publicToken("")
					.build();
			return this;
		}
		
		public CreatePublicTokenReq build() {
			return new CreatePublicTokenReq(this);
		}
	}
}

