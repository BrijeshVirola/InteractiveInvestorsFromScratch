package tests.tokenservice.request;

import tests.tokenservice.requestobjects.CreatePrivateTokenParams;

public class CreatePrivateTokenReq {
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private CreatePrivateTokenParams params;

	private CreatePrivateTokenReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params = builder.params;
	}
	
	public static class Builder{
		private String method;
		private String id;
		private CreatePrivateTokenParams params;
		
		public Builder defaults() {
			this.method = "createprivatetoken";
			this.id = "1";
			this.params = new CreatePrivateTokenParams
					.Builder()
					.defaults()
					.build();
			return this;
		}
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder params(CreatePrivateTokenParams  params) {
			this.params = params;
			return this;
		}

		public CreatePrivateTokenReq build() {
			return new CreatePrivateTokenReq(this);
		}
	}
}
