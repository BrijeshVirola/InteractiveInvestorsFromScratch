package tests.tokenservice.request;

import com.google.gson.annotations.SerializedName;

public class InvalidateTokenByTokenReq {
	
	@SuppressWarnings("unused")
	private String Id;
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private Params Params;

	private InvalidateTokenByTokenReq(Builder builder) {
		Id = builder.id;
		Method = builder.method;
		Params = new Params(builder);
	}
	
	public static class Builder {
		
		private String id;
		private String method;
		private String token;
		private Boolean isPublic;
		
		public Builder defaults() {
			id = "test_id";
			method = "InvalidateTokenByToken";
			token = "b5fa5f4e-3d8a-11ec-9bbc-0242ac130002";
			isPublic = true;
			return this;
		}
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder token(String token) {
			this.token = token;
			return this;
		}
		
		public Builder isPublic(Boolean isPublic) {
			this.isPublic = isPublic;
			return this;
		}
		
		public InvalidateTokenByTokenReq build() {
			return new InvalidateTokenByTokenReq(this);
		}
	}
	
	private class Params {
		
		@SuppressWarnings("unused")
		private String token;
		@SerializedName("is_public")
		private Boolean isPublic;
		
		public Params(Builder builder) {
			token = builder.token;
			isPublic = builder.isPublic;
		}
	}
}
