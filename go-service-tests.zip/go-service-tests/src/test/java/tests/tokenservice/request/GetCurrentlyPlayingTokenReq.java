package tests.tokenservice.request;

public class GetCurrentlyPlayingTokenReq {
	
	@SuppressWarnings("unused")
	private String Id;
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private Params Params;

	private GetCurrentlyPlayingTokenReq(Builder builder) {
		Id = builder.id;
		Method = builder.method;
		Params = new Params(builder);
	}
	
	public static class Builder {
		
		private String id;
		private String method;
		private Integer user_id;
		
		public Builder defaults() {
			id = "test_id";
			method = "GetCurrentlyPlayingToken";
			user_id = 100058196;
			return this;
		}
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder userId(Integer userId) {
			this.user_id = userId;
			return this;
		}
		
		public GetCurrentlyPlayingTokenReq build() {
			return new GetCurrentlyPlayingTokenReq(this);
		}
	}
	
	private class Params {
		
		@SuppressWarnings("unused")
		private String token;
		@SuppressWarnings("unused")
		private Integer user_id;
		
		public Params(Builder builder) {
			user_id = builder.user_id;
		}
	}
}
