package tests.tokenservice.response;

import tests.tokenservice.responseobjects.TokenResult;

public class TokenResp {

	private String id;
	
	private TokenResult result;

	public String id() {
		return id;
	}
	
	public String token() {
		return result.token();
	}
	
	public long sno() {	
		return result.sno();
	}
	
	public String createdDate() {
		return result.createdDate();
	}
	
	public String expirationDate() {
		return result.expirationDate();
	}
	
	private TokenResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public static class Builder {
		private String id;
		private TokenResult result;

		public Builder defaults() {
			this.id = "test_id";
			this.result = new TokenResult
					.Builder()
					.defaults()
					.build();
			return this;
		}
		
		public Builder result(TokenResult result) {
			this.result = result;
			return this;
		}
		
		
		public TokenResp build() {
			return new TokenResp(this);
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
	}
}
