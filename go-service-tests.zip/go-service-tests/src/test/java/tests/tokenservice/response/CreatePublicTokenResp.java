package tests.tokenservice.response;

public class CreatePublicTokenResp {

	private String id;
	private Result result;
	
	private CreatePublicTokenResp(Builder builder) {
		this.id = builder.id;
		this.result = new Result(builder.sno, builder.publicToken);
	}

	public String id() {
		return this.id;
	}
	
	public String publicToken() {
		return result.public_token;
	}
	
	public long sno() {
		return result.sno;
	}
	
	public static class Builder {
		private String id;
	    private long sno;
		private String publicToken;
		
		public Builder defaults() {
			this.id = "";
			this.sno = 01;
			this.publicToken = "";
			return this;
		}
		
		public CreatePublicTokenResp build() {
			return new CreatePublicTokenResp(this);
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder sno(long sno) {
			this.sno = sno;
			return this;
		}

		public Builder publicToken(String publicToken) {
			this.publicToken = publicToken;
			return this;
		}
	}
	
	private class Result {
	    private long sno;
		private String public_token;

		public Result(long sno, String publicToken) {
			this.sno = sno;
			this.public_token = publicToken;
		}
	}
}
