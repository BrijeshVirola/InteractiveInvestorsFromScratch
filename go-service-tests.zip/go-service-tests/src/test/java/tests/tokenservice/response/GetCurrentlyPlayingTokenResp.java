package tests.tokenservice.response;

public class GetCurrentlyPlayingTokenResp {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Result result;
	
	private GetCurrentlyPlayingTokenResp(Builder builder) {
		this.id = builder.id;
		this.result = new Result(builder.token);
	}

	public static class Builder {
		private String id;
		private String token;
		
		public Builder defaults() {
			id = "defaultId";
			token = "4248278-ae63-4e4a-8748-5ae1ec72bf1111111";
			return this;
		}
		
		public GetCurrentlyPlayingTokenResp build() {
			return new GetCurrentlyPlayingTokenResp(this);
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder token(String token) {
			this.token = token;
			return this;
		}
	}
	
	private class Result {
		
		@SuppressWarnings("unused")
		private String token;

		public Result(String token) {
			this.token = token;
		}
	}
}
