package tests.tokenservice.response;

public class InvalidateTokenByTokenResp {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String result;
	
	public InvalidateTokenByTokenResp(String id, String result) {
		this.id = id;
		this.result = result;
	}
}
