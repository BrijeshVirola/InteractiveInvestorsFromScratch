package tests.tokenservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.util.UUID;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.tokenservice.request.GetTokenByTokenReq;
import tests.tokenservice.requestobjects.GetTokenByTokenParams;
import tests.tokenservice.response.TokenResp;
import tests.tokenservice.responseobjects.TokenResult;

public class GetTokenByTokenTests  extends BaseClassSetup {

	@Test(description = "Make a request to GetTokenByToken with public token.")
	public void getTokenByToken_Public_Token() {
		
		String token = "4edf2510-3374-42da-98bb-76a9d24545cd";
		String id = UUID.randomUUID().toString();

		GetTokenByTokenReq getRequest = new GetTokenByTokenReq.Builder()
				.defaults()
				.id(id)
				.params(new GetTokenByTokenParams
						.Builder()
						.defaults()
						.token(token)
						.build())
				.build(); 
		
		TokenResp actualGetResponse =  BaseRequest.getResponse(getRequest, ResponseEndpoints.getTokenByTokenSuccess);
		TokenResult expectedGetResult = new TokenResult
				.Builder()
				.defaults()
				.sno(3789545l)
				.token(token)
				.userId(100017940)
				.sessionId("92CD32E0E297B3969B42B08966998510000004")
				.isPublic(true)
				.providerImplementationId(100)
				.productId(4)
				.partnerHash("CogenaWhiteLabelUKHash")
				.createdDate("2021-11-04T08:02:51.663Z")
				.expirationDate("2021-11-04T08:07:51.663Z")
				.consumedDate("0001-01-01T00:00:00Z")
				.gameLaunchUrl("http://games.bet365.com")
				.accountHistoryUrl("http://members.bet365.com")
				.regulatedGameId(6403)
				.build();
		
		TokenResp expectedGetResponse = new TokenResp
				.Builder()
				.defaults()
				.id(id)
				.result(expectedGetResult)
				.build(); 
		
		assertReflectionEquals(expectedGetResponse, actualGetResponse);
	}
	
	@Test(description = "Make a request to GetTokenByToken with private token.")
	public void getTokenByToken_Private_Token() {
		
		String token = "04248278-ae63-4e4a-8748-5ae1ec72bf11";
		String id = UUID.randomUUID().toString();

		GetTokenByTokenReq getRequest = new GetTokenByTokenReq.Builder()
				.defaults()
				.id(id)
				.params(new GetTokenByTokenParams
						.Builder()
						.defaults()
						.token(token)
						.build())
				.build(); 
		
		TokenResp actualGetResponse =  BaseRequest.getResponse(getRequest, ResponseEndpoints.getTokenByTokenSuccess);
		TokenResult expectedGetResult = new TokenResult
				.Builder()
				.defaults()
				.sno(3790995)
				.token(token)
				.userId(100017940)
				.sessionId("92CD32E0E297B3969B42B08966998510000004")
				.isPublic(false)
				.providerImplementationId(100)
				.productId(4)
				.partnerHash("CogenaWhiteLabelUKHash")
				.createdDate("2021-11-04T09:37:30.18Z")
				.expirationDate("0001-01-01T00:00:00Z")
				.consumedDate("0001-01-01T00:00:00Z")
				.gameLaunchUrl("http://games.bet365.com")
				.accountHistoryUrl("http://members.bet365.com")
				.regulatedGameId(6403)
				.build();
		
		TokenResp expectedGetResponse = new TokenResp
				.Builder()
				.defaults()
				.id(id)
				.result(expectedGetResult)
				.build(); 
		
		assertReflectionEquals(expectedGetResponse, actualGetResponse);
	}
	
	@Test(description = "Make a request to GetTokenByToken with missing parameter token.")
	public void getTokenByToken_Missing_Parameter_Token() {
		
		String id = UUID.randomUUID().toString();

		GetTokenByTokenReq getRequest = new GetTokenByTokenReq.Builder()
				.defaults()
				.id(id)
				.params(new GetTokenByTokenParams
						.Builder()
						.defaults()
						.token(null)
						.build())
				.build(); 
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(getRequest, ResponseEndpoints.getTokenByTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: token")
				.id(id)
				.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to GetTokenByToken with invalid method.")
	public void getTokenByToken_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();

		GetTokenByTokenReq getRequest = new GetTokenByTokenReq.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.params(new GetTokenByTokenParams
						.Builder()
						.defaults()
						.token(null)
						.build())
				.build(); 
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(getRequest, ResponseEndpoints.getTokenByTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to GetTokenByToken with not existing token.")
	public void getTokenByToken_Not_Existing_Token() {
		
		String id = UUID.randomUUID().toString();

		GetTokenByTokenReq getRequest = new GetTokenByTokenReq.Builder()
				.defaults()
				.id(id)
				.params(new GetTokenByTokenParams
						.Builder()
						.defaults()
						.token("04248278-ae63-4e4a-8748-5ae1ec72bf111")
						.build())
				.build(); 
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(getRequest, ResponseEndpoints.getTokenByTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1001)
				.message("User token was not found")
				.id(id)
				.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to GetTokenByToken with too long token.")
	public void getTokenByToken_Too_Long_Token() {
		
		String id = UUID.randomUUID().toString();

		GetTokenByTokenReq getRequest = new GetTokenByTokenReq.Builder()
				.defaults()
				.id(id)
				.params(new GetTokenByTokenParams
						.Builder()
						.defaults()
						.token("04248278-ae63-4e4a-8748-5ae1ec72bf1111111111111111111111111111111111111111111111111111111111111111111")
						.build())
				.build(); 
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(getRequest, ResponseEndpoints.getTokenByTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1007)
				.message("Supplied token is too long (100 chars max)")
				.id(id)
				.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
}
