package tests.tokenservice.requestobjects;

import com.google.gson.annotations.SerializedName;

public class CreatePrivateTokenParams {

	@SuppressWarnings("unused")
	private String token;
	@SerializedName("is_public")
	private boolean isPublic;
	
	private CreatePrivateTokenParams(Builder builder) {
		this.token = builder.token;
		this.isPublic = builder.isPublic;
	}
	
	public static class Builder{
		private String token;
		private boolean isPublic;
		
		public Builder defaults() {
			this.token = "";
			this.isPublic = true;
			return this;
		}
		
		public Builder token(String token) {
			this.token = token;
			return this;
		}

		public Builder isPublic(boolean isPublic) {
			this.isPublic = isPublic;
			return this;
		}

		public CreatePrivateTokenParams build() {
			return new CreatePrivateTokenParams(this);
		}
	}
}
