package tests.tokenservice.requestobjects;


public class CreatePublicTokenParams {

	@SuppressWarnings("unused")
	private int user_id;
	private String session_id;
	@SuppressWarnings("unused")
	private int provider_implementation_id;
	@SuppressWarnings("unused")
	private int product_id;
	@SuppressWarnings("unused")
	private int milliseconds_token_is_valid;
	@SuppressWarnings("unused")
	private String game_launch_url;
	@SuppressWarnings("unused")
	private String account_history_url;
	@SuppressWarnings("unused")
	private int regulated_game_id;
	@SuppressWarnings("unused")
	private String public_token;
	
	public CreatePublicTokenParams(Builder builder) {
		user_id = builder.user_id;
		session_id = builder.session_id;
		provider_implementation_id = builder.provider_implementation_id;
		product_id = builder.product_id;
		milliseconds_token_is_valid = builder.milliseconds_token_is_valid;
		game_launch_url = builder.game_launch_url;
		account_history_url = builder.account_history_url;
		regulated_game_id = builder.regulated_game_id;
		public_token = builder.public_token;
	}
	
	public String getSessionId() {
		return this.session_id;
	}
	
	public static class Builder {
		private int user_id;
		private String session_id;
		private int provider_implementation_id;
		private int product_id;
		private int milliseconds_token_is_valid;
		private String game_launch_url;
		private String account_history_url;
		private int regulated_game_id;
		private String public_token;
		
		public Builder userId(int userId) {
			this.user_id = userId;
			return this;
		}
		
		public Builder defaults() {
			this.user_id =  100017940;
			this.session_id =  "92CD32E0E297B3969B42B08966998510000004";
			this.provider_implementation_id =  100;
			this.product_id =  4;
			this.milliseconds_token_is_valid =  300000;
			this.game_launch_url =  "http://games.bet365.com";
			this.account_history_url =  "http://members.bet365.com";
			this.regulated_game_id =  6403;
			this.public_token = "custom token";
			return this;
		}
		
		public Builder sessionId(String sessionId) {
			this.session_id = sessionId;
			return this;
		}
		
		public Builder providerImplementationId(int providerImplementationId) {
			this.provider_implementation_id = providerImplementationId;
			return this;
		}
		
		public Builder productId(int productId) {
			this.product_id = productId;
			return this;
		}
		
		public Builder millisecondsTokenIsValid(int millisecondsTokenIsValid) {
			this.milliseconds_token_is_valid = millisecondsTokenIsValid;
			return this;
		}
		
		public Builder gameLaunchUrl(String gameLaunchUrl) {
			this.game_launch_url = gameLaunchUrl;
			return this;
		}
		
		public Builder accountHistoryUrl(String accountHistoryUrl) {
			this.account_history_url = accountHistoryUrl;
			return this;
		}
		
		public Builder regulatedGameId(int regulatedGameId) {
			this.regulated_game_id = regulatedGameId;
			return this;
		}
		
		public Builder publicToken(String publicToken) {
			this.public_token = publicToken;
			return this;
		}
		
		public CreatePublicTokenParams  build() {
			return new CreatePublicTokenParams (this);
		}
	}
}
