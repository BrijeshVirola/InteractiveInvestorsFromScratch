package tests.tokenservice.requestobjects;

public class GetTokenByTokenParams {

	@SuppressWarnings("unused")
	private String token;
	
	public GetTokenByTokenParams(Builder builder) {
		this.token = builder.token;
	}
	
	public static class Builder {
		private String token;

		public Builder token(String token) {
			this.token = token;
			return this;
		}
		
		public Builder defaults() {
			this.token = "01234567-89ab-cdef-0123-456789abcdef";
			return this;
		}
		
		public GetTokenByTokenParams build() {
			return new GetTokenByTokenParams(this);
		}
	}
}
