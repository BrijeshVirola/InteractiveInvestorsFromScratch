package tests.tokenservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.Utils;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.tokenservice.request.InvalidateTokenByTokenReq;
import tests.tokenservice.response.InvalidateTokenByTokenResp;

public class InvalidateTokenByTokenTests  extends BaseClassSetup {

	@Test(description = "Make a request to invalidateTokenByToken with public token.")
	public void invalidateTokenByToken_Public_Token() {
		
		String publicToken = Utils.createNewPublicToken(UsersId.GO_SVC_TESTS10).publicToken();
		String id = UUID.randomUUID().toString();

		InvalidateTokenByTokenReq getRequest = new InvalidateTokenByTokenReq.Builder()
				.defaults()
				.id(id)
				.token(publicToken)
				.isPublic(true)
				.build(); 
		
		InvalidateTokenByTokenResp actualGetResponse =  BaseRequest.getResponse(getRequest, ResponseEndpoints.invalidateTokenByTokenSuccess);
		InvalidateTokenByTokenResp expectedGetResponse = new InvalidateTokenByTokenResp(id, "OK");
		
		assertReflectionEquals(expectedGetResponse, actualGetResponse);
	}
	
	@Test(description = "Make a request to invalidateTokenByToken with private token.")
	public void invalidateTokenByToken_Private_Token() {
		
		String publicToken = Utils.createNewPublicToken(UsersId.GO_SVC_TESTS11).publicToken();
		String privateToken = Utils.createNewPrivateToken(publicToken).token();
		String id = UUID.randomUUID().toString();

		InvalidateTokenByTokenReq getRequest = new InvalidateTokenByTokenReq.Builder()
				.defaults()
				.id(id)
				.token(privateToken)
				.isPublic(false)
				.build(); 
		
		InvalidateTokenByTokenResp actualGetResponse =  BaseRequest.getResponse(getRequest, ResponseEndpoints.invalidateTokenByTokenSuccess);
		InvalidateTokenByTokenResp expectedGetResponse = new InvalidateTokenByTokenResp(id, "OK");
		
		assertReflectionEquals(expectedGetResponse, actualGetResponse);
	}
	
	@Test(description = "Make a request to invalidateTokenByToken with missing parameter token.")
	public void invalidateTokenByToken_Missing_Parameter_Token() {
		
		String id = UUID.randomUUID().toString();

		InvalidateTokenByTokenReq getRequest = new InvalidateTokenByTokenReq.Builder()
				.defaults()
				.id(id)
				.token(null)
				.build(); 
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(getRequest, ResponseEndpoints.invalidateTokenByTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: token")
				.id(id)
				.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to invalidateTokenByToken with invalid method.")
	public void invalidateTokenByToken_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();

		InvalidateTokenByTokenReq getRequest = new InvalidateTokenByTokenReq.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build(); 
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(getRequest, ResponseEndpoints.invalidateTokenByTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to invalidateTokenByToken with not existing token.")
	public void invalidateTokenByToken_Not_Existing_Token() {
		
		String id = UUID.randomUUID().toString();

		InvalidateTokenByTokenReq getRequest = new InvalidateTokenByTokenReq.Builder()
				.defaults()
				.id(id)
				.token("b5fa5f4e-4d8b-11ec-9bbc-0242ac130002")
				.build(); 
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(getRequest, ResponseEndpoints.invalidateTokenByTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1001)
				.message("User token was not found")
				.id(id)
				.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to invalidateTokenByToken with too long token.")
	public void invalidateTokenByToken_Too_Long_Token() {
		
		String id = UUID.randomUUID().toString();

		InvalidateTokenByTokenReq getRequest = new InvalidateTokenByTokenReq.Builder()
				.defaults()
				.id(id)
				.token("04248278-ae63-4e4a-8748-5ae1ec72bf1111111111111111111111111111111111111111111111111111111111111111111")
				.build(); 
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(getRequest, ResponseEndpoints.invalidateTokenByTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1007)
				.message("Supplied token is too long (100 chars max)")
				.id(id)
				.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to invalidateTokenByToken. Token was not private error.")
	public void invalidateTokenByToken_Token_Not_Private() {
		
		String publicToken = Utils.createNewPublicToken(UsersId.GO_SVC_TESTS22).publicToken();
		String id = UUID.randomUUID().toString();

		InvalidateTokenByTokenReq getRequest = new InvalidateTokenByTokenReq.Builder()
				.defaults()
				.id(id)
				.token(publicToken)
				.isPublic(false)
				.build(); 
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(getRequest, ResponseEndpoints.invalidateTokenByTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1005)
				.message("Supplied token was not private")
				.id(id)
				.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to invalidateTokenByToken. Token was not public error.")
	public void invalidateTokenByToken_Token_Not_Public() {
		
		String publicToken = Utils.createNewPublicToken(UsersId.GO_SVC_TESTS23).publicToken();
		String privateToken = Utils.createNewPrivateToken(publicToken).token();
		String id = UUID.randomUUID().toString();

		InvalidateTokenByTokenReq getRequest = new InvalidateTokenByTokenReq.Builder()
				.defaults()
				.id(id)
				.token(privateToken)
				.isPublic(true)
				.build(); 
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(getRequest, ResponseEndpoints.invalidateTokenByTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1004)
				.message("Supplied token was not public")
				.id(id)
				.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to invalidateTokenByToken with expired token.")
	public void invalidateTokenByToken_Expired_Token() {
		
		String id = UUID.randomUUID().toString();

		InvalidateTokenByTokenReq getRequest = new InvalidateTokenByTokenReq.Builder()
				.defaults()
				.id(id)
				.token("b5fa5f4e-3d8a-11ec-9bbc-0242ac130002")
				.isPublic(true)
				.build(); 
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(getRequest, ResponseEndpoints.invalidateTokenByTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Token has expired")
				.id(id)
				.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to invalidateTokenByToken twice.")
	public void invalidateTokenByToken_Public_Token_Consumed() {
		
		String publicToken = Utils.createNewPublicToken(UsersId.GO_SVC_TESTS24).publicToken();
		String id = UUID.randomUUID().toString();

		InvalidateTokenByTokenReq getRequest = new InvalidateTokenByTokenReq.Builder()
				.defaults()
				.id(id)
				.token(publicToken)
				.isPublic(true)
				.build(); 
		
		BaseRequest.getResponse(getRequest, ResponseEndpoints.invalidateTokenByTokenSuccess);
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(getRequest, ResponseEndpoints.invalidateTokenByTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Token has already been consumed")
				.id(id)
				.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
}
