package tests.tokenservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.Utils;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.ServiceErrors;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.tokenservice.request.CreatePrivateTokenReq;
import tests.tokenservice.request.InvalidateTokenByTokenReq;
import tests.tokenservice.requestobjects.CreatePrivateTokenParams;
import tests.tokenservice.response.TokenResp;
import tests.tokenservice.responseobjects.TokenResult;

public class CreatePrivateTokenTests  extends BaseClassSetup {

	@Test(description = "create a private token using a new public token and then read it back")
	public void createPrivateTokenUsingNewUniquePublicToken() {

		//	Create a public token that we can use to create a private one 
		String publicToken = Utils.createNewPublicToken(UsersId.GO_SVC_TESTS07).publicToken();

		TokenResp actualResponse = Utils.createNewPrivateToken(publicToken);
		TokenResp expectedResponse = new TokenResp
				.Builder()
				.defaults()
				.id("1")
				.result(new TokenResult
						.Builder()
						.defaults()
						.token(actualResponse.token())
						.sno(actualResponse.sno())
						.userId(UsersId.GO_SVC_TESTS07)
						.createdDate(actualResponse.createdDate())
						.build())
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "create a private token using a new public token which is passed as a private token")
	public void createPrivateTokenUsingAPublicTokenAsAPrivateToken() {

		//	Create a public token that we can use to create a private one 
		String publicToken = Utils.createNewPublicToken(UsersId.GO_SVC_TESTS08).publicToken();

		//	Create a private token using the newly created public token as an input
		CreatePrivateTokenReq request = new CreatePrivateTokenReq
				.Builder()
				.defaults()
				.params(new CreatePrivateTokenParams
						.Builder()
						.defaults()
						.token(publicToken)
						.isPublic(false)
						.build())
				.build();
		CustomErrorResponse actualError =  BaseRequest.getResponse(request, ResponseEndpoints.createPrivateTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(ServiceErrors.Token.TOKEN_IS_NOT_PRIVATE.getCode())
				.message(ServiceErrors.Token.TOKEN_IS_NOT_PRIVATE.getMessage())
				.id("1")
				.build();

		assertReflectionEquals(expectedError,actualError);
	}

	@Test(description = "create a private token using a new private token which is passed as a public token")
	public void createPrivateTokenUsingAPrivateTokenAsAPublicToken() {

		String publicToken = Utils.createNewPublicToken(UsersId.GO_SVC_TESTS09).publicToken();

		TokenResp actualResponse = Utils.createNewPrivateToken(publicToken);

		CreatePrivateTokenReq privateRequest = new CreatePrivateTokenReq
				.Builder()
				.defaults()
				.params(new CreatePrivateTokenParams
						.Builder()
						.defaults()
						.isPublic(true)
						.token(actualResponse.token())
						.build())
				.build();
		CustomErrorResponse actualError =  BaseRequest.getResponse(privateRequest, ResponseEndpoints.createPrivateTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(ServiceErrors.Token.TOKEN_IS_NOT_PUBLIC.getCode())
				.message(ServiceErrors.Token.TOKEN_IS_NOT_PUBLIC.getMessage())
				.id("1")
				.build();

		assertReflectionEquals(expectedError,actualError);
	}

	@Test(description = "create a private token with the token parameter missing")
	public void createPrivateTokenWithMissingPublicToken() {

		CreatePrivateTokenReq request = new CreatePrivateTokenReq
				.Builder()
				.defaults()
				.params(new CreatePrivateTokenParams
						.Builder()
						.defaults()
						.token("")
						.build())
				.build();
		CustomErrorResponse actualError =  BaseRequest.getResponse(request, ResponseEndpoints.createPrivateTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(ServiceErrors.Token.MISSING_PARAMETER.getCode())
				.message(ServiceErrors.Token.MISSING_PARAMETER.getMessage() + "token")
				.id("1")
				.build();

		assertReflectionEquals(expectedError,actualError);
	}

	@Test(description = "create a private token Using a public token that is too long")
	public void createPrivateTokenWithPublicTokenThatIsTooLong() {

		String token = "A123456789B123456789C123456789D123456789E123456789F123456789G123456789H123456789I123456789J123456789K";
		CreatePrivateTokenReq request = new CreatePrivateTokenReq
				.Builder()
				.defaults()
				.params(new CreatePrivateTokenParams
						.Builder()
						.defaults()
						.token(token)
						.build())
				.build();
		CustomErrorResponse actualError =  BaseRequest.getResponse(request, ResponseEndpoints.createPrivateTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(ServiceErrors.Token.SUPPLIED_TOKEN_IS_TOO_LONG.getCode())
				.message(ServiceErrors.Token.SUPPLIED_TOKEN_IS_TOO_LONG.getMessage())
				.id("1")
				.build();

		assertReflectionEquals(expectedError,actualError);
	}

	@Test(description = "create a private token with token that is not found")
	public void createPrivateTokenUserTokenNotFound() {

		String token = "e31b3c5d-54df-4192-b429-c84a504b0911";
		CreatePrivateTokenReq request = new CreatePrivateTokenReq
				.Builder()
				.defaults()
				.params(new CreatePrivateTokenParams
						.Builder()
						.defaults()
						.token(token)
						.build())
				.build();
		CustomErrorResponse actualError =  BaseRequest.getResponse(request, ResponseEndpoints.createPrivateTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1001)
				.message("User token was not found")
				.id("1")
				.build();

		assertReflectionEquals(expectedError,actualError);
	}

	@Test(description = "create a private token with token that is expired")
	public void createPrivateTokenExpiredToken() {

		String token = "b5fa5f4e-3d8a-11ec-9bbc-0242ac130002";
		CreatePrivateTokenReq request = new CreatePrivateTokenReq
				.Builder()
				.defaults()
				.params(new CreatePrivateTokenParams
						.Builder()
						.defaults()
						.token(token)
						.build())
				.build();
		CustomErrorResponse actualError =  BaseRequest.getResponse(request, ResponseEndpoints.createPrivateTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Token has expired")
				.id("1")
				.build();

		assertReflectionEquals(expectedError,actualError);
	}

	@Test(description = "create a private token with token that is consumed")
	public void createPrivateTokenConsumedToken() {
		
		String publicToken = Utils.createNewPublicToken(UsersId.GO_SVC_TESTS27).publicToken();
		
		InvalidateTokenByTokenReq getRequest = new InvalidateTokenByTokenReq.Builder()
				.defaults()
				.token(publicToken)
				.isPublic(true)
				.build(); 
		BaseRequest.getResponse(getRequest, ResponseEndpoints.invalidateTokenByTokenSuccess);

		CreatePrivateTokenReq request = new CreatePrivateTokenReq
				.Builder()
				.defaults()
				.params(new CreatePrivateTokenParams
						.Builder()
						.defaults()
						.token(publicToken)
						.build())
				.build();
		CustomErrorResponse actualError =  BaseRequest.getResponse(request, ResponseEndpoints.createPrivateTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Token has already been consumed")
				.id("1")
				.build();

		assertReflectionEquals(expectedError,actualError);
	}
}

