package tests.tokenservice.responseobjects;

import com.google.gson.annotations.SerializedName;

public class TokenResult {
	private long sno;
	private String token;
	@SerializedName("user_id")
	private Integer userId;
	@SerializedName("session_id")
	private String sessionId;
	@SerializedName("public")
	private boolean isPublic;
	@SerializedName("provider_implementation_id")
	private int providerImplementationId;
	@SerializedName("product_id")
	private int productId;
	@SerializedName("partner_hash")
	private String partnerHash;
	@SerializedName("created_date")
	private String createdDdate;
	@SerializedName("expiration_date")
	private String expirationDate;
	@SerializedName("consumed_date")
	private String consumedDate;
	@SerializedName("game_launch_url")
	private String gameLaunchUrl;
	@SerializedName("account_history_url")
	private String accountHistoryUrl;
	@SerializedName("regulated_game_id")
	private int regulatedGameId;
	
	public String token() {
		return token;
	}

	public long sno() {
		return sno;
	}
	
	public String createdDate() {
		return createdDdate;
	}
	
	public String expirationDate() {
		return expirationDate;
	}
	
	public TokenResult(Builder builder) {
		this.sno = builder.sno;
		this.token = builder.token;
		this.userId = builder.userId;
		this.sessionId = builder.sessionId;
		this.isPublic = builder.isPublic;
		this.providerImplementationId = builder.providerImplementationId;
		this.productId = builder.productId;
		this.partnerHash = builder.partnerHash;
		this.createdDdate = builder.createdDate;
		this.expirationDate = builder.expirationDate;
		this.consumedDate = builder.consumedDate;
		this.gameLaunchUrl = builder.gameLaunchUrl;
		this.accountHistoryUrl = builder.accountHistoryUrl;
		this.regulatedGameId = builder.regulatedGameId;
	}

	public static class Builder {

		private long sno;
		private String token;
		private Integer userId;
		private String sessionId;
		private boolean isPublic;
		private int providerImplementationId;
		private int productId;
		private String partnerHash;
		private String createdDate;
		private String expirationDate;
		private String consumedDate;
		private String gameLaunchUrl;
		private String accountHistoryUrl;
		private int regulatedGameId;
		public Builder defaults() {
			
		    sno= -1;
		    token = "53c25a29-1bd2-4fc6-aa3d-66c740d13904";
		    userId = 100017940;
		    sessionId = "92CD32E0E297B3969B42B08966998510000004";
		    isPublic = false;
		    providerImplementationId = 100;
		    productId = 4;
		    partnerHash = "CogenaWhiteLabelUKHash";
		    createdDate = "2021-10-29T16:32:48.69Z";
		    expirationDate = "0001-01-01T00:00:00Z";
		    consumedDate = "0001-01-01T00:00:00Z";
		    gameLaunchUrl = "http://games.bet365.com";
		    accountHistoryUrl = "http://members.bet365.com";
		    regulatedGameId = 6403;
			
			return this;
		}

		public TokenResult build() {
			return new TokenResult(this);
		}

		public Builder sno(long sno) {
			this.sno = sno;
			return this;
		}

		public Builder token(String token) {
			this.token = token;
			return this;
		}

		public Builder userId(Integer userId) {
			this.userId = userId;
			return this;
		}

		public Builder sessionId(String sessionId) {
			this.sessionId = sessionId;
			return this;
		}

		public Builder isPublic(boolean isPublic) {
			this.isPublic = isPublic;
			return this;
		}

		public Builder providerImplementationId(int providerImplementationId) {
			this.providerImplementationId = providerImplementationId;
			return this;
		}

		public Builder productId(int productId) {
			this.productId = productId;
			return this;
		}

		public Builder partnerHash(String partnerHash) {
			this.partnerHash = partnerHash;
			return this;
		}
		
		public Builder createdDate(String createdDate) {
			this.createdDate = createdDate;
			return this;
		}

		public Builder expirationDate(String expirationDate) {
			this.expirationDate = expirationDate;
			return this;
		}

		public Builder consumedDate(String consumedDate) {
			this.consumedDate = consumedDate;
			return this;
		}

		public Builder gameLaunchUrl(String gameLaunchUrl) {
			this.gameLaunchUrl = gameLaunchUrl;
			return this;
		}

		public Builder accountHistoryUrl(String accountHistoryUrl) {
			this.accountHistoryUrl = accountHistoryUrl;
			return this;
		}

		public Builder regulatedGameId(int regulatedGameId) {
			this.regulatedGameId = regulatedGameId;
			return this;
		}
	}
}
