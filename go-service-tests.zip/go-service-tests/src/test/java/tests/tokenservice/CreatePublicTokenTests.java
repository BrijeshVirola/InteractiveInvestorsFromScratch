package tests.tokenservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.ServiceErrors;
import domain.BaseRequest;
import junit.framework.Assert;
import tests.tokenservice.request.CreatePublicTokenReq;
import tests.tokenservice.request.GetTokenByTokenReq;
import tests.tokenservice.requestobjects.CreatePublicTokenParams;
import tests.tokenservice.requestobjects.GetTokenByTokenParams;
import tests.tokenservice.response.CreatePublicTokenResp;
import tests.tokenservice.response.TokenResp;
import tests.tokenservice.responseobjects.TokenResult;

public class CreatePublicTokenTests  extends BaseClassSetup {
	
	@Test(description = "create a public token using a unique token and then read it back")
	public void createAndReadBackAUniquePublicToken() {

		String publicToken = UUID.randomUUID().toString();
		CreatePublicTokenReq createRequest = new CreatePublicTokenReq
				.Builder()
				.defaults()
				.params(new CreatePublicTokenParams
						.Builder()
						.defaults()
						.publicToken(publicToken)
						.build())
				.build();

		CreatePublicTokenResp actualCreateResponse =  BaseRequest.getResponse(createRequest, ResponseEndpoints.createPublicTokenSuccess);
		CreatePublicTokenResp expectedCreateResponse = new CreatePublicTokenResp.Builder()
				.id(null)
				.defaults()
				.sno(actualCreateResponse.sno())
				.publicToken(publicToken)
				.build();

		Assert.assertEquals(expectedCreateResponse.publicToken(),actualCreateResponse.publicToken());
		Assert.assertTrue(actualCreateResponse.sno() > 0);


		GetTokenByTokenReq getRequest = new GetTokenByTokenReq.Builder().defaults()
				.params(new GetTokenByTokenParams
						.Builder()
						.defaults()
						.token(actualCreateResponse.publicToken()).build())
				.build(); 
		
		TokenResp actualGetResponse =  BaseRequest.getResponse(getRequest, ResponseEndpoints.getTokenByTokenSuccess);
		TokenResult expectedGetResult = new TokenResult
				.Builder()
				.defaults()
				.sessionId(createRequest.getParams().getSessionId())
				.isPublic(true)
				.sno(actualGetResponse.sno())
				.createdDate(actualGetResponse.createdDate())
				.expirationDate(actualGetResponse.expirationDate())
				.token(publicToken)
				.build();
		TokenResp expectedGetResponse = new TokenResp
				.Builder()
				.defaults()
				.result(expectedGetResult)
				.build(); 
		
		Assert.assertTrue(actualGetResponse.sno() >= 0);
		assertReflectionEquals(expectedGetResponse, actualGetResponse);
	}
	
	@Test(description = "create a public token with empty token value and then read it back")
	public void createAndReadBackPublicTokenInitiallyEmptyTokenVlaue() {

		CreatePublicTokenReq createRequest = new CreatePublicTokenReq
				.Builder()
				.defaults()
				.params(new CreatePublicTokenParams
						.Builder()
						.defaults()
						.publicToken("")
						.build())
				.build();

		CreatePublicTokenResp actualCreateResponse =  BaseRequest.getResponse(createRequest, ResponseEndpoints.createPublicTokenSuccess);

		Assert.assertTrue(actualCreateResponse.publicToken().length() > 0);
		Assert.assertTrue(actualCreateResponse.sno() > 0);

		GetTokenByTokenReq getRequest = new GetTokenByTokenReq.Builder().defaults()
				.params(new GetTokenByTokenParams
						.Builder()
						.defaults()
						.token(actualCreateResponse.publicToken()).build())
				.build(); 
		
		TokenResp actualGetResponse =  BaseRequest.getResponse(getRequest, ResponseEndpoints.getTokenByTokenSuccess);
		TokenResult expectedGetResult = new TokenResult
				.Builder()
				.defaults()
				.sessionId(createRequest.getParams().getSessionId())
				.isPublic(true)
				.sno(actualGetResponse.sno())
				.createdDate(actualGetResponse.createdDate())
				.expirationDate(actualGetResponse.expirationDate())
				.token(actualCreateResponse.publicToken())
				.build();
		TokenResp expectedGetResponse = new TokenResp
				.Builder()
				.defaults()
				.result(expectedGetResult)
				.build(); 
		
		Assert.assertTrue(actualGetResponse.sno() >= 0);
		assertReflectionEquals(expectedGetResponse, actualGetResponse);
	}
	
	@Test(description = "invoke createPublicToken using a duplicate token")
	public void createPublicTokenUsingDuplicateToken() {

		String publicToken = UUID.randomUUID().toString();
		
		CreatePublicTokenReq request = new CreatePublicTokenReq
				.Builder()
				.defaults()
				.params(new CreatePublicTokenParams
						.Builder()
						.defaults()
						.publicToken(publicToken)
						.build())
				.build();

		CreatePublicTokenResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.createPublicTokenSuccess);
		CreatePublicTokenResp expectedResponse = new CreatePublicTokenResp.Builder()
				.defaults()
				.id(actualResponse.id())
				.sno(actualResponse.sno())
				.publicToken(publicToken)
				.build();
		assertReflectionEquals(expectedResponse,actualResponse);

		CustomErrorResponse actualError =  BaseRequest.getResponse(request, ResponseEndpoints.createPublicTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(ServiceErrors.Token.UNEXPECTED_ERROR.getCode())
				.message(ServiceErrors.Token.PUBLIC_TOKEN_WAS_NOT_CREATED.getMessage())
				.id("test_id")
				.build();
		
		assertReflectionEquals(expectedError,actualError);
	}
	
	@Test(description = "invoke createPublicToken with the user_id parameter missing")
	public void createPublicTokenWithMissingUserIdParameter() {
		String publicToken = UUID.randomUUID().toString();
		
		CreatePublicTokenReq request = new CreatePublicTokenReq
				.Builder()
				.defaults()
				.params(new CreatePublicTokenParams
						.Builder()
						.defaults()
						.userId(0)
						.publicToken(publicToken)
						.build())
				.build();

		CustomErrorResponse actualError =  BaseRequest.getResponse(request, ResponseEndpoints.createPublicTokenError);
		String errorMessage = ServiceErrors.Token.MISSING_PARAMETER.getMessage() + "user_id";
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(ServiceErrors.Token.MISSING_PARAMETER.getCode())
				.message(errorMessage)
				.id("test_id")
				.build();
		
		assertReflectionEquals(expectedError,actualError);
	}

	@Test(description = "invoke createPublicToken with the provider_implementation_id parameter missing")
	public void createPublicTokenWithMmissingProviderImplementationIdParameter() {
		String publicToken = UUID.randomUUID().toString();
		
		CreatePublicTokenReq request = new CreatePublicTokenReq
				.Builder()
				.defaults()
				.params(new CreatePublicTokenParams
						.Builder()
						.defaults()
						.providerImplementationId(0)
						.publicToken(publicToken)
						.build())
				.build();

		CustomErrorResponse actualError =  BaseRequest.getResponse(request, ResponseEndpoints.createPublicTokenError);
		String errorMessage = ServiceErrors.Token.MISSING_PARAMETER.getMessage() + "provider_implementation_id";
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(ServiceErrors.Token.MISSING_PARAMETER.getCode())
				.message(errorMessage)
				.id("test_id")
				.build();
		
		assertReflectionEquals(expectedError,actualError);
	}
	
	@Test(description = "invoke createPublicToken with the product_id parameter missing")
	public void createPublicTokenWithMissingProductIdParameter() {
		String publicToken = UUID.randomUUID().toString();
		
		CreatePublicTokenReq request = new CreatePublicTokenReq
				.Builder()
				.defaults()
				.params(new CreatePublicTokenParams
						.Builder()
						.defaults()
						.productId(0)
						.publicToken(publicToken)
						.build())
				.build();

		CustomErrorResponse actualError =  BaseRequest.getResponse(request, ResponseEndpoints.createPublicTokenError);
		String errorMessage = ServiceErrors.Token.MISSING_PARAMETER.getMessage() + "product_id";
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(ServiceErrors.Token.MISSING_PARAMETER.getCode())
				.message(errorMessage)
				.id("test_id")
				.build();

		assertReflectionEquals(expectedError,actualError);
	}
	
	@Test(description = "invoke createPublicToken with the milliseconds_token_is_valid parameter missing")
	public void createPublicTokenWithMissingMillisecondsTokenIsValidParameter() {
		
		String publicToken = UUID.randomUUID().toString();
		CreatePublicTokenReq request = new CreatePublicTokenReq
				.Builder()
				.defaults()
				.params(new CreatePublicTokenParams
						.Builder()
						.defaults()
						.millisecondsTokenIsValid(0)
						.publicToken(publicToken)
						.build())
				.build();

		CustomErrorResponse actualError =  BaseRequest.getResponse(request, ResponseEndpoints.createPublicTokenError);
		String errorMessage = ServiceErrors.Token.MISSING_PARAMETER.getMessage() + "milliseconds_token_is_valid";
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(ServiceErrors.Token.MISSING_PARAMETER.getCode())
				.message(errorMessage)
				.id("test_id")
				.build();

		assertReflectionEquals(expectedError,actualError);
	}
	
	@Test(description = "invoke createPrivateToken using a public token that is too long")
	public void createPublicTokenWithAnInputTokenThatIsTooLong() {

		String token = "A123456789B123456789C123456789D123456789E123456789F123456789G123456789H123456789I123456789J123456789K";
		CreatePublicTokenReq request = new CreatePublicTokenReq
				.Builder()
				.defaults()
				.params(new CreatePublicTokenParams
						.Builder()
						.defaults()
						.publicToken(token)
						.build())
				.build();
		CustomErrorResponse actualError =  BaseRequest.getResponse(request, ResponseEndpoints.createPublicTokenError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(ServiceErrors.Token.SUPPLIED_TOKEN_IS_TOO_LONG.getCode())
				.message(ServiceErrors.Token.SUPPLIED_TOKEN_IS_TOO_LONG.getMessage())
				.id("test_id")
				.build();
		
		assertReflectionEquals(expectedError,actualError);
	}

	@Test(description = "invoke createPublicToken using an invalid method name")
	public void createPublicTokenWithInvalidMethod() {
		
		String publicToken = UUID.randomUUID().toString();
		
		CreatePublicTokenReq request = new CreatePublicTokenReq
				.Builder()
				.defaults()
				.method("INVALID_METHOD")
				.params(new CreatePublicTokenParams
						.Builder()
						.defaults()
						.publicToken(publicToken)
						.build())
				.build();

		CustomErrorResponse actualError =  BaseRequest.getResponse(request, ResponseEndpoints.createPublicTokenError);
		String errorMessage = ServiceErrors.Token.INCORRECT_METHOD.getMessage();
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(ServiceErrors.Token.INCORRECT_METHOD.getCode())
				.message(errorMessage)
				.build();
		
		assertReflectionEquals(expectedError,actualError);	
	}
}
