package tests.gbtenabledservice.response;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class GbtEnabledProductsPerCountryResp {

	@SuppressWarnings("unused")
	private String id;

	
	private Map<String, List<Integer>> result = new HashMap<>();
	
	private GbtEnabledProductsPerCountryResp(Builder builder) {
		this.id = builder.id;
		this.result.put("products", builder.products);
	}
	
	
	public static class Builder {
		
		private String id;
		private List<Integer> products;

		

		public Builder id(String id) {
			this.id = id;
			return this;
		}


		public Builder addProduct(Integer product) {
			this.products.add(product);
			return this;
		}
		
		public Builder defaults() {
			this.id = "defaultId";
			this.products = new ArrayList<>();
			return this;
		}
		
		public GbtEnabledProductsPerCountryResp build() {
			return new GbtEnabledProductsPerCountryResp(this);
		}
	}
	
}