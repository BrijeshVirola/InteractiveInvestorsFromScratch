package tests.gbtenabledservice.response;

public class IsGbtEnabledResp {
	
	@SuppressWarnings("unused")
	public String id;
	@SuppressWarnings("unused")
	public Boolean result;
	
	public IsGbtEnabledResp() {
	}

	public IsGbtEnabledResp(Builder builder) {
	
		this.id = builder.id;
		this.result = builder.result;
		}
	
	public static class Builder {
		private String id;
		private Boolean result;
	

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder result(Boolean result) {
			this.result = result;
			return this;

		}
		public Builder defaults() {
			this.id = "123456789";
			this.result = true;
			return this;


	}

		public IsGbtEnabledResp build() {
			return new IsGbtEnabledResp (this);
		}
	}
}
