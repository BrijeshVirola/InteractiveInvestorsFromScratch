package tests.gamelaunchtokenservice.request;

import java.util.HashMap;
import java.util.Map;

public class GenerateGameLaunchUrlReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Integer channel_id;

	private Map<String, Object> params = new HashMap<>();

	private GenerateGameLaunchUrlReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("product_id", builder.product_id);
		this.params.put("platform_type_id", builder.platform_type_id);
		this.params.put("country_id", builder.country_id);
		this.params.put("language_code", builder.language_code);
		this.params.put("session_id", builder.session_id);
		this.params.put("association", builder.association);
		this.params.put("launch_host", builder.launch_host);
		this.params.put("free_play", builder.free_play);
		this.params.put("regulated_game_id", builder.regulated_game_id);
		this.params.put("game_token_id", builder.game_token_id);
		this.params.put("provider_implementation_id", builder.provider_implementation_id);
	}

	public static class Builder {
		private String method, id, language_code, session_id, association, launch_host;
		private Integer product_id, platform_type_id, country_id, regulated_game_id, game_token_id,
				provider_implementation_id;
		private Boolean free_play;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder productId(Integer product_id) {
			this.product_id = product_id;
			return this;
		}

		public Builder platformTypeId(Integer platform_type_id) {
			this.platform_type_id = platform_type_id;
			return this;
		}

		public Builder countryId(Integer country_id) {
			this.country_id = country_id;
			return this;
		}

		public Builder languageCode(String language_code) {
			this.language_code = language_code;
			return this;
		}

		public Builder sessionId(String session_id) {
			this.session_id = session_id;
			return this;
		}

		public Builder association(String association) {
			this.association = association;
			return this;
		}

		public Builder launchHost(String launch_host) {
			this.launch_host = launch_host;
			return this;
		}

		public Builder freePlay(Boolean free_play) {
			this.free_play = free_play;
			return this;
		}

		public Builder regulatedGameId(Integer regulated_game_id) {
			this.regulated_game_id = regulated_game_id;
			return this;
		}

		public Builder gameTokenId(Integer game_token_id) {
			this.game_token_id = game_token_id;
			return this;
		}

		public Builder providerImplementationId(Integer provider_implementation_id) {
			this.provider_implementation_id = provider_implementation_id;
			return this;
		}

		public Builder defaults() {
			this.method = "generategamelaunchurl";
			this.id = "1";
			this.product_id = 4;
			this.platform_type_id = 1;
			this.country_id = 197;
			this.language_code = "en-GB";
			this.session_id = "41D9B93552C54A738B0E4DE0C7B6DB3D000004";
			this.association = "011";
			this.launch_host = "https://games011.b365uat.com";
			this.free_play = false;
			this.regulated_game_id = 37508;
			this.game_token_id = 7516;
			this.provider_implementation_id = 145;
			return this;
		}

		public GenerateGameLaunchUrlReq build() {
			return new GenerateGameLaunchUrlReq(this);
		}
	}
}
