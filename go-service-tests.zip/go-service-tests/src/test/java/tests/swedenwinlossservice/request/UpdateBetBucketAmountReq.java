package tests.swedenwinlossservice.request;

import java.util.HashMap;
import java.util.Map;

public class UpdateBetBucketAmountReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private UpdateBetBucketAmountReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
		this.params.put("product_id", builder.product_id);
		this.params.put("bet", builder.bet);
		this.params.put("bucket_date", builder.bucket_date);
	}

	public static class Builder {
		private String id, method, bucket_date;
		private Integer product_id, bet, user_id;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder productId(Integer product_id) {
			this.product_id = product_id;
			return this;
		}

		public Builder bet(Integer bet) {
			this.bet = bet;
			return this;
		}
		
		public Builder bucketDate(String bucket_date) {
			this.bucket_date = bucket_date;
			return this;
		}

		public Builder defaults() {
			this.method = "UpdateBetBucketAmount";
			this.id = "1";
			this.user_id = 3453426;
			this.product_id = 4;
			this.bet = 20;
			this.bucket_date = "2021-10-11T00:00:00Z";
			return this;
		}

		public UpdateBetBucketAmountReq build() {
			return new UpdateBetBucketAmountReq(this);
		}
	}
}
