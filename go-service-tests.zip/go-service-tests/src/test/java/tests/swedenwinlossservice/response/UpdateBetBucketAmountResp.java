package tests.swedenwinlossservice.response;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

public class UpdateBetBucketAmountResp {

	@SuppressWarnings("unused")
	private String id;
	
	private Map<String, Object> result = new HashMap<>();
	
	private UpdateBetBucketAmountResp(Builder builder) {
		this.id = builder.id;
		this.result.put("bucket_date", builder.bucket_date);
	}
	
	public String getId() {
		return id;
	}
	
	public Instant getBucketDate() {
		return Instant.parse(result.get("bucket_date").toString());
	}
	
	public static class Builder {
		private String id;
		private String bucket_date;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder bucketDate(String bucket_date) {
			this.bucket_date = bucket_date;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.bucket_date = "2021-10-11T00:00:00Z";
			return this;
		}
		
		public UpdateBetBucketAmountResp build() {
			return new UpdateBetBucketAmountResp(this);
		}	
	}
}
