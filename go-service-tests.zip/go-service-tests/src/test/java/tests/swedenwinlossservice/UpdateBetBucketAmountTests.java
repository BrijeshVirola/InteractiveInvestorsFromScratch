package tests.swedenwinlossservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.ExpectedFailure;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.swedenwinlossservice.request.UpdateBetBucketAmountReq;
import tests.swedenwinlossservice.response.UpdateBetBucketAmountResp;
public class UpdateBetBucketAmountTests extends BaseClassSetup {
	
	@Test(description = "Make a request to updateBetBucketAmount. Positive scenario.")
	public void updateBetBucketAmount_Positive_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		UpdateBetBucketAmountReq request = new UpdateBetBucketAmountReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		UpdateBetBucketAmountResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.updateBetBucketAmountSuccess);
		
		UpdateBetBucketAmountResp expectedResponse =  new UpdateBetBucketAmountResp.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId)
											.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to updateBetBucketAmount, cancel/rollback. Positive scenario.")
	public void updateBetBucketAmount_rollback_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		UpdateBetBucketAmountReq request = new UpdateBetBucketAmountReq.Builder()
										.defaults()
										.bet(-20)
										.bucketDate(null)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		UpdateBetBucketAmountResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.updateBetBucketAmountSuccess);
		
		Assert.assertEquals(actualResponse.getId(), idForRequestToBeEchoedBackInResponseId);
		
		Instant dateTimeNow = Instant.now();
		Instant bucketDate = actualResponse.getBucketDate();
		long timeSinceBucketCreated = Duration.between(bucketDate, dateTimeNow).toMinutes();
		Assert.assertTrue(timeSinceBucketCreated > 0);
	}
	
	@Test(description = "Make a request to UpdateBetBucketAmount. Daily bet limit exceeded.")
	public void updateBetBucketAmount_DailyBetLimitExceeded() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		UpdateBetBucketAmountReq request = new UpdateBetBucketAmountReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.userId(447492)
										.bet(15001)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.updateBetBucketAmountError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Gaming daily bet limit would be breached")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@ExpectedFailure(jiraRef="PRJSAK-1918", action="disabled test, cannot reliably create this scenario. see comments on PRJSAK-1918")
	@Test(enabled=false, description = "Make a request to UpdateBetBucketAmount. Weekly bet limit exceeded.")
	public void updateBetBucketAmount_WeeklyBetLimitExceeded() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		UpdateBetBucketAmountReq request = new UpdateBetBucketAmountReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.userId(447492)
										.bet(20001)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.updateBetBucketAmountError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Gaming weekly bet limit would be breached")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@ExpectedFailure(jiraRef="PRJSAK-1918", action="disabled test, cannot reliably create this scenario. see comments on PRJSAK-1918")
	@Test(enabled=false, description = "Make a request to UpdateBetBucketAmount. Monthly bet limit exceeded.")
	public void updateBetBucketAmount_MonthlyBetLimitExceeded() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		UpdateBetBucketAmountReq request = new UpdateBetBucketAmountReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.userId(447492)
										.bet(30001)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.updateBetBucketAmountError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Gaming monthly bet limit would be breached")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to UpdateBetBucketAmount. Missing parameter.")
	public void updateBetBucketAmount_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		UpdateBetBucketAmountReq request = new UpdateBetBucketAmountReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.userId(null)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.updateBetBucketAmountError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to UpdateBetBucketAmount. Wrong method.")
	public void updateBetBucketAmount_Wrong_Method() {

		UpdateBetBucketAmountReq request = new UpdateBetBucketAmountReq.Builder()
										.defaults()
										.id(null)
										.method("INVALID_METHOD_NAME")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.updateBetBucketAmountError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
