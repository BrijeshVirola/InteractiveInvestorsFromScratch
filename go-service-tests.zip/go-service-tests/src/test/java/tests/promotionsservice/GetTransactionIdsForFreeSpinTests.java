package tests.promotionsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigInteger;
import java.util.UUID;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.promotionsservice.request.GetTransactionIdsForFreeSpinReq;
import tests.promotionsservice.response.GetTransactionIdsForFreeSpinResp;

public class GetTransactionIdsForFreeSpinTests extends BaseClassSetup {
	
	@Test(description = "Make a request to getTransactionIdsForFreeSpin. "
			+ "Promotion token with transactions.")
	public void getTransactionIdsForFreeSpin_PromotionTokenWithTransactions() {
		
		String id = UUID.randomUUID().toString();

		GetTransactionIdsForFreeSpinReq requestBody = new GetTransactionIdsForFreeSpinReq
				.Builder().defaults()
				.id(id)
				.promotionToken("331E52D1-0E44-4CA8-A165-32F67568C560")
				.build();
				
		GetTransactionIdsForFreeSpinResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getTransactionIdsForFreeSpinSuccess);
				
		GetTransactionIdsForFreeSpinResp expectedResponse =  new GetTransactionIdsForFreeSpinResp
				.Builder()
				.defaults()
				.id(id)
				.addTransaction(new BigInteger("2157485443"))
				.addTransaction(new BigInteger("2157485444"))
				.addTransaction(new BigInteger("2157485445"))
				.addTransaction(new BigInteger("2157485446"))
				.addTransaction(new BigInteger("2157485447"))
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to getTransactionIdsForFreeSpin."
			+ " Promotion token without transactions.")
	public void getTransactionIdsForFreeSpin_PromotionTokenWithoutTransactions() {
		
		String id = UUID.randomUUID().toString();

		GetTransactionIdsForFreeSpinReq requestBody = new GetTransactionIdsForFreeSpinReq
				.Builder().defaults()
				.id(id)
				.promotionToken("331E52D1-0E44-4CA8-A165-32F67568C568")
				.build();
				
		GetTransactionIdsForFreeSpinResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getTransactionIdsForFreeSpinSuccess);
				
		GetTransactionIdsForFreeSpinResp expectedResponse =  new GetTransactionIdsForFreeSpinResp
				.Builder()
				.defaults()
				.id(id)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to getTransactionIdsForFreeSpin with invalid method.")
	public void getTransactionIdsForFreeSpin_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		GetTransactionIdsForFreeSpinReq requestBody = new GetTransactionIdsForFreeSpinReq
				.Builder().defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getTransactionIdsForFreeSpinError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getTransactionIdsForFreeSpin with missing parameter promotion token.")
	public void getTransactionIdsForFreeSpin_Missing_Promotion_Token() {
		
		String id = UUID.randomUUID().toString();
		
		GetTransactionIdsForFreeSpinReq requestBody = new GetTransactionIdsForFreeSpinReq
				.Builder().defaults()
				.id(id)
				.promotionToken(null)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getTransactionIdsForFreeSpinError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: promotion_token")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getTransactionIdsForFreeSpin invalid promotion token.")
	public void getTransactionIdsForFreeSpin_Unknown_Promotion_Token() {
		
		String id = UUID.randomUUID().toString();

		GetTransactionIdsForFreeSpinReq requestBody = new GetTransactionIdsForFreeSpinReq.Builder()
				.defaults()
				.id(id)
				.promotionToken("331E52D1-0E44-4CA8-A165-32F67568C561")
				.build();

		GetTransactionIdsForFreeSpinResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getTransactionIdsForFreeSpinSuccess);
		
		GetTransactionIdsForFreeSpinResp expectedResponse =  new GetTransactionIdsForFreeSpinResp
				.Builder()
				.defaults()
				.id(id)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
}