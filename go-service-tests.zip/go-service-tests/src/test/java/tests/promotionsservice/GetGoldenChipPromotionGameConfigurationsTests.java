package tests.promotionsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.promotionsservice.request.GetGoldenChipPromotionGameConfigurationsReq;
import tests.promotionsservice.response.GetGoldenChipPromotionGameConfigurationsResp;
import tests.promotionsservice.responseobjects.GoldenChipGameConfiguration;

public class GetGoldenChipPromotionGameConfigurationsTests extends BaseClassSetup {
	
	@Test(description = "Make a request to getgoldenchippromotiongameconfigurations for real promotion id.")
	public void getGoldenChipPromotionGameConfigurations_Positive_Scenario() {
		
		String id = UUID.randomUUID().toString();

		GetGoldenChipPromotionGameConfigurationsReq requestBody = new GetGoldenChipPromotionGameConfigurationsReq
				.Builder()
				.defaults()
				.id(id)
				.promotionId(28802)
				.build();
				
		GetGoldenChipPromotionGameConfigurationsResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getGoldenChipPromotionGameConfigurationsSuccess);
				
		GoldenChipGameConfiguration expConfiguration = new GoldenChipGameConfiguration.Builder()
				.defaults()
				.regulatedGameId(20943)
				.maxGoldenchipsPerGameround(1)
				.build();
		

		GetGoldenChipPromotionGameConfigurationsResp expectedResponse =  new GetGoldenChipPromotionGameConfigurationsResp
				.Builder()
				.defaults()
				.id(id)
				.addGameConfiguration(expConfiguration)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to getgoldenchippromotiongameconfigurations with invalid promotion id.")
	public void getGoldenChipPromotionGameConfigurations_Invalid_Promotion_Id() {
		
		String id = UUID.randomUUID().toString();
		
		GetGoldenChipPromotionGameConfigurationsReq requestBody = new GetGoldenChipPromotionGameConfigurationsReq
				.Builder()
				.defaults()
				.id(id)
				.promotionId(985181111)
				.build();
		
		GetGoldenChipPromotionGameConfigurationsResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getGoldenChipPromotionGameConfigurationsSuccess);
		GetGoldenChipPromotionGameConfigurationsResp expectedResponse =  new GetGoldenChipPromotionGameConfigurationsResp
				.Builder()
				.defaults()
				.id(id)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to getGoldenChipPromotionGameConfigurations with invalid method.")
	public void getGoldenChipPromotionGameConfigurations_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		GetGoldenChipPromotionGameConfigurationsReq requestBody = new GetGoldenChipPromotionGameConfigurationsReq
				.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getGoldenChipPromotionGameConfigurationsError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getGoldenChipPromotionGameConfigurations with missing parameter promotion id.")
	public void getGoldenChipPromotionGameConfigurations_Missing_Promotion_Id() {
		
		String id = UUID.randomUUID().toString();

		GetGoldenChipPromotionGameConfigurationsReq requestBody = new GetGoldenChipPromotionGameConfigurationsReq.Builder()
				.defaults()
				.promotionId(null)
				.id(id)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getGoldenChipPromotionGameConfigurationsError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing required parameter: promotion_id")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}