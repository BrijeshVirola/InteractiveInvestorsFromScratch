package tests.promotionsservice.responseobjects;

public class CurrencyConversionMultiplier {
	
	@SuppressWarnings("unused")
	private String currency_code;
	@SuppressWarnings("unused")
	private String multiplier;
	
	public CurrencyConversionMultiplier(String currencyCode, String multiplier) {
		this.currency_code = currencyCode;
		this.multiplier = multiplier;
	}
}
