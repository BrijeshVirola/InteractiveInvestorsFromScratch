package tests.promotionsservice.responseobjects;

import java.math.BigDecimal;

public class GoldenChip {
	
	Integer qty;
	BigDecimal uoc_value; 
	
	public GoldenChip(Integer quantity, BigDecimal valueInUserCurrency) {
		qty = quantity;
		uoc_value = valueInUserCurrency;
	}
}
