package tests.promotionsservice.responseobjects;

public class GoldenChipGameConfiguration {
	
	Integer regulated_game_id;
	Integer max_goldenchips_per_gameround;
	
	private GoldenChipGameConfiguration(Builder builder) {
		this.regulated_game_id = builder.regulated_game_id;
		this.max_goldenchips_per_gameround = builder.max_goldenchips_per_gameround;
	}
	
	public static class Builder {
		
		Integer regulated_game_id;
		Integer max_goldenchips_per_gameround;
		
		public Builder regulatedGameId(Integer regulatedGameId) {
			this.regulated_game_id = regulatedGameId;
			return this;
		}
		
		public Builder maxGoldenchipsPerGameround(Integer maxGoldenchipsPerGameround) {
			this.max_goldenchips_per_gameround = maxGoldenchipsPerGameround;
			return this;
		}
		
		public Builder defaults() {
			this.regulated_game_id = 6403;
			this.max_goldenchips_per_gameround = 1;
			return this;
		}
		
		public GoldenChipGameConfiguration build() {
			return new GoldenChipGameConfiguration(this);
		}
	}
}
