package tests.promotionsservice.responseobjects;

public class FreeSpinGameConfiguration {
	
	Integer regulated_game_id;
	String gbp_bet_per_line;
	Integer number_of_lines;
	
	private FreeSpinGameConfiguration(Builder builder) {
		this.regulated_game_id = builder.regulated_game_id;
		this.gbp_bet_per_line = builder.gbp_bet_per_line;
		this.number_of_lines = builder.number_of_lines;
	}
	
	public static class Builder {
		
		Integer regulated_game_id;
		String gbp_bet_per_line;
		Integer number_of_lines;
		
		public Builder regulatedGameId(Integer regulatedGameId) {
			this.regulated_game_id = regulatedGameId;
			return this;
		}
		
		public Builder gbpBetPerLine(String gbpBetPerLine) {
			this.gbp_bet_per_line = gbpBetPerLine;
			return this;
		}
		
		public Builder numberOfLines(Integer numberOfLines) {
			this.number_of_lines = numberOfLines;
			return this;
		}
		
		public Builder defaults() {
			this.regulated_game_id = 6403;
			this.gbp_bet_per_line = "0.1";
			this.number_of_lines = 10;
			return this;
		}
		
		public FreeSpinGameConfiguration build() {
			return new FreeSpinGameConfiguration(this);
		}
	}
}
