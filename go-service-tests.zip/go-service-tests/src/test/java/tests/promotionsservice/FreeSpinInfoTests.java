package tests.promotionsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.util.UUID;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.promotionsservice.request.FreeSpinInfoReq;
import tests.promotionsservice.response.FreeSpinInfoResp;

public class FreeSpinInfoTests extends BaseClassSetup {
	
	@Test(description = "Make a request to freespininfo. Claimed and closed promotion.")
	public void freespininfo_Claimed_And_Closed() {
		
		String id = UUID.randomUUID().toString();

		FreeSpinInfoReq requestBody = new FreeSpinInfoReq
				.Builder()
				.defaults()
				.id(id)
				.promotionToken("539AF4E9-2C9B-48CC-A0BB-0726E892A4EC").build();
				
		FreeSpinInfoResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.freeSpinInfoSuccess);
				
		FreeSpinInfoResp expectedResponse =  new FreeSpinInfoResp
				.Builder()
				.defaults()
				.id(id)
				.promotionId(28603)
				.userId(2586877)
				.expiryDateUtc("2021-10-21T14:08:07.807Z")
				.claimedDateUtc("2021-10-21T14:07:07.79Z")
				.promotionCloseReasonId(2)
				.totalSpins(1)
				.remainingSpins(1)
				.currencyConversionMultiplierId(1)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to freespininfo. Only claimed promotion.")
	public void freespininfo_Only_Claimed() {
		
		String id = UUID.randomUUID().toString();
		
		FreeSpinInfoReq requestBody = new FreeSpinInfoReq
				.Builder()
				.defaults()
				.id(id)
				.promotionToken("564B365D-9C07-444A-8099-1AF030059139")
				.build();
				
		FreeSpinInfoResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.freeSpinInfoSuccess);
				
		FreeSpinInfoResp expectedResponse =  new FreeSpinInfoResp
				.Builder()
				.defaults()
				.id(id)
				.promotionId(28618)
				.userId(4630132)
				.expiryDateUtc("2023-03-06T09:56:33.767Z")
				.claimedDateUtc("2021-10-22T09:56:33.767Z")
				.promotionCloseReasonId(0)
				.totalSpins(10)
				.remainingSpins(10)
				.currencyConversionMultiplierId(1)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to freespininfo. Claimed and open promotion. Played several spins.")
	public void freespininfo_Claimed_And_Spent_Some_Spins() {
		
		String id = UUID.randomUUID().toString();
		
		FreeSpinInfoReq requestBody = new FreeSpinInfoReq
				.Builder()
				.defaults()
				.id(id)
				.promotionToken("331E52D1-0E44-4CA8-A165-32F67568C560")
				.build();
				
		FreeSpinInfoResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.freeSpinInfoSuccess);
				
		FreeSpinInfoResp expectedResponse =  new FreeSpinInfoResp
				.Builder()
				.defaults()
				.id(id)
				.promotionId(28618)
				.userId(4630337)
				.expiryDateUtc("2023-03-06T10:18:44.683Z")
				.claimedDateUtc("2021-10-22T10:18:44.683Z")
				.promotionCloseReasonId(0)
				.totalSpins(10)
				.remainingSpins(7)
				.currencyConversionMultiplierId(1)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to freespininfo with invalid method.")
	public void freespininfo_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		FreeSpinInfoReq requestBody = new FreeSpinInfoReq
				.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.freeSpinInfoError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to freespininfo with missing parameter promotion token.")
	public void freespininfo_Missing_Promotion_Token() {
		
		String id = UUID.randomUUID().toString();

		FreeSpinInfoReq requestBody = new FreeSpinInfoReq.Builder()
				.defaults()
				.promotionToken(null)
				.id(id)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.freeSpinInfoError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: promotion_token")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getfreespininfoUserById invalid promotion token.")
	public void freespininfo_Unknown_PromotionToken() {
		
		String id = UUID.randomUUID().toString();

		FreeSpinInfoReq requestBody = new FreeSpinInfoReq.Builder()
				.defaults()
				.id(id)
				.promotionToken("331E52D1-0E44-4CA8-A165-32F67568C561")
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.freeSpinInfoError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Invalid token")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}