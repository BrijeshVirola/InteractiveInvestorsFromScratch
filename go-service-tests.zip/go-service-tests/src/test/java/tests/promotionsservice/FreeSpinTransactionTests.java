package tests.promotionsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.promotionsservice.request.FreeSpinTransactionReq;
import tests.promotionsservice.request.GetTransactionIdsForFreeSpinReq;
import tests.promotionsservice.response.FreeSpinTransactionResp;
import tests.promotionsservice.response.GetTransactionIdsForFreeSpinResp;

public class FreeSpinTransactionTests extends BaseClassSetup {
	
	@Test(description = "Make a request to FreeSpinTransaction with new transaction and check it is added.")
	public void freeSpinTransaction_New_Transaction() {
		
		String id = UUID.randomUUID().toString();
		BigInteger randomTrnId = new BigInteger(40, new Random());
		String promotionToken = "88268cfa-3632-11ec-8d3d-0242ac130003";

		GetTransactionIdsForFreeSpinReq getTransactionsBody = new GetTransactionIdsForFreeSpinReq
				.Builder().defaults()
				.promotionToken(promotionToken)
				.build();
				
		//Get transactions before creating FreeSpinTransaction
		GetTransactionIdsForFreeSpinResp getTransactionsResponse =  BaseRequest.getResponse(getTransactionsBody, ResponseEndpoints.getTransactionIdsForFreeSpinSuccess);
		List<BigInteger> expTransactions = getTransactionsResponse.getTransactions();
		expTransactions.add(randomTrnId);
		Collections.sort(expTransactions);
		
		FreeSpinTransactionReq body = new FreeSpinTransactionReq.Builder()
				.defaults()
				.id(id)
				.bet365GamesTransactionId(randomTrnId)
				.taxableAmount(new BigDecimal("1"))
				.promotionToken(promotionToken)
				.build();
		
		FreeSpinTransactionResp actResponse =  BaseRequest.getResponse(body, ResponseEndpoints.freeSpinTransactionSuccess);
		FreeSpinTransactionResp	expResponse = new FreeSpinTransactionResp.Builder()
				.defaults()
				.id(id)
				.result("OK")
				.build();
		
		assertReflectionEquals(expResponse, actResponse);
		
		//Get transactions after creating FreeSpinTransaction
		getTransactionsResponse =  BaseRequest.getResponse(getTransactionsBody, ResponseEndpoints.getTransactionIdsForFreeSpinSuccess);
		List<BigInteger> actTransactions = getTransactionsResponse.getTransactions();
		
		assertReflectionEquals(expTransactions, actTransactions);
	}
	
	@Test(description = "Make a request to FreeSpinTransaction with existing transaction and check it is not added.")
	public void freeSpinTransaction_Existing_Transaction() {
		
		String id = UUID.randomUUID().toString();
		BigInteger randomTrnId = new BigInteger("793429161006");
		String promotionToken = "564B365D-9C07-444A-8099-1AF030059139";

		GetTransactionIdsForFreeSpinReq getTransactionsBody = new GetTransactionIdsForFreeSpinReq
				.Builder().defaults()
				.promotionToken(promotionToken)
				.build();
				
		//Get transactions before creating FreeSpinTransaction
		GetTransactionIdsForFreeSpinResp getTransactionsResponse =  BaseRequest.getResponse(getTransactionsBody, ResponseEndpoints.getTransactionIdsForFreeSpinSuccess);
		List<BigInteger> expTransactions = getTransactionsResponse.getTransactions();
		
		FreeSpinTransactionReq body = new FreeSpinTransactionReq.Builder()
				.defaults()
				.id(id)
				.bet365GamesTransactionId(randomTrnId)
				.taxableAmount(new BigDecimal("0.2"))
				.promotionToken(promotionToken)
				.build();
		
		FreeSpinTransactionResp actResponse =  BaseRequest.getResponse(body, ResponseEndpoints.freeSpinTransactionSuccess);
		FreeSpinTransactionResp	expResponse = new FreeSpinTransactionResp.Builder()
				.defaults()
				.id(id)
				.result("OK")
				.build();
		
		assertReflectionEquals(expResponse, actResponse);
		
		//Get transactions after creating FreeSpinTransaction
		getTransactionsResponse =  BaseRequest.getResponse(getTransactionsBody, ResponseEndpoints.getTransactionIdsForFreeSpinSuccess);
		List<BigInteger> actTransactions = getTransactionsResponse.getTransactions();
		
		assertReflectionEquals(expTransactions, actTransactions);
	}
	
	@Test(description = "Make a request to freeSpinTransaction with invalid method.")
	public void freeSpinTransaction_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		FreeSpinTransactionReq requestBody = new FreeSpinTransactionReq.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.freeSpinTransactionError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to freeSpinTransaction with missing parameter bet365_games_transaction_id.")
	public void freeSpinTransaction_Missing_Bet365_Games_Transaction_Id() {
		
		String id = UUID.randomUUID().toString();

		FreeSpinTransactionReq requestBody = new FreeSpinTransactionReq.Builder()
				.defaults()
				.id(id)
				.bet365GamesTransactionId(null)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.freeSpinTransactionError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: bet365_games_transaction_id")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to freeSpinTransaction with insufficient free spins.")
	public void freeSpinTransaction_Insufficient_Free_Spins() {
		
		String id = UUID.randomUUID().toString();
		
		FreeSpinTransactionReq requestBody = new FreeSpinTransactionReq.Builder()
				.defaults()
				.id(id)
				.bet365GamesTransactionId(new BigInteger("680641111832"))
				.taxableAmount(new BigDecimal("-1.00"))
				.promotionToken("ea897c4a-82b7-44b7-bfc1-e94adb6cd74e")
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.freeSpinTransactionError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1003)
				.message("No free spins remaining")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}