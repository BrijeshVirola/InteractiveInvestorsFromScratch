package tests.promotionsservice.request;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import tests.promotionsservice.responseobjects.GoldenChip;

public class AdjustGoldenChipsReq {
	
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private Params Params;

	private AdjustGoldenChipsReq(Builder builder) {
		this.Method = builder.Method;
		this.ID = builder.id;
		Params = new Params(builder);
	}
	
	public static class Builder {
		
		private String Method;
		private String id;
		private String promotion_token;
		private BigInteger source_bet365_games_transaction_id;
		private BigInteger bet365_games_transaction_id;
		private List<GoldenChip> goldenchips;

		public Builder method(String method) {
			this.Method = method;
			return this;
		}
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder promotionToken(String promotionToken) {
			this.promotion_token = promotionToken;
			return this;
		}
		
		public Builder sourceBet365GamesTransactionId(BigInteger sourceBet365GamesTransactionId) {
			source_bet365_games_transaction_id = sourceBet365GamesTransactionId;
			return this;
		}
		
		public Builder bet365GamesTransactionId(BigInteger bet365GamesTransactionId) {
			bet365_games_transaction_id = bet365GamesTransactionId;
			return this;
		}
		
		public Builder goldenchips(List<GoldenChip> goldenchips) {
			this.goldenchips = goldenchips;
			return this;
		}
		
		public Builder addGoldenChip(GoldenChip goldenChip) {
			goldenchips.add(goldenChip);
			return this;
		}
		
		
		public Builder defaults() {
			Method = "AdjustGoldenChips";
			id = "defaultTestId";
			promotion_token = "6e1a73b1-2c99-4d7f-a2c3-057b7776dfe2";
			bet365_games_transaction_id = new BigInteger("0");
			goldenchips = new ArrayList<GoldenChip>();
			
			return this;
		}
		
		public AdjustGoldenChipsReq build() {
			return new AdjustGoldenChipsReq(this);
		}
	}
	
	private class Params {
		
		@SuppressWarnings("unused")
		String promotion_token;
		@SuppressWarnings("unused")
		BigInteger source_bet365_games_transaction_id;
		@SuppressWarnings("unused")
		BigInteger bet365_games_transaction_id;
		@SuppressWarnings("unused")
		List<GoldenChip> goldenchips;

		public Params(Builder builder) {
			promotion_token = builder.promotion_token;
			source_bet365_games_transaction_id = builder.source_bet365_games_transaction_id;
			bet365_games_transaction_id = builder.bet365_games_transaction_id;
			goldenchips = builder.goldenchips;
		}

	}
}