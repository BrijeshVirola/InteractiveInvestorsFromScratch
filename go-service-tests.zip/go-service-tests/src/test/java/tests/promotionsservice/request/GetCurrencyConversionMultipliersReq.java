package tests.promotionsservice.request;

import java.math.BigInteger;

public class GetCurrencyConversionMultipliersReq {
	
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private Params Params;
	
	public GetCurrencyConversionMultipliersReq(Builder builder) {
		this.Method = builder.Method;
		this.ID = builder.ID;
		this.Params = new Params(builder);
	}
	
	public static class Builder {
		private String Method;
		private String ID;
		private BigInteger currency_conversion_multiplier_id;

		public Builder id(String id) {
			this.ID = id;
			return this;
		}
		
		public Builder currencyConversionMultiplierId(BigInteger currencyConversionMultiplierId) {
			this.currency_conversion_multiplier_id = currencyConversionMultiplierId;
			return this;
		}
		
		public Builder method(String method) {
			this.Method = method;
			return this;
		}
		
		public Builder defaults() {
			this.Method = "getcurrencyconversionmultipliers";
			this.ID = "defaultTestId";
			this.currency_conversion_multiplier_id = new BigInteger("1");
			return this;
		}
		
		public GetCurrencyConversionMultipliersReq build() {
			return new GetCurrencyConversionMultipliersReq(this);
		}
	}
	
	private class Params {
		@SuppressWarnings("unused")
		BigInteger currency_conversion_multiplier_id;
		
		public Params(Builder builder) {
			this.currency_conversion_multiplier_id = builder.currency_conversion_multiplier_id;
		}
	}
}