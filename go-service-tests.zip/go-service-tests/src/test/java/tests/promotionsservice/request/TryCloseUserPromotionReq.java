package tests.promotionsservice.request;

public class TryCloseUserPromotionReq {
	
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private Params Params;
	
	private TryCloseUserPromotionReq(Builder builder) {
		this.Method = builder.Method;
		this.ID = builder.ID;
		this.Params = new Params(builder);
	}
	
	public static class Builder {
		private String Method;
		private String ID;
		private String promotion_token;
		private Integer promotion_close_reason_id;

		public Builder id(String id) {
			this.ID = id;
			return this;
		}
		
		public Builder promotionToken(String promotionToken) {
			this.promotion_token = promotionToken;
			return this;
		}
		
		public Builder promotionCloseReasonId(Integer promotionCloseReasonId) {
			this.promotion_close_reason_id = promotionCloseReasonId;
			return this;
		}
		
		public Builder method(String method) {
			this.Method = method;
			return this;
		}
		
		public Builder defaults() {
			this.Method = "trycloseuserpromotion";
			this.ID = "defaultTestId";
			this.promotion_token = "331E52D1-0E44-4CA8-A165-32F67568C560";
			this.promotion_close_reason_id = 1;
			return this;
		}
		
		public TryCloseUserPromotionReq build() {
			return new TryCloseUserPromotionReq(this);
		}
	}
	
	private class Params {
		@SuppressWarnings("unused")
		private String promotion_token;
		@SuppressWarnings("unused")
		private Integer promotion_close_reason_id;
		
		public Params(Builder builder) {
			this.promotion_token = builder.promotion_token;
			this.promotion_close_reason_id = builder.promotion_close_reason_id;
		}
	}
}