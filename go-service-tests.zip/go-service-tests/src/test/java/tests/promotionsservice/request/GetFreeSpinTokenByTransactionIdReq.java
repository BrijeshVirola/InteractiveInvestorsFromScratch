package tests.promotionsservice.request;

import java.math.BigInteger;

public class GetFreeSpinTokenByTransactionIdReq {
	
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private Params Params;
	
	private GetFreeSpinTokenByTransactionIdReq(Builder builder) {
		this.Method = builder.Method;
		this.ID = builder.ID;
		this.Params = new Params(builder);
	}
	
	public static class Builder {
		private String Method;
		private String ID;
		private BigInteger bet365_games_transaction_id;

		public Builder id(String id) {
			this.ID = id;
			return this;
		}
		
		public Builder bet365GamesTransactionId(BigInteger bet365GamesTransactionId) {
			this.bet365_games_transaction_id = bet365GamesTransactionId;
			return this;
		}
		
		public Builder method(String method) {
			this.Method = method;
			return this;
		}
		
		public Builder defaults() {
			this.Method = "getfreespintokenbytransactionid";
			this.ID = "defaultTestId";
			this.bet365_games_transaction_id = new BigInteger("1");
			return this;
		}
		
		public GetFreeSpinTokenByTransactionIdReq build() {
			return new GetFreeSpinTokenByTransactionIdReq(this);
		}
	}
	
	private class Params {
		@SuppressWarnings("unused")
		BigInteger bet365_games_transaction_id;
		
		public Params(Builder builder) {
			this.bet365_games_transaction_id = builder.bet365_games_transaction_id;
		}
	}
}