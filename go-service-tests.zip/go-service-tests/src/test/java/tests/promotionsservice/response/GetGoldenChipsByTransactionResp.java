package tests.promotionsservice.response;

import java.util.ArrayList;
import java.util.List;

import tests.promotionsservice.responseobjects.GoldenChip;

public class GetGoldenChipsByTransactionResp {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Result result;

	private GetGoldenChipsByTransactionResp(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}
	
	public static class Builder {
		
		private String id;
		List<GoldenChip> goldenchips;
		private String promotion_token;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder addGoldenChip(GoldenChip goldenChip) {
			goldenchips.add(goldenChip);
			return this;
		}
		
		public Builder promotionToken(String promotionToken) {
			this.promotion_token = promotionToken;
			return this;
		}
		
		public Builder defaults() {
			this.id = "defaultTestId";
			this.goldenchips = new ArrayList<GoldenChip>();
			
			return this;
		}
		
		public GetGoldenChipsByTransactionResp build() {
			return new GetGoldenChipsByTransactionResp(this);
		}
	}
	
	private class Result {
		
		@SuppressWarnings("unused")
		List<GoldenChip> goldenchips;
		@SuppressWarnings("unused")
		String promotion_token;

		public Result(Builder builder) {
			this.goldenchips = builder.goldenchips;
			this.promotion_token = builder.promotion_token;
		}

	}
}