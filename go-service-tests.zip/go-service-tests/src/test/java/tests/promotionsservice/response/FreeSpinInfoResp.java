package tests.promotionsservice.response;

public class FreeSpinInfoResp {
	
	@SuppressWarnings("unused")
	private String id;
	private Result result;
	
	private FreeSpinInfoResp(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}
	
	public Integer getPromotion_close_reason_id() {
		return result.promotion_close_reason_id;
	}

	public static class Builder {
		
		private String id;
		private Integer promotion_id;
		private Integer user_id;
		private String expiry_date_utc;
		private String claimed_date_utc;
		private Integer promotion_close_reason_id;
		private Integer total_spins;
		private Integer remaining_spins;
		private Integer currency_conversion_multiplier_id;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder promotionId(Integer promotionId) {
			this.promotion_id = promotionId;
			return this;
		}
		
		public Builder userId(Integer userId) {
			this.user_id = userId;
			return this;
		}
		
		public Builder expiryDateUtc(String expiryDateUtc) {
			this.expiry_date_utc = expiryDateUtc;
			return this;
		}
		
		public Builder claimedDateUtc(String claimedDateUtc) {
			this.claimed_date_utc = claimedDateUtc;
			return this;
		}
		
		public Builder promotionCloseReasonId(Integer promotionCloseReasonId) {
			this.promotion_close_reason_id = promotionCloseReasonId;
			return this;
		}
		
		public Builder totalSpins(Integer totalSpins) {
			this.total_spins = totalSpins;
			return this;
		}
		
		public Builder remainingSpins(Integer remainingSpins) {
			this.remaining_spins = remainingSpins;
			return this;
		}
		
		public Builder currencyConversionMultiplierId(Integer currencyConversionMultiplierId) {
			this.currency_conversion_multiplier_id = currencyConversionMultiplierId;
			return this;
		}
		
		public Builder defaults() {
			this.id = null;
			this.promotion_id = 28218;
			this.user_id = 2587401;
			this.expiry_date_utc = "2021-10-07T17:16:18.651Z";
			this.claimed_date_utc = "2021-10-07T15:36:18.637Z";
			this.promotion_close_reason_id = 0;
			this.total_spins = 10;
			this.remaining_spins = 4;
			this.currency_conversion_multiplier_id = 1;
			
			return this;
		}
		
		public FreeSpinInfoResp build() {
			return new FreeSpinInfoResp(this);
		}
	}
	
	private class Result {
		
		@SuppressWarnings("unused")
		Integer promotion_id;
		@SuppressWarnings("unused")
		Integer user_id;
		@SuppressWarnings("unused")
		String expiry_date_utc;
		@SuppressWarnings("unused")
		String claimed_date_utc;
		Integer promotion_close_reason_id;
		@SuppressWarnings("unused")
		Integer total_spins;
		@SuppressWarnings("unused")
		Integer remaining_spins;
		@SuppressWarnings("unused")
		Integer currency_conversion_multiplier_id;
		
		public Result(Builder builder) {
			this.promotion_id = builder.promotion_id;
			this.user_id = builder.user_id;
			this.expiry_date_utc = builder.expiry_date_utc;
			this.claimed_date_utc = builder.claimed_date_utc;
			this.promotion_close_reason_id = builder.promotion_close_reason_id;
			this.total_spins = builder.total_spins;
			this.remaining_spins = builder.remaining_spins;
			this.currency_conversion_multiplier_id = builder.currency_conversion_multiplier_id;
		}
	}
}