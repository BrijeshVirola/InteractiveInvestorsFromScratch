package tests.promotionsservice.response;

public class GetGoldenChipUserPromotionDetailsResp {
	
	@SuppressWarnings("unused")
	private String id;
	private Result result;
	
	private GetGoldenChipUserPromotionDetailsResp(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}
	
	public Integer getPromotion_close_reason_id() {
		return result.promotion_close_reason_id;
	}

	public static class Builder {
		
		private String id;
		private Integer promotion_id;
		private String expiry_date_utc;
		private Integer promotion_close_reason_id;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder promotionId(Integer promotionId) {
			this.promotion_id = promotionId;
			return this;
		}
		
		public Builder expiryDateUtc(String expiryDateUtc) {
			this.expiry_date_utc = expiryDateUtc;
			return this;
		}
		
		public Builder promotionCloseReasonId(Integer promotionCloseReasonId) {
			this.promotion_close_reason_id = promotionCloseReasonId;
			return this;
		}
		
		public Builder defaults() {
			this.id = "defaultId";
			this.promotion_id = 19732;
			this.expiry_date_utc = "2021-10-07T17:16:18.651Z";
			this.expiry_date_utc = "2021-10-07T15:36:18.637Z";
			this.promotion_close_reason_id = 0;
			
			return this;
		}
		
		public GetGoldenChipUserPromotionDetailsResp build() {
			return new GetGoldenChipUserPromotionDetailsResp(this);
		}
	}
	
	private class Result {
		
		@SuppressWarnings("unused")
		Integer promotion_id;
		@SuppressWarnings("unused")
		String expiry_date_utc;
		Integer promotion_close_reason_id;
		
		public Result(Builder builder) {
			this.promotion_id = builder.promotion_id;
			this.expiry_date_utc = builder.expiry_date_utc;
			this.promotion_close_reason_id = builder.promotion_close_reason_id;
		}
	}
}