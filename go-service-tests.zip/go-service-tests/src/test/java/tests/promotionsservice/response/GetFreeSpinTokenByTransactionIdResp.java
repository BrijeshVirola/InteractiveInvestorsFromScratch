package tests.promotionsservice.response;

import java.util.UUID;

public class GetFreeSpinTokenByTransactionIdResp {
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Result result;
	
	private GetFreeSpinTokenByTransactionIdResp(Builder builder) {
		this.id = builder.id;
		this.result = new Result(builder);
	}

	public static class Builder {
		private String id;
		private UUID promotion_token;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder promotionToken(UUID promotionToken) {
			this.promotion_token = promotionToken;
			return this;
		}
		
		public Builder defaults() {
			this.id = "defaultId";
			this.promotion_token = UUID.randomUUID();
			return this;
		}
		
		public GetFreeSpinTokenByTransactionIdResp build() {
			return new GetFreeSpinTokenByTransactionIdResp(this);
		}
	}
	
	private class Result {
		
		@SuppressWarnings("unused")
		private UUID promotion_token;
		
		public Result(Builder builder) {
			this.promotion_token = builder.promotion_token;
		}
	}
}
