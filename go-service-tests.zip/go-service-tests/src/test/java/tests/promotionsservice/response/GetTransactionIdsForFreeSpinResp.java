package tests.promotionsservice.response;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class GetTransactionIdsForFreeSpinResp {
	
	@SuppressWarnings("unused")
	private String id;
	private Result result;

	private GetTransactionIdsForFreeSpinResp(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}
	
	public List<BigInteger> getTransactions() {
		return result.getTransactions();
	}

	public static class Builder {
		
		private String id;
		List<BigInteger> transactions;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder addTransaction(BigInteger transaction) {
			transactions.add(transaction);
			return this;
		}
		
		public Builder defaults() {
			this.id = "defaultTestId";
			this.transactions = new ArrayList<BigInteger>();
			
			return this;
		}
		
		public GetTransactionIdsForFreeSpinResp build() {
			return new GetTransactionIdsForFreeSpinResp(this);
		}
	}
	
	private class Result {
		
		List<BigInteger> transactions;

		public Result(Builder builder) {
			this.transactions = builder.transactions;
		}
		
		public List<BigInteger> getTransactions() {
			return transactions;
		}
	}
}