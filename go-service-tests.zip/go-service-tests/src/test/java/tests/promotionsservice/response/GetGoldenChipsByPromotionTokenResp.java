package tests.promotionsservice.response;

import java.util.ArrayList;
import java.util.List;

import tests.promotionsservice.responseobjects.GoldenChip;

public class GetGoldenChipsByPromotionTokenResp {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Result result;

	private GetGoldenChipsByPromotionTokenResp(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}
	
	public static class Builder {
		
		private String id;
		List<GoldenChip> available;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder addGoldenChip(GoldenChip goldenChip) {
			available.add(goldenChip);
			return this;
		}
		
		public Builder defaults() {
			this.id = "defaultTestId";
			this.available = new ArrayList<GoldenChip>();
			
			return this;
		}
		
		public GetGoldenChipsByPromotionTokenResp build() {
			return new GetGoldenChipsByPromotionTokenResp(this);
		}
	}
	
	private class Result {
		
		@SuppressWarnings("unused")
		List<GoldenChip> available;

		public Result(Builder builder) {
			this.available = builder.available;
		}

	}
}