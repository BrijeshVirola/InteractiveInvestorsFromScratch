package tests.promotionsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigInteger;
import java.util.UUID;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.promotionsservice.request.GetFreeSpinTokenByTransactionIdReq;
import tests.promotionsservice.response.GetFreeSpinTokenByTransactionIdResp;

public class GetFreeSpinTokenByTransactionIdTests extends BaseClassSetup {
	
	@DataProvider(name =  "getFreeSpinTokenByTransactionId")
	private Object[][] getFreeSpinTokenByTransactionId() {
		return new Object[][] {
			{new BigInteger("2821854556"), UUID.fromString("88268cfa-3632-11ec-8d3d-0242ac130003")},
			{new BigInteger("2157485444"), UUID.fromString("331e52d1-0e44-4ca8-a165-32f67568c560")}
		};
	}
	
	@Test(description = "Make a request to getFreeSpinTokenByTransactionId. Positive scenario.", dataProvider = "getFreeSpinTokenByTransactionId")
	public void getFreeSpinTokenByTransactionId_Promotion_Transaction_With_Free_Spin_Token(BigInteger transactionId, UUID promotionToken) {
		
		String id = UUID.randomUUID().toString();

		GetFreeSpinTokenByTransactionIdReq requestBody = new GetFreeSpinTokenByTransactionIdReq
				.Builder().defaults()
				.id(id)
				.bet365GamesTransactionId(transactionId)
				.build();
				
		GetFreeSpinTokenByTransactionIdResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getFreeSpinTokenByTransactionIdSuccess);
				
		GetFreeSpinTokenByTransactionIdResp expectedResponse =  new GetFreeSpinTokenByTransactionIdResp
				.Builder()
				.defaults()
				.id(id)
				.promotionToken(promotionToken)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to getFreeSpinTokenByTransactionId with transaction not belonging to free spin token.")
	public void getFreeSpinTokenByTransactionId_Transaction_Without_Free_Spin_Token() {
		
		String id = UUID.randomUUID().toString();

		GetFreeSpinTokenByTransactionIdReq requestBody = new GetFreeSpinTokenByTransactionIdReq
				.Builder().defaults()
				.id(id)
				.bet365GamesTransactionId(new BigInteger("2157485442"))
				.build();
				
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getFreeSpinTokenByTransactionIdError);
				
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1004)
				.message("Free Spin token not found")
				.id(id)
				.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to getFreeSpinTokenByTransactionId with invalid method.")
	public void getFreeSpinTokenByTransactionId_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		GetFreeSpinTokenByTransactionIdReq requestBody = new GetFreeSpinTokenByTransactionIdReq
				.Builder().defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getFreeSpinTokenByTransactionIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getFreeSpinTokenByTransactionId with missing parameter bet365_games_transaction_id.")
	public void getFreeSpinTokenByTransactionId_Missing_Bet365_Games_Transaction_Id() {
		
		String id = UUID.randomUUID().toString();
		
		GetFreeSpinTokenByTransactionIdReq requestBody = new GetFreeSpinTokenByTransactionIdReq
				.Builder().defaults()
				.id(id)
				.bet365GamesTransactionId(null)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getFreeSpinTokenByTransactionIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: bet365_games_transaction_id")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}