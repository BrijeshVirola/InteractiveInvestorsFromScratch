package tests.promotionsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import java.util.UUID;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.promotionsservice.request.FreeSpinInfoReq;
import tests.promotionsservice.request.TryCloseUserPromotionReq;
import tests.promotionsservice.response.FreeSpinInfoResp;
import tests.promotionsservice.response.TryCloseUserPromotionResp;

public class TryCloseUserPromotionTests extends BaseClassSetup {
	
	@DataProvider
	private Object[][] closeReasonId() {
		return new Object[][] {
			{1, "ec0c5e75-385c-4c3e-b86e-1f557fe2aff5"},
			{2, "8a5167c9-9ff1-4997-ba27-6f1b4e01156b"},
			{3, "32fd1795-77d3-4fc7-8cb9-098eace15d8a"}
			};
	}
	
	@Test(description = "Make a request to trycloseuserpromotion.", dataProvider =  "closeReasonId")
	public void tryCloseUserPromotion_PositiveScenario(Integer closeReasonId, String promotionToken) {
		
		String id = UUID.randomUUID().toString();

		TryCloseUserPromotionReq requestBody = new TryCloseUserPromotionReq
				.Builder().defaults()
				.id(id)
				.promotionToken(promotionToken)
				.promotionCloseReasonId(closeReasonId)
				.build();
				
		TryCloseUserPromotionResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.tryCloseUserPromotionSuccess);
				
		TryCloseUserPromotionResp expectedResponse =  new TryCloseUserPromotionResp
				.Builder()
				.defaults()
				.id(id)
				.result("OK")
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
		
		FreeSpinInfoReq requestBody2 = new FreeSpinInfoReq
				.Builder()
				.defaults()
				.id(id)
				.promotionToken(promotionToken).build();
				
		FreeSpinInfoResp actualResponse2 =  BaseRequest.getResponse(requestBody2, ResponseEndpoints.freeSpinInfoSuccess);
		actualResponse2.getPromotion_close_reason_id();
		
		assertThat("Promotion close reason id", actualResponse2.getPromotion_close_reason_id(), equalTo(closeReasonId));
	}
	
	@Test(description = "Make a request to trycloseuserpromotion with invalid method.")
	public void tryCloseUserPromotion_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();

		TryCloseUserPromotionReq requestBody = new TryCloseUserPromotionReq
				.Builder().defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();
				
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.tryCloseUserPromotionError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to tryCloseUserPromotion with missing parameter promotion_close_reason_id.")
	public void tryCloseUserPromotion_Missing_Promotion_Token() {
		
		String id = UUID.randomUUID().toString();
		
		TryCloseUserPromotionReq requestBody = new TryCloseUserPromotionReq
				.Builder().defaults()
				.id(id)
				.promotionCloseReasonId(null)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.tryCloseUserPromotionError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: promotion_close_reason_id")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}