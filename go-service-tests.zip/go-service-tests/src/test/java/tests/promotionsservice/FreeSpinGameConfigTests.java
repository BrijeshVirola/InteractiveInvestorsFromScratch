package tests.promotionsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.util.UUID;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.promotionsservice.request.FreeSpinGameConfigReq;
import tests.promotionsservice.response.FreeSpinGameConfigResp;
import tests.promotionsservice.responseobjects.FreeSpinGameConfiguration;

public class FreeSpinGameConfigTests extends BaseClassSetup {
	
	@Test(description = "Make a request to freeSpinGameConfig for real promotion id.")
	public void freeSpinGameConfig_Positive_Scenario() {
		
		String id = UUID.randomUUID().toString();

		FreeSpinGameConfigReq requestBody = new FreeSpinGameConfigReq
				.Builder()
				.defaults()
				.id(id)
				.promotionId(28618)
				.build();
				
		FreeSpinGameConfigResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.freeSpinGameConfigSuccess);
				
		FreeSpinGameConfiguration expConfiguration1 = new FreeSpinGameConfiguration.Builder()
				.defaults()
				.regulatedGameId(6403)
				.gbpBetPerLine("0.1")
				.numberOfLines(10)
				.build();
		
		FreeSpinGameConfiguration expConfiguration2 = new FreeSpinGameConfiguration.Builder()
				.defaults()
				.regulatedGameId(71112)
				.gbpBetPerLine("0.01")
				.numberOfLines(12)
				.build();
		
		FreeSpinGameConfigResp expectedResponse =  new FreeSpinGameConfigResp
				.Builder()
				.defaults()
				.id(id)
				.addGameConfiguration(expConfiguration1)
				.addGameConfiguration(expConfiguration2)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to freeSpinGameConfig with invalid promotion id.")
	public void freeSpinGameConfig_Invalid_Promotion_Id() {
		
		String id = UUID.randomUUID().toString();
		
		FreeSpinGameConfigReq requestBody = new FreeSpinGameConfigReq
				.Builder()
				.defaults()
				.id(id)
				.promotionId(985181111)
				.build();
		
		FreeSpinGameConfigResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.freeSpinGameConfigSuccess);
		FreeSpinGameConfigResp expectedResponse =  new FreeSpinGameConfigResp
				.Builder()
				.defaults()
				.id(id)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to freeSpinGameConfig with invalid method.")
	public void freeSpinGameConfig_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		FreeSpinGameConfigReq requestBody = new FreeSpinGameConfigReq
				.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.freeSpinGameConfigError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to freeSpinGameConfig with missing parameter promotion id.")
	public void freeSpinGameConfig_Missing_Promotion_Id() {
		
		String id = UUID.randomUUID().toString();

		FreeSpinGameConfigReq requestBody = new FreeSpinGameConfigReq.Builder()
				.defaults()
				.promotionId(null)
				.id(id)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.freeSpinGameConfigError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: promotion_id")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}