package tests.promotionsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.promotionsservice.request.AdjustGoldenChipsReq;
import tests.promotionsservice.response.AdjustGoldenChipsResp;
import tests.promotionsservice.responseobjects.GoldenChip;

public class AdjustGoldenChipsTests extends BaseClassSetup {
	
	@Test(description = "Make a request to adjustGoldenChips with source_bet365_games_transaction_id.")
	public void adjustGoldenChips_With_Source_Bet365_Games_Transaction_Id() {
		
		String id = UUID.randomUUID().toString();

		AdjustGoldenChipsReq requestBody = new AdjustGoldenChipsReq
				.Builder()
				.defaults()
				.id(id)
				.promotionToken("6e1a73b1-2c99-4d7f-a2c3-057b7776dfe2")
				.sourceBet365GamesTransactionId(new BigInteger("2157394341"))
				.bet365GamesTransactionId(new BigInteger("2157394693"))
				.addGoldenChip(new GoldenChip(1, new BigDecimal("1")))
				.build();
				
		AdjustGoldenChipsResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.adjustGoldenChipsSuccess);
				
		AdjustGoldenChipsResp expectedResponse =  new AdjustGoldenChipsResp
				.Builder()
				.defaults()
				.id(id)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to adjustGoldenChips without source_bet365_games_transaction_id.")
	public void adjustGoldenChips_Without_Source_Bet365_Games_Transaction_Id() {
		
		String id = UUID.randomUUID().toString();

		AdjustGoldenChipsReq requestBody = new AdjustGoldenChipsReq
				.Builder()
				.defaults()
				.id(id)
				.promotionToken("ad79608c-bf92-41ba-922e-ce643b507401")
				.bet365GamesTransactionId(new BigInteger("1"))
				.addGoldenChip(new GoldenChip(1, new BigDecimal("1")))
				.build();
				
		AdjustGoldenChipsResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.adjustGoldenChipsSuccess);
				
		AdjustGoldenChipsResp expectedResponse =  new AdjustGoldenChipsResp
				.Builder()
				.defaults()
				.id(id)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to adjustGoldenChips with not existing golden chip in the promotion.")
	public void adjustGoldenChips_Wih_Not_Existing_Golden_Chip() {
		
		String id = UUID.randomUUID().toString();

		AdjustGoldenChipsReq requestBody = new AdjustGoldenChipsReq
				.Builder()
				.defaults()
				.id(id)
				.promotionToken("ad79608c-bf92-41ba-922e-ce643b507401")
				.bet365GamesTransactionId(new BigInteger("12"))
				.addGoldenChip(new GoldenChip(1, new BigDecimal("0.5")))
				.build();
				
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.adjustGoldenChipsError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(1003)
												.message("Insufficient GoldenChips")
												.id(id)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to adjustGoldenChips. Retun on unstaked golden chip")
	public void adjustGoldenChips_Return_On_Unstaked_Golden_Chip() {
		
		String id = UUID.randomUUID().toString();

		AdjustGoldenChipsReq requestBody = new AdjustGoldenChipsReq
				.Builder()
				.defaults()
				.id(id)
				.promotionToken("ad79608c-bf92-41ba-922e-ce643b507401")
				.sourceBet365GamesTransactionId(new BigInteger("17"))
				.bet365GamesTransactionId(new BigInteger("18"))
				.addGoldenChip(new GoldenChip(1, new BigDecimal("1")))
				.build();
				
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.adjustGoldenChipsError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(1007)
												.message("Return on unstaked GoldenChip(s)")
												.id(id)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to adjustGoldenChips with invalid method.")
	public void adjustGoldenChips_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		AdjustGoldenChipsReq requestBody = new AdjustGoldenChipsReq
				.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.adjustGoldenChipsError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to adjustGoldenChips with missing parameter bet365_games_transaction_id.")
	public void adjustGoldenChips_Missing_Bet365_Games_Transaction_Id() {
		
		String id = UUID.randomUUID().toString();

		AdjustGoldenChipsReq requestBody = new AdjustGoldenChipsReq.Builder()
				.defaults()
				.sourceBet365GamesTransactionId(new BigInteger("17"))
				.bet365GamesTransactionId(null)
				.id(id)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.adjustGoldenChipsError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing required parameter: bet365_games_transaction_id")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to adjustGoldenChips with missing parameter goldenchips.")
	public void adjustGoldenChips_Missing_Goldenchips() {
		
		String id = UUID.randomUUID().toString();

		AdjustGoldenChipsReq requestBody = new AdjustGoldenChipsReq.Builder()
				.defaults()
				.sourceBet365GamesTransactionId(new BigInteger("17"))
				.bet365GamesTransactionId(new BigInteger("18"))
				.id(id)
				.goldenchips(null)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.adjustGoldenChipsError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing required parameter: goldenchips")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}