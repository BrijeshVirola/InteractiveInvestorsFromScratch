package tests.jackpotdetailsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.math.BigDecimal;
import java.util.UUID;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.ServiceErrors;
import domain.BaseRequest;
import domain.ErrorResponse;
import io.restassured.response.Response;
import tests.jackpotdetailsservice.request.RecordJackpotDetailsReq;
import tests.jackpotdetailsservice.requestobjects.RecordJackpotDetailsParams;
import tests.jackpotdetailsservice.requestobjects.RecordJackpotDetailsParamsJackpot;
import tests.jackpotdetailsservice.response.RecordjackpotdetailsResp;

public class RecordJackpotDetailsTests extends BaseClassSetup {
	
	@Test(description = "Make a request to recordjackpotdetails. Positive scenario.")
	public void recordjackpotdetails_Positive_Scenario() {
		
		String id = UUID.randomUUID().toString();
		
		RecordJackpotDetailsParamsJackpot jackpot1 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("2.55"))
				.win(new BigDecimal("0.78"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();
		
		RecordJackpotDetailsParamsJackpot jackpot2 = new RecordJackpotDetailsParamsJackpot
				.Builder()
				.defaults()
				.contribution(new BigDecimal("0.07"))
				.win(new BigDecimal("0"))
				.code("MegaPot")
				.networkId("TheJackpotNetwork")
				.build();
		
		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.addJackpot(jackpot1)
				.addJackpot(jackpot2)
				.build();
		
		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();
				
		RecordjackpotdetailsResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.recordJackpotDetailsSuccess);
				
		RecordjackpotdetailsResp expectedResponse =  new RecordjackpotdetailsResp(id, true);
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to recordjackpotdetails. Invalid method name.")
	public void recordjackpotdetails_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();
				
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.recordJackpotDetailsError);
				
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to recordjackpotdetails. Missing transaction_id.")
	public void recordjackpotdetails_Missing_Parameter() {
		
		String id = UUID.randomUUID().toString();
		
		RecordJackpotDetailsParams params = new RecordJackpotDetailsParams
				.Builder()
				.defaults()
				.transactionId(null)
				.build();
		
		RecordJackpotDetailsReq requestBody = new RecordJackpotDetailsReq
				.Builder()
				.defaults()
				.id(id)
				.params(params)
				.build();
				
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.recordJackpotDetailsError);
				
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing required parameter: transaction_id")
				.id(id)
				.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request with GET instead of POST method - Error code 1")
	public void get_Method_Instead_Of_Post() {

		Response response = BaseRequest.callEmptyBodyRequest(baseUriJackpotDetailsService, "recordjackpotdetails",
				true, true, false);
		
		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.NOT_HTTP_POST);

		assertReflectionEquals(expError, actError);
	}
	
	@Test(description = "Make a request with no content type header - Error code 2")
	public void header_Content_Type_Not_Set() {

		Response response = BaseRequest.callEmptyBodyRequest(baseUriJackpotDetailsService, "recordjackpotdetails",
				true, false, true);
		
		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.THE_CONTENT_TYPE_HEADER_WAS_MISSING_OR_INVALID);

		assertReflectionEquals(expError, actError);
	}
	
	@Test(description = "Make a request wihtout Accept Header - Error code 3")
	public void header_Accept_Not_Set() {

		Response response = BaseRequest.callEmptyBodyRequest(baseUriJackpotDetailsService, "recordjackpotdetails",
				false, true, true);
		
		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.THE_ACCEPT_HEADER_WAS_MISSING_OR_INVALID);

		assertReflectionEquals(expError, actError);
	}
	
	@Test(description = "Make a request with no json in the body - Error code 4")
	public void no_Json() {

		Response response = BaseRequest.callNoJsonRequest(baseUriJackpotDetailsService, "recordjackpotdetails",
				true, true, true);
		
		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.NO_JSON_REQUEST);

		assertReflectionEquals(expError, actError);
	}
	
	@Test(description = "Make a request with empty json in the body - Error code 5")
	public void json_Body_Empty() {

		Response response = BaseRequest.callEmptyBodyRequest(baseUriJackpotDetailsService, "recordjackpotdetails",
				true, true, true);
		
		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.EMPTY_JSON_BODY_REQUEST);

		assertReflectionEquals(expError, actError);
	}
}
