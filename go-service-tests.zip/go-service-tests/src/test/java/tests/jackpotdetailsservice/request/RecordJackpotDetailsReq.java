package tests.jackpotdetailsservice.request;

import tests.jackpotdetailsservice.requestobjects.RecordJackpotDetailsParams;
import tests.jackpotdetailsservice.requestobjects.RecordJackpotDetailsParamsJackpot;

public class RecordJackpotDetailsReq {
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private RecordJackpotDetailsParams Params;
	
	private RecordJackpotDetailsReq(Builder builder) {
		this.Method = builder.method;
		this.ID = builder.id;
		this.Params = builder.params;
	}

	public static class Builder {
		private String method;
		private String id;
		private RecordJackpotDetailsParams params;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder params(RecordJackpotDetailsParams params) {
			this.params = params;
			return this;
		}
		
		public Builder defaults() {
			this.method = "recordjackpotdetails";
			this.id = "test_id";
			this.params = new RecordJackpotDetailsParams
					.Builder()
					.defaults()
					.addJackpot(new RecordJackpotDetailsParamsJackpot
							.Builder().defaults().build())
					.build();
			return this;
		}
		
		public RecordJackpotDetailsReq build() {
			return new RecordJackpotDetailsReq(this);
		}
	}
}
