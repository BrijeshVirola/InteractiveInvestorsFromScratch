package tests.jackpotdetailsservice.requestobjects;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class RecordJackpotDetailsParams {

	@SuppressWarnings("unused")
	private BigInteger transaction_id;
	@SuppressWarnings("unused")
	private List<RecordJackpotDetailsParamsJackpot> jackpots;

	private RecordJackpotDetailsParams(Builder builder) {
		this.transaction_id = builder.transaction_id;
		this.jackpots = builder.jackpots;
	}

	public static class Builder {
		
		private BigInteger transaction_id;
		private List<RecordJackpotDetailsParamsJackpot> jackpots = new ArrayList<>();

		public Builder transactionId(BigInteger transactionId) {
			this.transaction_id = transactionId;
			return this;
		}

		public Builder addJackpot(RecordJackpotDetailsParamsJackpot jackpot) {
			jackpots.add(jackpot);
			return this;
		}
		
		public Builder defaults() {
			transaction_id = new BigInteger("2150039052");
			jackpots = new ArrayList<>();
			return this;
		}

		public RecordJackpotDetailsParams build() {
			return new RecordJackpotDetailsParams(this);
		}
	}
}
