package tests.netpositionservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.time.Duration;
import java.time.Instant;
import java.util.UUID;
import org.testng.Assert;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.netpositionservice.request.GetNetPositionReq;
import tests.netpositionservice.request.HandleTransactionsReq;
import tests.netpositionservice.request.StartSessionReq;
import tests.netpositionservice.request.Transaction;
import tests.netpositionservice.response.GetNetPositionResp;
public class HandleTransactionsTests extends BaseClassSetup{
	
	@Test(description = "Make a request to HandleTransactions. Positive scenario.")
	public void handleTransactions_Positive_Scenario() throws InterruptedException {
		
		Integer testUserId = 1462;
		
		Instant sessionCreationTime = Instant.now();
		String sessionId = UUID.randomUUID().toString();
		StartSessionReq sessionRequest = new StartSessionReq.Builder()
										.defaults()
										.userId(testUserId)
										.id(sessionId)
										.build();
		
		ResultOKResp actualSessionResponse =  BaseRequest.getResponse(sessionRequest, ResponseEndpoints.startSessionSuccess);

		ResultOKResp expectedSessionResponse = new ResultOKResp.Builder()
															.defaults()
															.id(sessionId)
															.build();
		
		assertReflectionEquals(expectedSessionResponse, actualSessionResponse);	
		
		String transactionId = UUID.randomUUID().toString();
		
		Transaction transaction1 = new Transaction.Builder()
										.generateTransactionId()
										.bonusAmount(1)
										.realAmount(2)
										.ringFencedAmount(3)
										.totalAmount(6)
										.userId(testUserId)
										.build();
		
		Transaction transaction2 = new Transaction.Builder()
													.generateTransactionId()
													.bonusAmount(1)
													.realAmount(2)
													.ringFencedAmount(3)
													.totalAmount(6)
													.userId(testUserId)
													.build();
		
		Transaction transaction3 = new Transaction.Builder()
													.generateTransactionId()
													.bonusAmount(1)
													.realAmount(2)
													.ringFencedAmount(3)
													.totalAmount(6)
													.userId(testUserId)
													.build();
									
		HandleTransactionsReq request = new HandleTransactionsReq.Builder()
										.defaults()
										.addTransaction(transaction1)
										.addTransaction(transaction2)
										.addTransaction(transaction3)
										.id(transactionId)
										.build();
		
		ResultOKResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.handleTransactionsSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
															.defaults()
															.id(transactionId)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
		
		String netPositionId = UUID.randomUUID().toString();
		GetNetPositionReq netPositionRequest = new GetNetPositionReq.Builder()
				.defaults()
				.userId(testUserId)
				.id(netPositionId)
				.build();

		GetNetPositionResp actualNetPositionResponse =  BaseRequest.getResponse(netPositionRequest, ResponseEndpoints.getNetPositionSuccess);
		
		Instant actionsCompleteTime = Instant.now();
		long timeSinceSessionCreated = Duration.between(sessionCreationTime, actionsCompleteTime).toMillis();
		
		Integer durationInMilliseconds = actualNetPositionResponse.getDurationInMilliseconds(); 
	
		Assert.assertTrue(durationInMilliseconds >= 0, "duration_in_milliseconds was less than zero");
		Assert.assertTrue(durationInMilliseconds <= timeSinceSessionCreated, "duration_in_milliseconds exceeded time since session was created");
		Assert.assertEquals(actualNetPositionResponse.getNetPositionAmount(),"18");
		Assert.assertEquals(actualNetPositionResponse.getRegulatedGameId(), 97998);
	
	}
	
	@Test(description = "Make a request to handleTransactions. Wrong method.")
	public void handleTransactions_Wrong_Method() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		HandleTransactionsReq request = new HandleTransactionsReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.method("INVALID_METHOD_NAME")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.handleTransactionsError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
