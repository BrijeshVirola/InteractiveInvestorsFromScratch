package tests.netpositionservice.response;

public class GetNetPositionResp {

	@SuppressWarnings("unused")
	private String id;

	Result result;

	private GetNetPositionResp(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}
	
	public int getDurationInMilliseconds() {
		return result.duration_in_milliseconds;
	}
	
	public String getNetPositionAmount() {
		return result.net_position_amount;
	}
	
	public int getRegulatedGameId() {
		return result.regulated_game_id;
	}
	
	public static class Builder {
		private String id;
		String net_position_amount;
		private int duration_in_milliseconds, regulated_game_id;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder netPositionAmount(String net_position_amount) {
			this.net_position_amount = net_position_amount;
			return this;
		}

		public Builder durationInMilliseconds(int duration_in_milliseconds) {
			this.duration_in_milliseconds = duration_in_milliseconds;
			return this;
		}

		public Builder regulatedGameId(int regulated_game_id) {
			this.regulated_game_id = regulated_game_id;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			this.net_position_amount = "0";
			this.duration_in_milliseconds = 1;
			this.regulated_game_id = 97998;
			return this;
		}

		public GetNetPositionResp build() {
			return new GetNetPositionResp(this);
		}
	}
	
	private class Result {

		String net_position_amount;
		int duration_in_milliseconds;
		int regulated_game_id;

		public Result(Builder builder) {
			
			this.net_position_amount = builder.net_position_amount;
			this.duration_in_milliseconds = builder.duration_in_milliseconds;
			this.regulated_game_id = builder.regulated_game_id;
		}
	}
}

