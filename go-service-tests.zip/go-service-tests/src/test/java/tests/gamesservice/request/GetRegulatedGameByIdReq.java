package tests.gamesservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetRegulatedGameByIdReq {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String method;
	private Map<String, Object> params = new HashMap<>();
	
	private GetRegulatedGameByIdReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("regulated_game_id", builder.regulated_game_id);
	}
	
	public static class Builder {
		private String id;
		private String method;
		private Integer regulated_game_id;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder regulatedGameId(Integer regulated_game_id) {
			this.regulated_game_id = regulated_game_id;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.method = "getregulatedgamebyid";
			this.regulated_game_id = 95678;
			return this;
		}
		
		public GetRegulatedGameByIdReq build() {
			return new GetRegulatedGameByIdReq(this);
		}
	}
}
