package tests.gamesservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetCurrencyCodeExcludedRegulatedGameIdsReq {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String method;

	private Map<String, Object> params = new HashMap<>();

	private GetCurrencyCodeExcludedRegulatedGameIdsReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("currency_code", builder.currency_code);
		this.params.put("product_id", builder.product_id);
		this.params.put("regulated_zone_id", builder.regulated_zone_id);
	}

	public static class Builder {
		private String id;
		private String method;
		private String currency_code;
		private Integer product_id;
		private Integer regulated_zone_id;

		public Builder currencyCode(String currency_code) {
			this.currency_code = currency_code;
			return this;
		}

		public Builder productId(Integer product_id) {
			this.product_id = product_id;
			return this;
		}

		public Builder regulatedZoneId(Integer regulated_zone_id) {
			this.regulated_zone_id = regulated_zone_id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder defaults() {
			this.method = "getcurrencycodeexcludedregulatedgameids";
			this.regulated_zone_id = 4;
			this.currency_code = "CAD";
			this.product_id = 20;
			return this;
		}

		public GetCurrencyCodeExcludedRegulatedGameIdsReq build() {
			return new GetCurrencyCodeExcludedRegulatedGameIdsReq(this);
		}
	}
}