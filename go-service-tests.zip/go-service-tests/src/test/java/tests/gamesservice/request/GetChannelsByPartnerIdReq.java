package tests.gamesservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetChannelsByPartnerIdReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Integer partner_id;
	
	private Map<String, Object> params = new HashMap<>();
	
	private GetChannelsByPartnerIdReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("partner_id", builder.partner_id);
	}

	public static class Builder {
		private String method;
		private String id;
		private Integer partner_id;
		
		public Builder partnerId(Integer partner_id) {
			this.partner_id = partner_id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder defaults() {
			this.method  = "getchannelsbypartnerid";
			this.id = "1";
			this.partner_id = 1;
			return this;
		}
		
		public GetChannelsByPartnerIdReq build() {
			return new GetChannelsByPartnerIdReq(this);
		}
	}
}

