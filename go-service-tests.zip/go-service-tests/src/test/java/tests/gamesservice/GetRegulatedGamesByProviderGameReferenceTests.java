package tests.gamesservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.gamesservice.request.GetRegulatedGamesByProviderGameReferenceReq;
import tests.gamesservice.response.ListOfRegulatedGamesResp;
import tests.gamesservice.responseobjects.RegulatedGame;

public class GetRegulatedGamesByProviderGameReferenceTests extends BaseClassSetup {

	@Test(description = "Make a valid request to get GetRegulatedGamesByProviderGameReference with known provider details")
	public void GivenValidRequestForKnownProviderDetails_WhenGetRegulatedGamesByProviderGameReference_ThenASuccessResponseIsReceived() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetRegulatedGamesByProviderGameReferenceReq requestBody = new GetRegulatedGamesByProviderGameReferenceReq.Builder()
																	.defaults()
																	.id(idForRequestToBeEchoedBackInResponseId)
																	.build();
		
		RegulatedGame game1 = new RegulatedGame.Builder().defaults()
				.platformTypeId(3)
				.regulatedGameId(95681)
				.build();
		
		RegulatedGame game2 = new RegulatedGame.Builder().defaults().build();
		
		RegulatedGame game3 = new RegulatedGame.Builder().defaults()
				.platformTypeId(6)
				.regulatedGameId(97998)
				.build();
			
		ListOfRegulatedGamesResp expectedResponse = new ListOfRegulatedGamesResp.Builder()
				.defaults()
				.addGame(game1)
				.addGame(game2)
				.addGame(game3)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
				
		ListOfRegulatedGamesResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getRegulatedGamesByProviderGameReferenceSuccess);
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a valid request to get GetRegulatedGamesByProviderGameReference which has no matching results")
	public void GivenValidRequestWithNoMatchingGames_WhenGetRegulatedGamesByProviderGameReference_ThenAnEmptySuccessResponseIsReceived() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetRegulatedGamesByProviderGameReferenceReq requestBody = new GetRegulatedGamesByProviderGameReferenceReq.Builder()
																	.defaults()
																	.providerGameReference("UNKNOWN")
																	.id(idForRequestToBeEchoedBackInResponseId)
																	.build();
		
		ListOfRegulatedGamesResp expectedResponse = new ListOfRegulatedGamesResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
				
		ListOfRegulatedGamesResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getRegulatedGamesByProviderGameReferenceSuccess);
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@DataProvider(name = "getRegulatedGamesByProviderGameReferenceInvalidFieldLengths")
	private Object[] getRegulatedGamesByProviderGameReferenceInvalidFieldLengths() {
		return new Object[] { "THIS_SENTENCE_IN_TOTAL_IS_ONE_CHARACTER_LONGER_THAN_THE_MAXIMUM_ALLOWABLE_FIELD_LENGTH_OF_ONE_HUNDRED", ""};
	}
	
	@Test(description = "A request with a field too long/short in GetRegulatedGamesByProviderGameReference - Error code 1006", dataProvider = "getRegulatedGamesByProviderGameReferenceInvalidFieldLengths")
	public void GivenRequestWithAProviderGameReferenceOfInvalidLength_WhenGetRegulatedGamesByProviderGameReference_ThenAnErrorResponseIsReceived(String invalidTestData) {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetRegulatedGamesByProviderGameReferenceReq requestBody = new GetRegulatedGamesByProviderGameReferenceReq.Builder()
																	.defaults()
																	.providerGameReference(invalidTestData)
																	.id(idForRequestToBeEchoedBackInResponseId)
																	.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getRegulatedGamesByProviderGameReferenceError);
		
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1009)
				.message("Invalid parameter: provider_game_reference must be between 1 and 100 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
}
