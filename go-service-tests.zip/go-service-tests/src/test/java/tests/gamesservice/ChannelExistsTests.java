package tests.gamesservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.gamesservice.request.ChannelExistsReq;
import tests.gamesservice.response.ChannelExistsResp;

public class ChannelExistsTests extends BaseClassSetup {
	
	@DataProvider(name = "channelExists")
	private Object[][] channelExists() {
		return new Object[][] {{ 10070, true}, {10046, true}, {9998, true}, {9997, false}, {1071, false}};
	}
	
	@Test(description = "Make a request to channel exists. Positive scenario.", dataProvider = "channelExists")
	public void channelExists_Positive_Scenario(int channel, boolean exists) {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		ChannelExistsReq request = new ChannelExistsReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.channelId(channel)
										.build();
		
		ChannelExistsResp actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.channelExistsSuccess);
		ChannelExistsResp expResponse =  new ChannelExistsResp.Builder()
											.id(idForRequestToBeEchoedBackInResponseId)
											.exists(exists)
											.build();
		
		assertReflectionEquals(expResponse, actResponse);
	}
	
	@Test(description = "Make a request to channel exists. Missing parameter.")
	public void channelExists_Missing_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		ChannelExistsReq request = new ChannelExistsReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.channelId(null)
										.build();
										
		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.channelExistsError);
		
		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: channel_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expResponse, actResponse);
	}
	
	@Test(description = "Make a request to channel exists. Wrong method.")
	public void channelExists_Wrong_Method() {

		ChannelExistsReq request = new ChannelExistsReq.Builder()
										.id(null)
										.channelId(9998)
										.method("INVALID_METHOD_NAME")
										.build();
		
		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.channelExistsError);
		
		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expResponse, actResponse);
	}
}
