package tests.gamesservice.response;

import java.util.HashMap;
import java.util.Map;

public class ChannelExistsResp {
	
	@SuppressWarnings("unused")
	private String id = null;
	private Map<String, Object> result = new HashMap<>();
	
	private ChannelExistsResp(Builder builder) {
		this.id = builder.id;
		this.result.put("exists", builder.exists);
	}
	
	public static class Builder {
		private String id;
		private boolean exists;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder exists(boolean exists) {
			this.exists = exists;
			return this;
		}
		
		public Builder defaults() {
			this.id = null;
			this.exists = true;
			return this;
		}
		
		public ChannelExistsResp build() {
			return new ChannelExistsResp(this);
		}	
	}
}
