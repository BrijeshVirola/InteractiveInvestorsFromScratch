package tests.gamesservice.response;

public class GetChannelsByPartnerIdResp {

	@SuppressWarnings("unused")
	private String id = null;
	@SuppressWarnings("unused")
	private Integer[] result;

	private GetChannelsByPartnerIdResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}

	public static class Builder {
		private String id;
		private Integer[] result;

		public Builder result(Integer[] result) {
			this.result = result;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.result = new Integer[] {};
			return this;
		}
	
		public GetChannelsByPartnerIdResp build() {
			return new GetChannelsByPartnerIdResp(this);
		}
	}
}
