package tests.gamesservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.gamesservice.request.GetRegulatedGameIdsByPropertyValueReq;
import tests.gamesservice.response.GetRegulatedGameIdsByPropertyValueResp;

public class GetRegulatedGameIdsByPropertyValueTests extends BaseClassSetup {
	
	String twoThousandAndOneCharacter = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque dapibus metus cursus leo pretium consectetur. Curabitur interdum nec orci quis rhoncus. Proin non rhoncus dui. Vivamus pretium dignissim dignissim. Donec pharetra mauris in turpis sagittis fermentum nec at leo. Curabitur sollicitudin maximus diam. Nunc posuere nisi vitae purus efficitur placerat. Pellentesque vel eros sit amet odio maximus laoreet. Mauris rhoncus, metus varius imperdiet maximus, velit magna tempus ligula, a tristique ipsum enim at mi. Aliquam viverra porta velit non bibendum. Aenean semper elit eleifend, laoreet purus sed, sagittis orci. Donec pretium lorem quis pretium accumsan. Morbi erat odio, semper ut pellentesque in, malesuada ut ipsum. Suspendisse elit orci, cursus in elit eu, dignissim volutpat libero. Nunc condimentum, justo nec placerat mollis, velit sem varius turpis, a convallis sapien mi sit amet lectus. Sed rutrum metus id ligula congue, ac dapibus velit aliquet. Vestibulum pharetra varius enim sed dictum. Cras luctus, purus at porttitor rhoncus, est arcu blandit lorem, eget porttitor purus eros ut leo. Quisque bibendum massa eget purus consequat ultrices. Curabitur ipsum sapien, euismod egestas commodo sed, tincidunt a enim. Curabitur porta felis libero, quis tincidunt justo tempor in. Cras commodo velit non rutrum tempor. In efficitur vel sapien nec mollis. Sed purus dolor, pellentesque id lorem eget, porttitor semper neque. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Phasellus vitae tempor eros. Nulla mi nulla, aliquam in egestas quis, lobortis a mauris. Maecenas scelerisque erat vel neque tincidunt, vel porttitor turpis maximus. Quisque nec varius enim, vitae iaculis massa. Maecenas nec nisl vitae felis pharetra lacinia. Sed in tincidunt sem. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Praesent vitae orci sapien. Morbi mi dolor, fermentum vitae luctus at, ultricie. L1";
	
	@DataProvider(name = "getRegulatedGameIdsByPropertyValue")
	//productId, languageId, propertyId, propertyValue, expRegulatedGameIds
	private Object[][] getRegulatedGameIdsByPropertyValue() {
		return new Object[][] {
			{3, 1, 2, "Test", new Integer[] {}},
			{4, 1, 2, "Solar Flash", new Integer[] {20991,20992,20993,20994,27424,27425,36282,36283,42149,42150,42151,42152,45838,45839,82584,82585,85339,85340,109982,109983, 115433, 115434, 115435, 115436, 115602, 115603}},
			{2, 1, 2, "Solar Flash", new Integer[] {108844,108845,108846,108847}},
			{3, 1, 2, "A Night Out", new Integer[] {8309,8310,8313,57743,59776,59777,59778,59779,60424,60425,60426,60427,60428,64046,64105}}
			};
	}
	
	@DataProvider(name = "getRegulatedGameIdsByPropertyValueErrors")
	//propertyValue, error
	private Object[][] getRegulatedGameIdsByPropertyValueErrors() {
		return new Object[][] {
			{""},
			{twoThousandAndOneCharacter}
			};
	}
	
	@Test(description = "Make a request to GetRegulatedGameIdsByPropertyValue. Positive scenario.", 
			dataProvider = "getRegulatedGameIdsByPropertyValue")
	public void getRegulatedGameIdsByPropertyValue_Positive_Scenario(int productId, int languageId,
			int propertyId, String propertyValue, Integer[] expRegulatedGameIds) {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGameIdsByPropertyValueReq request = new GetRegulatedGameIdsByPropertyValueReq.Builder()
															.defaults()
															.productId(productId)
															.languageId(languageId)
															.propertyId(propertyId)
															.propertyValue(propertyValue)
															.languageId(languageId)
															.id(idForRequestToBeEchoedBackInResponseId)
															.build();
		
		GetRegulatedGameIdsByPropertyValueResp actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getRegulatedGameIdsByPropertyValueSuccess);
		GetRegulatedGameIdsByPropertyValueResp expResponse =  new GetRegulatedGameIdsByPropertyValueResp.Builder()
																.defaults()
																.regulatedGameIds(expRegulatedGameIds)
																.id(idForRequestToBeEchoedBackInResponseId)
																.build();
		
		assertReflectionEquals(expResponse, actResponse);
	}
	
	@Test(description = "Make a request with invalid property value parameter from params object for GetRegulatedGameIdsByPropertyValue", 
			dataProvider = "getRegulatedGameIdsByPropertyValueErrors")
	public void getRegulatedGameIdsByPropertyValue_Invalid_Property_Value(String propertyValue) {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGameIdsByPropertyValueReq request = new GetRegulatedGameIdsByPropertyValueReq.Builder()
															.defaults()
															.propertyValue(propertyValue)
															.id(idForRequestToBeEchoedBackInResponseId)
															.build();
		
		CustomErrorResponse actError =  BaseRequest.getResponse(request, ResponseEndpoints.getRegulatedGameIdsByPropertyValueError);
		
		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.code(1009)
				.message("Invalid parameter: property_value must be between 1 and 2000 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expError, actError);
	}
	
	@Test(description = "Make a request with missing parameter product_id from GetRegulatedGameIdsByPropertyValue")
	public void getRegulatedGameIdsByPropertyValue_Missing_Product_Id() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGameIdsByPropertyValueReq request = new GetRegulatedGameIdsByPropertyValueReq.Builder()
															.defaults()
															.propertyId(null)
															.id(idForRequestToBeEchoedBackInResponseId)
															.build();
		
		CustomErrorResponse actError =  BaseRequest.getResponse(request, ResponseEndpoints.getRegulatedGameIdsByPropertyValueError);
		
		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: property_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expError, actError);
	}
	
	@Test(description = "Make a request with missing parameter language_id from GetRegulatedGameIdsByPropertyValue")
	public void getRegulatedGameIdsByPropertyValue_Missing_Language_Id() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGameIdsByPropertyValueReq request = new GetRegulatedGameIdsByPropertyValueReq.Builder()
															.defaults()
															.languageId(null)
															.id(idForRequestToBeEchoedBackInResponseId)
															.build();
		
		CustomErrorResponse actError =  BaseRequest.getResponse(request, ResponseEndpoints.getRegulatedGameIdsByPropertyValueError);
		
		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: language_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expError, actError);
	}
	
	@Test(description = "Make a request with missing parameter property_id from GetRegulatedGameIdsByPropertyValue")
	public void getRegulatedGameIdsByPropertyValue_Missing_Property_Id() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetRegulatedGameIdsByPropertyValueReq request = new GetRegulatedGameIdsByPropertyValueReq.Builder()
															.defaults()
															.propertyId(null)
															.id(idForRequestToBeEchoedBackInResponseId)
															.build();
		
		CustomErrorResponse actError =  BaseRequest.getResponse(request, ResponseEndpoints.getRegulatedGameIdsByPropertyValueError);
		
		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: property_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expError, actError);
	}
	
	@Test(description = "Make a request with wrong method in the body for GetRegulatedGameIdsByPropertyValue")
	public void getRegulatedGameIdsByPropertyValue_Wrong_Method() {

		GetRegulatedGameIdsByPropertyValueReq request = new GetRegulatedGameIdsByPropertyValueReq.Builder()
															.defaults()
															.method("INVALID_METHOD")
															.id(null)
															.build();
		
		CustomErrorResponse actError =  BaseRequest.getResponse(request, ResponseEndpoints.getRegulatedGameIdsByPropertyValueError);
		
		CustomErrorResponse expError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expError, actError);
	}
}
