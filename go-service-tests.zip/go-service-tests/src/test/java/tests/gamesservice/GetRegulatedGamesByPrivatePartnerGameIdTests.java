package tests.gamesservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.gamesservice.request.GetRegulatedGamesByPrivatePartnerGameIdReq;
import tests.gamesservice.response.ListOfRegulatedGamesResp;
import tests.gamesservice.responseobjects.RegulatedGame;

public class GetRegulatedGamesByPrivatePartnerGameIdTests extends BaseClassSetup {
	@Test(description = "Make a valid request to get GetRegulatedGamesByPrivatePartnerGameId with known private partner game details")
	public void GivenValidRequestForKnownDetails_WhenGetRegulatedGamesByPrivatePartnerGameId_ThenASuccessResponseIsReceived() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetRegulatedGamesByPrivatePartnerGameIdReq requestBody = new GetRegulatedGamesByPrivatePartnerGameIdReq.Builder()
																	.defaults()
																	.id(idForRequestToBeEchoedBackInResponseId)
																	.build();
		
		RegulatedGame game1 = new RegulatedGame.Builder().defaults()
				.platformTypeId(3)
				.regulatedGameId(95681)
				.build();
		
		RegulatedGame game2 = new RegulatedGame.Builder().defaults().build();
		
		RegulatedGame game3 = new RegulatedGame.Builder().defaults()
				.platformTypeId(6)
				.regulatedGameId(97998)
				.build();
			
		ListOfRegulatedGamesResp expectedResponse = new ListOfRegulatedGamesResp.Builder()
														.defaults()
														.addGame(game1)
														.addGame(game2)
														.addGame(game3)
														.id(idForRequestToBeEchoedBackInResponseId)
														.build();
				
		ListOfRegulatedGamesResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getRegulatedGamesByPrivatePartnerGameIdSuccess);
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a valid request to get GetRegulatedGamesByPrivatePartnerGameId with unknown private partner game details")
	public void GivenValidRequestForUnknownDetails_WhenGetRegulatedGamesByPrivatePartnerGameId_ThenAnEmptySucessfulResponseIsReceived() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetRegulatedGamesByPrivatePartnerGameIdReq requestBody = new GetRegulatedGamesByPrivatePartnerGameIdReq.Builder()
																	.defaults()
																	.privatePartnerGameId("UNKNOWN")
																	.id(idForRequestToBeEchoedBackInResponseId)
																	.build();
			
		ListOfRegulatedGamesResp expectedResponse = new ListOfRegulatedGamesResp.Builder()
														.defaults()
														.id(idForRequestToBeEchoedBackInResponseId)
														.build();
				
		ListOfRegulatedGamesResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getRegulatedGamesByPrivatePartnerGameIdSuccess);
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@DataProvider(name = "getRegulatedGamesByPrivatePartnerGameIdInvalidFieldLengths")
	private Object[] getRegulatedGamesByPrivatePartnerGameIdInvalidFieldLengths() {
		return new Object[] { "THIS_SENTENCE_IN_TOTAL_IS_ONE_CHARACTER_LONGER_THAN_THE_MAXIMUM_ALLOWABLE_FIELD_LENGTH_OF_ONE_HUNDRED", ""};
	}
	
	@Test(description = "A request with a field too long/short in GetRegulatedGamesByPrivatePartnerGameId - Error code 1009", dataProvider = "getRegulatedGamesByPrivatePartnerGameIdInvalidFieldLengths")
	public void GivenRequestWithAProviderGameReferenceOfInvalidLength_WhenGetRegulatedGamesByPrivatePartnerGameId_ThenAnErrorResponseIsReceived(String invalidTestData) {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetRegulatedGamesByPrivatePartnerGameIdReq requestBody = new GetRegulatedGamesByPrivatePartnerGameIdReq.Builder()
																	.defaults()
																	.privatePartnerGameId(invalidTestData)
																	.id(idForRequestToBeEchoedBackInResponseId)
																	.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getRegulatedGamesByPrivatePartnerGameIdError);

		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
		.code(1009)
		.message("Invalid parameter: private_partner_game_id must be between 1 and 100 characters")
		.id(idForRequestToBeEchoedBackInResponseId)
		.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
}
