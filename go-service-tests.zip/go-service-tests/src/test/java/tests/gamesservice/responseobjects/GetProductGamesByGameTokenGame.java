package tests.gamesservice.responseobjects;

public class GetProductGamesByGameTokenGame {
	@SuppressWarnings("unused")
	private String name;
	@SuppressWarnings("unused")
	private Integer game_id;
	@SuppressWarnings("unused")
	private Integer product_game_id;
	@SuppressWarnings("unused")
	private Integer provider_id;
	@SuppressWarnings("unused")
	private Integer game_type_id;
	@SuppressWarnings("unused")
	private Integer technology_id;
	@SuppressWarnings("unused")
	private Boolean is_visible;
	
	private GetProductGamesByGameTokenGame(Builder builder) {
		this.name = builder.name;
		this.game_id = builder.game_id;
		this.product_game_id = builder.product_game_id;
		this.provider_id = builder.provider_id;
		this.game_type_id = builder.game_type_id;
		this.technology_id = builder.technology_id;
		this.is_visible = builder.is_visible;
	}
	
	public static class Builder {
		private String name;
		private Integer game_id;
		private Integer product_game_id;
		private Integer provider_id;
		private Integer game_type_id;
		private Integer technology_id;
		private Boolean is_visible;
		
		public Builder name(String name) {
			this.name = name;
			return this;
		}

		public Builder gameId(Integer game_id) {
			this.game_id = game_id;
			return this;
		}
		
		public Builder productGameId(Integer product_game_id) {
			this.product_game_id = product_game_id;
			return this;
		}
		
		public Builder providerId(Integer provider_id) {
			this.provider_id = provider_id;
			return this;
		}
		
		public Builder gameTypeId(Integer game_type_id) {
			this.game_type_id = game_type_id;
			return this;
		}
		
		public Builder technologyId(Integer technology_id) {
			this.technology_id = technology_id;
			return this;
		}
		
		public Builder isVisible(Boolean is_visible) {
			this.is_visible = is_visible;
			return this;
		}
		
		public Builder defaults() {
			this.name = "3 Hand Blackjack";
			this.game_id = 207;
			this.product_game_id = 220;
			this.provider_id = 1;
			this.game_type_id = 0;
			this.technology_id = 1;
			this.is_visible = true;		
			return this;
		}

		public GetProductGamesByGameTokenGame build() {
			GetProductGamesByGameTokenGame result = new GetProductGamesByGameTokenGame(this);
			return result;
		}
	}
}