package tests.gamesservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.gamesservice.request.GetCurrencyCodeExcludedRegulatedGameIdsReq;
import tests.gamesservice.response.GetCurrencyCodeExcludedRegulatedGameIdsResp;

public class GetCurrencyCodeExcludedRegulatedGameIdsTests extends BaseClassSetup {
	@Test(description = "Make a valid request to GetCurrencyCodeExcludedRegulatedGameIds with known currency code details")
	public void GivenValidRequestForKnownDetails_WhenGetCurrencyCodeExcludedRegulatedGameIds_ThenASuccessResponseIsReceived() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetCurrencyCodeExcludedRegulatedGameIdsReq requestBody = new GetCurrencyCodeExcludedRegulatedGameIdsReq.Builder()
																	.defaults()
																	.id(idForRequestToBeEchoedBackInResponseId)
																	.build();
		
		GetCurrencyCodeExcludedRegulatedGameIdsResp expectedResponse = new GetCurrencyCodeExcludedRegulatedGameIdsResp.Builder()
																			.defaults()
																			.id(idForRequestToBeEchoedBackInResponseId)
																			.build();
				
		GetCurrencyCodeExcludedRegulatedGameIdsResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getCurrencyCodeExcludedRegulatedGameIdsSuccess);
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a valid request to GetCurrencyCodeExcludedRegulatedGameIds with unknown currency code details")
	public void GivenValidRequestForUnknownDetails_WhenGetCurrencyCodeExcludedRegulatedGameIds_ThenAnEmptySuccessResponseIsReceived() {
		
		String unknownCurrencyCode = "ZZZ";
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetCurrencyCodeExcludedRegulatedGameIdsReq requestBody = new GetCurrencyCodeExcludedRegulatedGameIdsReq.Builder()
																	.defaults()
																	.currencyCode(unknownCurrencyCode)
																	.id(idForRequestToBeEchoedBackInResponseId)
																	.build();
		
		Integer[] emptyList = {};
		GetCurrencyCodeExcludedRegulatedGameIdsResp expectedResponse = new GetCurrencyCodeExcludedRegulatedGameIdsResp.Builder()
																			.regulatedGameIds(emptyList)
																			.id(idForRequestToBeEchoedBackInResponseId)
																			.build();
				
		GetCurrencyCodeExcludedRegulatedGameIdsResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getCurrencyCodeExcludedRegulatedGameIdsSuccess);
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@DataProvider(name = "getCurrencyCodeExcludedRegulatedGameIdsInvalidFieldLengths")
	private Object[] GetCurrencyCodeExcludedRegulatedGameIdsInvalidFieldLengths() {
		return new Object[] { "LONG", ""};
	}
	
	@Test(description = "A request with a field too long/short in GetRegulatedGamesByProviderGameReference - Error code 1009", dataProvider = "getCurrencyCodeExcludedRegulatedGameIdsInvalidFieldLengths")
	public void GetCurrencyCodeExcludedRegulatedGameIdsOfInvalidLength_WhenGetCurrencyCodeExcludedRegulatedGameIds_ThenAnErrorResponseIsReceived(String invalidTestData) {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetCurrencyCodeExcludedRegulatedGameIdsReq requestBody = new GetCurrencyCodeExcludedRegulatedGameIdsReq.Builder()
																	.defaults()
																	.currencyCode(invalidTestData)
																	.id(idForRequestToBeEchoedBackInResponseId)
																	.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getCurrencyCodeExcludedRegulatedGameIdsError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1009)
				.message("Invalid parameter: currency_code must be between 1 and 3 characters")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
}
