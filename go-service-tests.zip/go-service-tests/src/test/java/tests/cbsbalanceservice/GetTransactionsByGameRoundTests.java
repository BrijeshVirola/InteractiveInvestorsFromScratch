package tests.cbsbalanceservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.cbsbalanceservice.request.GetTransactionsByGameRoundReq;
import tests.cbsbalanceservice.response.GetCbsTransactionsResp;
import tests.cbsbalanceservice.response.InsertTransaction;
import tests.common.response.ResultOKResp;

public class GetTransactionsByGameRoundTests extends BaseClassSetup {

	@Test(description = "Make a request to getTransactionsByGameRound. Positive default scenario.")
	public void getTransactionsByGameRound_Positive_Default_Scenario() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetTransactionsByGameRoundReq requestBody = new GetTransactionsByGameRoundReq.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId)
											.build();
		
		InsertTransaction insertTransaction = new InsertTransaction.Builder()
				.defaults()
				.gameRoundId(9712524274560982L)
				.partnerTimestampUtc("2021-11-22T10:47:23.344Z")
				.partnerTransactionId("e6b2bff2-5288-497b-b26e-9484f067687d")
				.bet365TransactionId(9712524274560982L)
				.bet365GamesTransactionId(9712524274560976L)
				.build();
													
		GetCbsTransactionsResp expectedResponse = new GetCbsTransactionsResp.Builder()
				.defaults()
				.addTransaction(insertTransaction)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
	    
		GetCbsTransactionsResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getTransactionsByGameroundSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to getTransactionsByGameRound with invalid method.")
	public void getTransactionsByGameRound_Invalid_Method() {
		
		GetTransactionsByGameRoundReq requestBody = new GetTransactionsByGameRoundReq.Builder()
				.defaults()
				.method("INVALID_METHOD")
				.id(null)
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getCbsTransactionByGameRoundError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getTransactionsByGameRound with missing parameter game_round_id.")
	public void getTransactionsByGameRound_Missing_gameRoundId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetTransactionsByGameRoundReq requestBody = new GetTransactionsByGameRoundReq.Builder()
				.defaults()
				.gameRoundId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getCbsTransactionByGameRoundError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: game_round_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getTransactionsByGameRound unknown game_round_id.")
	public void getTransactionsByGameRound_Unknown_GameRoundId() {
		Long unknownGameId = 281474976710656L;
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetTransactionsByGameRoundReq requestBody = new GetTransactionsByGameRoundReq.Builder()
				.defaults()
				.gameRoundId(unknownGameId)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.result(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		ResultOKResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getTransactionsByGameroundError);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
