package tests.cbsbalanceservice.response;

public class GetCbsTransactionResp {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	public InsertTransaction result;

	private GetCbsTransactionResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.insertTransaction;
	}

	public static class Builder {
		private String id;
		private InsertTransaction insertTransaction;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder addTransaction(InsertTransaction insertTransaction) {
			this.insertTransaction = insertTransaction;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			return this;
		}

		public GetCbsTransactionResp build() {
			GetCbsTransactionResp result = new GetCbsTransactionResp(this);
			return result;
		}
	}
}
