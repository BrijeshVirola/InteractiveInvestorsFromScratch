package tests.cbsbalanceservice.response;

public class InsertTransaction {

	public Long bet365_games_transaction_id;
	public Integer transaction_type_id;
	public String partner_transaction_id;
	public String real_amount;
	public String ringfenced_amount;
	public String bonus_amount;
	public String total_amount;
	public String total_amount_gbp;
	public String currency_code;
	public String partner_timestamp_utc;
	public Long game_round_id;
	public Long bet365_transaction_id;
	public Integer provider_region_id;
	public Integer regulated_game_id;
	public Boolean is_new;

	private InsertTransaction(Builder builder) {
		this.bet365_games_transaction_id = builder.bet365_games_transaction_id;
		this.transaction_type_id = builder.transaction_type_id;
		this.partner_transaction_id = builder.partner_transaction_id;
		this.real_amount = builder.real_amount;
		this.ringfenced_amount = builder.ringfenced_amount;
		this.bonus_amount = builder.bonus_amount;
		this.total_amount = builder.total_amount;
		this.total_amount_gbp = builder.total_amount_gbp;
		this.currency_code = builder.currency_code;
		this.partner_timestamp_utc = builder.partner_timestamp_utc;
		this.game_round_id = builder.game_round_id;
		this.bet365_transaction_id = builder.bet365_transaction_id;
		this.provider_region_id = builder.provider_region_id;
		this.regulated_game_id = builder.regulated_game_id;
		this.is_new = builder.is_new;
	}
	
	public static class Builder {
		Long bet365_games_transaction_id, game_round_id, bet365_transaction_id;
		String partner_transaction_id;
		String real_amount, bonus_amount, total_amount, total_amount_gbp, currency_code, partner_timestamp_utc;
		String ringfenced_amount;
		Integer provider_region_id, transaction_type_id, regulated_game_id;
		Boolean is_new;
		
		public Builder bet365GamesTransactionId(Long bet365_games_transaction_id) {
			this.bet365_games_transaction_id = bet365_games_transaction_id;
			return this;
		}

		public Builder transactionTypeId(Integer transaction_type_id) {
			this.transaction_type_id = transaction_type_id;
			return this;
		}
		
		public Builder partnerTransactionId(String partner_transaction_id) {
			this.partner_transaction_id = partner_transaction_id;
			return this;
		}

		public Builder realAmount(String real_amount) {
			this.real_amount = real_amount;
			return this;
		}
		
		public Builder ringFencedAmount(String ringfenced_amount) {
			this.ringfenced_amount = ringfenced_amount;
			return this;
		}
		
		public Builder bonusAmount(String bonus_amount) {
			this.bonus_amount = bonus_amount;
			return this;
		}
		
		public Builder totalAmount(String total_amount) {
			this.total_amount = total_amount;
			return this;
		}
		
		public Builder totalAmountGbp(String total_amount_gbp) {
			this.total_amount_gbp = total_amount_gbp;
			return this;
		}
		
		public Builder currencyCode(String currency_code) {
			this.currency_code = currency_code;
			return this;
		}

		public Builder partnerTimestampUtc(String partner_timestamp_utc) {
			this.partner_timestamp_utc = partner_timestamp_utc;
			return this;
		}
		
		public Builder gameRoundId(Long game_round_id) {
			this.game_round_id = game_round_id;
			return this;
		}
		
		public Builder bet365TransactionId(Long bet365_transaction_id) {
			this.bet365_transaction_id = bet365_transaction_id;
			return this;
		}
		
		public Builder providerRegionId(Integer provider_region_id) {
			this.provider_region_id = provider_region_id;
			return this;
		}
		
		public Builder regulatedGameId(Integer regulated_game_id) {
			this.regulated_game_id = regulated_game_id;
			return this;
		}
		
		public Builder isNew(Boolean is_new) {
			this.is_new = is_new;
			return this;
		}
		
		public Builder defaults() {
			this.bet365_games_transaction_id = 9712524270655275L;
			this.transaction_type_id = 133;
			this.partner_transaction_id = "141543e0-022c-4d19-93a6-75e1ed9b9fb9";
			this.real_amount = "-0.03";
			this.ringfenced_amount = "0";
			this.bonus_amount = "0";
			this.total_amount = "-0.03";
			this.total_amount_gbp = "-0.03";
			this.currency_code = "GBP";
			this.partner_timestamp_utc = "2021-11-22T09:42:17.643Z";
			this.game_round_id = 383998L;
			this.bet365_transaction_id = 9712524270655281L;
			this.provider_region_id = 20;
			this.regulated_game_id = 6403;
			this.is_new = false;
            return this;
		}

		public InsertTransaction build() {
			return new InsertTransaction(this);
		}
	}

	@SuppressWarnings("unused")
	private class Result {

		private Long bet365_games_transaction_id;
		private Integer transaction_type_id;
		private String partner_transaction_id;
		private String real_amount;
		private String ringfenced_amount;
		private String bonus_amount;
		private String total_amount;
		private Object total_amount_gbp;
		private String currency_code;
		private String partner_timestamp_utc;
		private Long game_round_id;
		private Long bet365_transaction_id;
		private Object provider_region_id;
		private Boolean is_new;

		public Result(Builder builder) {
			this.bet365_games_transaction_id = builder.bet365_games_transaction_id;
			this.transaction_type_id = builder.transaction_type_id;
			this.partner_transaction_id = builder.partner_transaction_id;
			this.real_amount = builder.real_amount;
			this.ringfenced_amount = builder.ringfenced_amount;
			this.bonus_amount = builder.bonus_amount;
			this.total_amount = builder.total_amount;
			this.total_amount_gbp = builder.total_amount_gbp;
			this.currency_code = builder.currency_code;
			this.partner_timestamp_utc = builder.partner_timestamp_utc;
			this.game_round_id = builder.game_round_id;
			this.bet365_transaction_id = builder.bet365_transaction_id;
			this.provider_region_id = builder.provider_region_id;
			this.is_new = builder.is_new;
		}
	}
}