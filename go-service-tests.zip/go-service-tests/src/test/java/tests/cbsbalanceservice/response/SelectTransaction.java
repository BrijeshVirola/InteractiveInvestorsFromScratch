package tests.cbsbalanceservice.response;

public class SelectTransaction {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Result result;

	private SelectTransaction(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}
	
	public static class Builder {
		String id;
		Long bet365_games_transaction_id, game_round_id, bet365_transaction_id, source_transaction_id, flake_id;
		String partner_transaction_id;
		String real_amount, bonus_amount, total_amount, total_amount_gbp, currency_code, partner_timestamp_utc, ring_fenced_amount, user_token;
		Integer provider_region_id, transaction_type_id, regulated_game_id;
		Boolean is_new;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder bet365GamesTransactionId(Long bet365_games_transaction_id) {
			this.bet365_games_transaction_id = bet365_games_transaction_id;
			return this;
		}

		public Builder balance(Integer transaction_type_id) {
			this.transaction_type_id = transaction_type_id;
			return this;
		}

		public Builder partnerTransactionId(String partner_transaction_id) {
			this.partner_transaction_id = partner_transaction_id;
			return this;
		}

		public Builder realAmount(String real_amount) {
			this.real_amount = real_amount;
			return this;
		}
		
		public Builder ringFencedAmount(String ring_fenced_amount) {
			this.ring_fenced_amount = ring_fenced_amount;
			return this;
		}
		
		public Builder bonusAmount(String bonus_amount) {
			this.bonus_amount = bonus_amount;
			return this;
		}
		
		public Builder totalAmount(String total_amount) {
			this.total_amount = total_amount;
			return this;
		}
		
		public Builder totalAmountGbp(String total_amount_gbp) {
			this.total_amount_gbp = total_amount_gbp;
			return this;
		}
		
		public Builder currencyCode(String currency_code) {
			this.currency_code = currency_code;
			return this;
		}

		public Builder partnerTimestampUtc(String partner_timestamp_utc) {
			this.partner_timestamp_utc = partner_timestamp_utc;
			return this;
		}
		
		public Builder gameRoundId(Long game_round_id) {
			this.game_round_id = game_round_id;
			return this;
		}
		
		public Builder bet365TransactionId(Long bet365_transaction_id) {
			this.bet365_transaction_id = bet365_transaction_id;
			return this;
		}
		
		public Builder providerRegionId(Integer provider_region_id) {
			this.provider_region_id = provider_region_id;
			return this;
		}
		
		public Builder regulatedGameId(Integer regulated_game_id) {
			this.regulated_game_id = regulated_game_id;
			return this;
		}

		public Builder sourceTransactionId(Long source_transaction_id) {
			this.source_transaction_id = source_transaction_id;
			return this;
		}

		public Builder userToken(String user_token) {
			this.user_token = user_token;
			return this;
		}
		
		public Builder flakeId(Long flake_id) {
			this.flake_id = flake_id;
			return this;
		}

		public Builder isNew(Boolean is_new) {
			this.is_new = is_new;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.bet365_games_transaction_id = 8584986789678594L;
			this.transaction_type_id = 133;
			this.partner_transaction_id = "1234/531512969";
			this.real_amount = "-1";
			this.ring_fenced_amount = "0";
			this.bonus_amount = "0";
			this.total_amount = "-1";
			this.total_amount_gbp = "-1";
			this.currency_code = "GBP";
			this.partner_timestamp_utc = "2021-09-17T10:19:08.303Z";
			this.game_round_id = 383998L;
			this.bet365_transaction_id = 0L;
			this.provider_region_id = 3;
			this.regulated_game_id = 21546;
			this.source_transaction_id = 0L;
			this.user_token = "ecc724dd-ecc5-43e3-8b62-7ca5cb57a520";
			this.flake_id = 8584986789678594L;
			this.is_new = true;
			return this;
		}

		public SelectTransaction build() {
			return new SelectTransaction(this);
		}
	}

	private class Result {

		@SuppressWarnings("unused")
		private Long bet365_games_transaction_id;
		@SuppressWarnings("unused")
		private Integer transaction_type_id;
		@SuppressWarnings("unused")
		private String partner_transaction_id;
		@SuppressWarnings("unused")
		private String real_amount;
		@SuppressWarnings("unused")
		private String ring_fenced_amount;
		@SuppressWarnings("unused")
		private String bonus_amount;
		@SuppressWarnings("unused")
		private String total_amount;
		@SuppressWarnings("unused")
		private Object total_amount_gbp;
		@SuppressWarnings("unused")
		private String currency_code;
		@SuppressWarnings("unused")
		private String partner_timestamp_utc;
		@SuppressWarnings("unused")
		private Long game_round_id;
		@SuppressWarnings("unused")
		private Long bet365_transaction_id;
		@SuppressWarnings("unused")
		private Object provider_region_id;
		@SuppressWarnings("unused")
		private Boolean is_new;

		public Result(Builder builder) {
			this.bet365_games_transaction_id = builder.bet365_games_transaction_id;
			this.transaction_type_id = builder.transaction_type_id;
			this.partner_transaction_id = builder.partner_transaction_id;
			this.real_amount = builder.real_amount;
			this.ring_fenced_amount =builder.ring_fenced_amount;
			this.bonus_amount = builder.bonus_amount;
			this.total_amount = builder.total_amount;
			this.total_amount_gbp = builder.total_amount_gbp;
			this.currency_code = builder.currency_code;
			this.partner_timestamp_utc = builder.partner_timestamp_utc;
			this.game_round_id = builder.game_round_id;
			this.bet365_transaction_id = builder.bet365_transaction_id;
			this.provider_region_id = builder.provider_region_id;
			this.is_new = builder.is_new;
		}
	}
}