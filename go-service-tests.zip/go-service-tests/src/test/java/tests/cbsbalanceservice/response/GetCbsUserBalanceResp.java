package tests.cbsbalanceservice.response;

public class GetCbsUserBalanceResp {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Result result;

	private GetCbsUserBalanceResp(Builder builder) {
		this.id = builder.id;
		result = new Result(builder);
	}
	
	public static class Builder {
		String id;
		Integer user_id;
		String balance;
		String bonus;
		String ring_fenced;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder balance(String balance) {
			this.balance = balance;
			return this;
		}

		public Builder bonus(String bonus) {
			this.bonus = bonus;
			return this;
		}

		public Builder ringFenced(String ring_fenced) {
			this.ring_fenced = ring_fenced;
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			this.user_id = 2001;
			this.balance = "940.83";
			this.bonus = "0";
			this.ring_fenced = "0";
			return this;
		}

		public GetCbsUserBalanceResp build() {
			return new GetCbsUserBalanceResp(this);
		}
	}

	private class Result {

		@SuppressWarnings("unused")
		Integer user_id;
		@SuppressWarnings("unused")
		String balance;
		@SuppressWarnings("unused")
		String bonus;
		@SuppressWarnings("unused")
		String ring_fenced;

		public Result(Builder builder) {
			this.user_id = builder.user_id;
			this.balance = builder.balance;
			this.bonus = builder.bonus;
			this.ring_fenced = builder.ring_fenced;
		}
	}
}