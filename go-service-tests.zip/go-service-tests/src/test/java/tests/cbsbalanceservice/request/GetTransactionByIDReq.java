package tests.cbsbalanceservice.request;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;  

public class GetTransactionByIDReq {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String method;

	private Map<String, Object> params = new HashMap<>();
	
	private GetTransactionByIDReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("id", builder.id_in_params);
	}
	
	public static class Builder {
		String id, method;
		Long id_in_params;
		
		Random random = new Random();
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder idInParams(Long id_in_params) {
			this.id_in_params = id_in_params;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.method = "GetTransactionById";
			this.id_in_params = 9712524270655275L;
			return this;
		}

		public GetTransactionByIDReq build() {
			return new GetTransactionByIDReq(this);
		}
	}
}
