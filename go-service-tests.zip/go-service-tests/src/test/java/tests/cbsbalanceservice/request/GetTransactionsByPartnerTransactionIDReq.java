package tests.cbsbalanceservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetTransactionsByPartnerTransactionIDReq {
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Integer user_id;
	@SuppressWarnings("unused")
	private Integer product_id;
	private Map<String, Object> params = new HashMap<>();
	
	private GetTransactionsByPartnerTransactionIDReq(Builder builder) {
		this.method = builder.method;
		this.id = builder.id;
		this.params.put("user_id", builder.user_id);
		this.params.put("provider_region_id", builder.provider_region_id);
		this.params.put("partner_transaction_id", builder.partner_transaction_id);
	}

	public static class Builder {
		private String method, id;
		private Integer provider_region_id;
		private Integer user_id;
		private String partner_transaction_id;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder providerRegionId(Integer provider_region_id) {
			this.provider_region_id = provider_region_id;
			return this;
		}
		
		public Builder partnerTransactionId(String partner_transaction_id) {
			this.partner_transaction_id = partner_transaction_id;
			return this;
		}
		
		public Builder defaults() {
			this.method  = "GetTransactionsByPartnerTransactionID";
			this.id = "1";
			this.user_id = 4419877;
			this.provider_region_id = 20;
			this.partner_transaction_id = "e6b2bff2-5288-497b-b26e-9484f067687d";
			return this;
		}
		
		public GetTransactionsByPartnerTransactionIDReq build() {
			return new GetTransactionsByPartnerTransactionIDReq(this);
		}
	}
}
