package tests.cbsbalanceservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetCbsUserBalanceReq {
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Integer user_id;
	@SuppressWarnings("unused")
	private Integer product_id;
	private Map<String, Object> params = new HashMap<>();
	
	private GetCbsUserBalanceReq(Builder builder) {
		this.method = builder.method;
		this.id = builder.id;
		this.params.put("user_id", builder.user_id);
		this.params.put("product_id", builder.product_id);
	}

	public static class Builder {
		private String method;
		private String id;
		private Integer user_id;
		private Integer product_id;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder productId(Integer product_id) {
			this.product_id = product_id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder defaults() {
			this.method  = "getuserbalance";
			this.id = null;
			this.user_id = 2001;
			this.product_id = 4;
			return this;
		}
		
		public GetCbsUserBalanceReq build() {
			return new GetCbsUserBalanceReq(this);
		}
	}
}
