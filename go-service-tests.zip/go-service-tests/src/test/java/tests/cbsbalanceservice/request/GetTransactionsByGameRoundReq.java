package tests.cbsbalanceservice.request;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;  

public class GetTransactionsByGameRoundReq {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String method;

	private Map<String, Object> params = new HashMap<>();
	
	private GetTransactionsByGameRoundReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("game_round_id", builder.game_round_id);
	}
	
	public static class Builder {
		String id, method;
		Long game_round_id;
		
		Random random = new Random();
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder gameRoundId(Long game_round_id) {
			this.game_round_id = game_round_id;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.method = "GetTransactionsByGameround";
			this.game_round_id = 9712524274560982L;
			return this;
		}

		public GetTransactionsByGameRoundReq build() {
			return new GetTransactionsByGameRoundReq(this);
		}
	}
}
