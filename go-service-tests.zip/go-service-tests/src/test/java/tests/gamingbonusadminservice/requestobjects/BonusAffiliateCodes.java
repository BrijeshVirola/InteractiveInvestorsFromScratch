package tests.gamingbonusadminservice.requestobjects;

import java.util.ArrayList;
import java.util.List;

public class BonusAffiliateCodes {
	
	Integer bonusaffiliatecodehistory_id;
	List<String> affiliatecodes;
	String createddate;
	
	private BonusAffiliateCodes(Builder builder) {
		bonusaffiliatecodehistory_id = builder.bonusaffiliatecodehistory_id;
		affiliatecodes = builder.affiliatecodes;
		createddate = builder.createddate;
	}
	
	public static class Builder {
		
		Integer bonusaffiliatecodehistory_id;
		List<String> affiliatecodes;
		String createddate;
		
		public Builder bonusAffiliateCodeHistoryId(Integer bonusAffiliateCodeHistoryId) {
			bonusaffiliatecodehistory_id = bonusAffiliateCodeHistoryId;
			return this;
		}
		
		public Builder addAffiliateCode(String affiliateCode) {
			affiliatecodes.add(affiliateCode);
			return this;
		}
		
		public Builder createdDate(String createdDate) {
			createddate = createdDate;
			return this;
		}
		
		public Builder defaults() {
			bonusaffiliatecodehistory_id = 1;
			affiliatecodes = new ArrayList<>();
			createddate = "2021-12-01T10:50:00.000Z";
			return this;
		}
		
		public BonusAffiliateCodes build() {
			return new BonusAffiliateCodes(this);
		}
	}
}
