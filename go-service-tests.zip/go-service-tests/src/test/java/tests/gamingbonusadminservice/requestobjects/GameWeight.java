package tests.gamingbonusadminservice.requestobjects;

public class GameWeight {
	
	Integer regulatedgame_id;
	Integer weight;
	
	private GameWeight(Builder builder) {
		regulatedgame_id = builder.regulatedgame_id;
		weight = builder.weight;
	}
	
	public static class Builder {
		
		private Integer regulatedgame_id;
		private Integer weight;
		
		public Builder defaults() {
			regulatedgame_id = 123;
			weight = 7;
			return this;
		}
		
		public Builder regulatedgame_id(Integer regulatedgameId) {
			regulatedgame_id = regulatedgameId;
			return this;
		}
		
		public Builder weight(Integer weight) {
			this.weight = weight;
			return this;
		}
		
		public GameWeight build() {
			return new GameWeight(this);
			
		}
	}
}
