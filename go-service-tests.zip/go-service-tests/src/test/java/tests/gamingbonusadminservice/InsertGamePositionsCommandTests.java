package tests.gamingbonusadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.testng.Reporter;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import common.DatabaseQueries;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusadminservice.request.InsertGamePositionsCommandReq;

public class InsertGamePositionsCommandTests extends BaseClassSetup {

	@Test(description = "Make a request to insertgamepositionscommand. Positive Scenario.")
	public void insertGamePositionsCommand_Positive_Scenario() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		int gameTokenId1 = 3268;
		int gameTokenId2 = 17743;
		int bonustemplateId = 515;
		int lastBonusTemplateGamePositionsId = DatabaseQueries.getLastBonusTemplateGamePositionsId();

		Reporter.log("01. Insert two game positions.");
		Map<String, Integer> expGamePosition1 = new HashMap<>();
		expGamePosition1.put("BonusTemplateGamePositionsId", ++lastBonusTemplateGamePositionsId);
		expGamePosition1.put("BonusTemplateId", bonustemplateId);
		expGamePosition1.put("RegulatedZoneId", 1);
		expGamePosition1.put("Position", 1);
		expGamePosition1.put("GameTokenId", gameTokenId1);
		expGamePosition1.put("ProductId", 2);

		Map<String, Integer> expGamePosition2 = new HashMap<>();
		expGamePosition2.put("BonusTemplateGamePositionsId", ++lastBonusTemplateGamePositionsId);
		expGamePosition2.put("BonusTemplateId", bonustemplateId);
		expGamePosition2.put("RegulatedZoneId", 1);
		expGamePosition2.put("Position", 2);
		expGamePosition2.put("GameTokenId", gameTokenId2);
		expGamePosition2.put("ProductId", 2);

		InsertGamePositionsCommandReq request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.addGame(gameTokenId1, 1)
				.addGame(gameTokenId2, 2)
				.bonustemplateId(bonustemplateId)
				.regulatedzoneId(1)
				.productId(2)
				.build();

		ResultOKResp actualResponse = BaseRequest.getResponse(
				request, ResponseEndpoints.insertGamePositionsCommandSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		Reporter.log("02. Check that repsponse is properly returned.");
		assertReflectionEquals(expectedResponse, actualResponse);

		Reporter.log("03. Check that game positions are properly inserted in the database.");
		Map<String, Integer> actGamePosition1 = DatabaseQueries.getBonusTemplateGamePosition(bonustemplateId, gameTokenId1);
		Map<String, Integer> actGamePosition2 = DatabaseQueries.getBonusTemplateGamePosition(bonustemplateId, gameTokenId2);

		assertReflectionEquals(expGamePosition1, actGamePosition1);
		assertReflectionEquals(expGamePosition2, actGamePosition2);
	}
	
	@Test(description = "Make a request to insertgamepositionscommand. Missing/Invalid bonustemplate_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void insertGamePositionsCommand_Missing_Invalid_Bonustemplate_Id(String nullZero) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer bonustemplateId = nullZero.equals("null") ? null : 0;

		InsertGamePositionsCommandReq request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.addGame(3268, 1)
				.bonustemplateId(bonustemplateId)
				.regulatedzoneId(1)
				.productId(2)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.getResponse(
				request, ResponseEndpoints.insertGamePositionsCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.code(1003)
				.message("Missing/Invalid parameter: bonustemplate_id")
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to insertgamepositionscommand. Missing/Invalid product_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void insertGamePositionsCommand_Missing_Invalid_Product_Id(String nullZero) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer productId = nullZero.equals("null") ? null : 0;

		InsertGamePositionsCommandReq request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.addGame(3268, 1)
				.bonustemplateId(515)
				.regulatedzoneId(1)
				.productId(productId)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.getResponse(
				request, ResponseEndpoints.insertGamePositionsCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.code(1003)
				.message("Missing/Invalid parameter: product_id")
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to insertgamepositionscommand. Missing/Invalid regulatedzone_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void insertGamePositionsCommand_Missing_Invalid_Regulatedzone_Id(String nullZero) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer regulatedzoneId = nullZero.equals("null") ? null : 0;

		InsertGamePositionsCommandReq request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.addGame(3268, 1)
				.bonustemplateId(515)
				.regulatedzoneId(regulatedzoneId)
				.productId(2)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.getResponse(
				request, ResponseEndpoints.insertGamePositionsCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.code(1003)
				.message("Missing/Invalid parameter: regulatedzone_id")
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to insertgamepositionscommand. Missing/Invalid games.")
	public void insertGamePositionsCommand_Missing_Invalid_Games() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		InsertGamePositionsCommandReq request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(515)
				.regulatedzoneId(1)
				.productId(2)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.getResponse(
				request, ResponseEndpoints.insertGamePositionsCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.code(1003)
				.message("Missing/Invalid parameter: games")
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to insertgamepositionscommand. Missing/Invalid position.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void insertGamePositionsCommand_Missing_Invalid_Position(String nullZero) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer position = nullZero.equals("null") ? null : 0;

		InsertGamePositionsCommandReq request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.addGame(3268, position)
				.bonustemplateId(515)
				.regulatedzoneId(2)
				.productId(2)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.getResponse(
				request, ResponseEndpoints.insertGamePositionsCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.code(1003)
				.message("Missing/Invalid parameter: position")
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to insertgamepositionscommand. Missing/Invalid gametoken_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void insertGamePositionsCommand_Missing_Invalid_Gametoken_id(String nullZero) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		Integer gameTokenId = nullZero.equals("null") ? null : 0;

		InsertGamePositionsCommandReq request = new InsertGamePositionsCommandReq.Builder()
				.defaults()
				.id(id)
				.addGame(gameTokenId, 1)
				.bonustemplateId(515)
				.regulatedzoneId(2)
				.productId(2)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.getResponse(
				request, ResponseEndpoints.insertGamePositionsCommandError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.code(1003)
				.message("Missing/Invalid parameter: gametoken_id")
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
