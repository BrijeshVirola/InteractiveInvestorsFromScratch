package tests.gamingbonusadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import java.util.UUID;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.gamingbonusadminservice.request.GetClaimedAndCompletedBonusCountCommandReq;
import tests.gamingbonusadminservice.response.GetClaimedAndCompletedBonusCountCommandResp;
import tests.gamingbonusadminservice.responseobjects.BonusCountClaimedAndCompletedResult;

public class GetClaimedAndCompletedBonusCountCommandTests extends BaseClassSetup {
	
	@Test(description = "Make a request to getclaimedandcompletedbonuscountcommand. Single bonustemplate_id.")
	public void getClaimedAndCompletedBonusCountCommand_Single_Bonustemplate_Id() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		GetClaimedAndCompletedBonusCountCommandReq request = new GetClaimedAndCompletedBonusCountCommandReq.Builder()
				.defaults()
				.id(id)
				.addBonustemplateId(485)
				.build();

		GetClaimedAndCompletedBonusCountCommandResp actualResponse = BaseRequest.getResponse(
				request, ResponseEndpoints.getClaimedAndCompletedBonusCountCommandSuccess);
		
		BonusCountClaimedAndCompletedResult result = new BonusCountClaimedAndCompletedResult.Builder()
				.defaults()
				.bonustemplateId(485)
				.claimedBonus(2)
				.completedBonus(8)
				.creditedBonus(9)
				.build();
				
		GetClaimedAndCompletedBonusCountCommandResp expectedResponse = new GetClaimedAndCompletedBonusCountCommandResp.Builder()
				.defaults()
				.id(id)
				.addResult(result)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}
	
	@Test(description = "Make a request to getclaimedandcompletedbonuscountcommand. Multi bonustemplate_id.")
	public void getClaimedAndCompletedBonusCountCommand_Multi_Bonustemplate_Id() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		GetClaimedAndCompletedBonusCountCommandReq request = new GetClaimedAndCompletedBonusCountCommandReq.Builder()
				.defaults()
				.id(id)
				.addBonustemplateId(485)
				.addBonustemplateId(452)
				.build();

		GetClaimedAndCompletedBonusCountCommandResp actualResponse = BaseRequest.getResponse(
				request, ResponseEndpoints.getClaimedAndCompletedBonusCountCommandSuccess);
		
		BonusCountClaimedAndCompletedResult result1 = new BonusCountClaimedAndCompletedResult.Builder()
				.defaults()
				.bonustemplateId(485)
				.claimedBonus(2)
				.completedBonus(8)
				.creditedBonus(9)
				.build();
		
		BonusCountClaimedAndCompletedResult result2 = new BonusCountClaimedAndCompletedResult.Builder()
				.defaults()
				.bonustemplateId(452)
				.claimedBonus(0)
				.completedBonus(2)
				.creditedBonus(5)
				.build();
				
		GetClaimedAndCompletedBonusCountCommandResp expectedResponse = new GetClaimedAndCompletedBonusCountCommandResp.Builder()
				.defaults()
				.id(id)
				.addResult(result1)
				.addResult(result2)
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}
	
	@Test(description = "Make a request to getclaimedandcompletedbonuscountcommand. Missing/Invalid bonustemplate_id.")
	public void getClaimedAndCompletedBonusCountCommand_Missing_Invalid_Bonustemplate_Ids() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		GetClaimedAndCompletedBonusCountCommandReq request = new GetClaimedAndCompletedBonusCountCommandReq.Builder()
				.defaults()
				.id(id)
				.build();

		CustomErrorResponse actualResponse = BaseRequest.getResponse(
				request, ResponseEndpoints.getClaimedAndCompletedBonusCountCommandError);
		
				
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.code(1003)
				.message("Missing/Invalid parameter: bonustemplate_ids")
				.build();

		assertReflectionEquals(expectedResponse, actualResponse);	
	}
}
