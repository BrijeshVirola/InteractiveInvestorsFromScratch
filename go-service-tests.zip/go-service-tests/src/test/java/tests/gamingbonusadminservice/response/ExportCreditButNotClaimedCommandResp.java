package tests.gamingbonusadminservice.response;

import java.util.ArrayList;
import java.util.List;

import tests.gamingbonusadminservice.responseobjects.ExportCreditButNotClaimedCommandResult;

public class ExportCreditButNotClaimedCommandResp {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private List<ExportCreditButNotClaimedCommandResult> result;
	
	public ExportCreditButNotClaimedCommandResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public static class Builder {
		
		private String id;
		private List<ExportCreditButNotClaimedCommandResult> result;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder addResult(ExportCreditButNotClaimedCommandResult result) {
			this.result.add(result);
			return this;
		}
		
		public Builder defaults() {
			this.id = "defaultTestId";
			this.result = new ArrayList<>();
			
			return this;
		}
		
		public ExportCreditButNotClaimedCommandResp build() {
			return new ExportCreditButNotClaimedCommandResp(this);
		}
	}
}
