package tests.gamingbonusadminservice.response;

public class ActiveDepositBonusQueryCommandResp {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Result result;
	
	private ActiveDepositBonusQueryCommandResp(Builder builder) {
		this.id = builder.id;
		this.result = new Result(builder);
	}
	
	public static class Builder {
		private String id;
		private Boolean exists;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder exists(Boolean exists) {
			this.exists = exists;
			return this;
		}
		
		public Builder defaults() {
			id = "defaultTestId";
			exists = false;
			return this;
		}
		
		public ActiveDepositBonusQueryCommandResp build() {
			return new ActiveDepositBonusQueryCommandResp(this);
		}	
	}
	
	private class Result {
		
		@SuppressWarnings("unused")
		Boolean exists;
		
		public Result(Builder builder) {
			exists = builder.exists;
		}
	}
}
