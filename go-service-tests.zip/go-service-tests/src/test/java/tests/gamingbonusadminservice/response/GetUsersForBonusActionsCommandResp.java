package tests.gamingbonusadminservice.response;

import java.util.ArrayList;
import java.util.List;

import tests.gamingbonusadminservice.responseobjects.UserBonusAction;

public class GetUsersForBonusActionsCommandResp {

	@SuppressWarnings("unused")
	private String id;
	private Result result;
	
	public GetUsersForBonusActionsCommandResp(Builder builder) {
		this.id = builder.id;
		this.result = new Result(builder);
	}
	
	/**
	 * Return first userbonus_id if there are multiple users_bonusactions returned
	 * @return
	 */
	public Integer getUserbonusId() {
		return getUserbonusId(1);
	}
	
	/**
	 * Return userbonus_id based on num parameter. If you want to get second userbonus_id from multiple result, put 2 as num.
	 * @param num
	 * @return
	 */
	public Integer getUserbonusId(int num) {
		return result.users_bonusactions.get(--num).getUserbonusId();
	}
	
	public static class Builder {
		
		private String id;
		private List<UserBonusAction> users_bonusactions;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder addUserBonusAction(UserBonusAction userBonusAction) {
			users_bonusactions.add(userBonusAction);
			return this;
		}
		
		public Builder defaults() {
			this.id = "defaultTestId";
			this.users_bonusactions = new ArrayList<>();
			
			return this;
		}
		
		public GetUsersForBonusActionsCommandResp build() {
			return new GetUsersForBonusActionsCommandResp(this);
		}
	}
	
	private class Result {
		
		private List<UserBonusAction> users_bonusactions;

		public Result(Builder builder) {
			this.users_bonusactions = builder.users_bonusactions;
		}
	}
}
