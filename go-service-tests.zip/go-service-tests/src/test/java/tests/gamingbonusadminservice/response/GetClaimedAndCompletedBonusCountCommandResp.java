package tests.gamingbonusadminservice.response;

import java.util.ArrayList;
import java.util.List;

import tests.gamingbonusadminservice.responseobjects.BonusCountClaimedAndCompletedResult;

public class GetClaimedAndCompletedBonusCountCommandResp {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private List<BonusCountClaimedAndCompletedResult> result;
 
	private GetClaimedAndCompletedBonusCountCommandResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public static class Builder {
		
		private String id;
		private List<BonusCountClaimedAndCompletedResult> result = new ArrayList<BonusCountClaimedAndCompletedResult>();

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder addResult(BonusCountClaimedAndCompletedResult bonusCountClaimedAndCompletedResult) {
			this.result.add(bonusCountClaimedAndCompletedResult);
			return this;
		}

		public Builder defaults() {
			this.id = "1";
			return this;
		}

		public GetClaimedAndCompletedBonusCountCommandResp build() {
			return new GetClaimedAndCompletedBonusCountCommandResp(this);
		}
	}
}