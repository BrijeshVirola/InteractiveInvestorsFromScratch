package tests.gamingbonusadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.UUID;

import org.testng.Reporter;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusadminservice.request.AddCreditedUsersCommandReq;
import tests.gamingbonusadminservice.request.BonusClaimByAdminCommandReq;
import tests.gamingbonusadminservice.request.ExportClaimedByVersionCommandReq;
import tests.gamingbonusadminservice.request.GetUsersForBonusActionsCommandReq;
import tests.gamingbonusadminservice.request.SpecificBonusCancelByAdminCommandReq;
import tests.gamingbonusadminservice.requestobjects.UserBonus;
import tests.gamingbonusadminservice.response.ExportClaimedByVersionCommandResp;
import tests.gamingbonusadminservice.response.GetUsersForBonusActionsCommandResp;
import tests.gamingbonusadminservice.responseobjects.ExportClaimedByVersionCommandResult;

public class ExportClaimedByVersionCommandTests extends BaseClassSetup {
	
	@Test(description = "Make a request to exportclaimedbyversioncommand. Pre-wager End to end Scenario.")
	public void exportClaimedByVersionCommand_Pre_Wager_End_To_End_Scenario() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		String historyToken = UUID.randomUUID().toString();
		Integer userId = 4681140;
		String username = "GO_SVC_TESTS53";
		BigInteger bonustemplateId = new BigInteger("517");
		Integer versionId = 1062;
		BigDecimal amount = new BigDecimal("1.2");

		Reporter.log("01. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(amount)
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.historyToken(historyToken)
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(id)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		ResultOKResp actAddCreditResp =  BaseRequest.getResponse(addCreditReq, ResponseEndpoints.addCreditedUsersCommandSuccess);

		ResultOKResp expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	

		Reporter.log("02. Get userbonusId using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq getUsersForBonusActionsReq = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(id)
				.bonusTemplateId(bonustemplateId)
				.versionId(versionId)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();
		
		GetUsersForBonusActionsCommandResp actGetUsersForBonusActionsResp = BaseRequest.getResponse(getUsersForBonusActionsReq, ResponseEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actGetUsersForBonusActionsResp.getUserbonusId();
		
		Reporter.log("03. Check that there is no bonus data for the user using exportclaimedbyversioncommand.");
		ExportClaimedByVersionCommandReq exportReq = new ExportClaimedByVersionCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(bonustemplateId)
				.build();

		CustomErrorResponse errorResp =  BaseRequest.getResponse(exportReq, ResponseEndpoints.exportClaimedByVersionCommandError);

		CustomErrorResponse expErrorResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("No data was found for passed Bonus Template Id")
				.code(1001)
				.build();

		assertReflectionEquals(expErrorResp, errorResp);	
		
		Reporter.log("04. Claim the bonus");
		BonusClaimByAdminCommandReq bonusClaimReq = new BonusClaimByAdminCommandReq.Builder()
				.defaults()
				.id(id)
				.userBonusId(userbonusId)
				.userId(userId)
				.build();
		
		ResultOKResp actResultOKResp = BaseRequest.getResponse(bonusClaimReq, ResponseEndpoints.bonusClaimByAdminCommandSuccess);
		ResultOKResp expResultOKResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expResultOKResp, actResultOKResp);	
		
		Reporter.log("05. Check that there is bonus data for the user using exportclaimedbyversioncommand.");
		ExportClaimedByVersionCommandResp exportResp =  BaseRequest.getResponse(exportReq, ResponseEndpoints.exportClaimedByVersionCommandSuccess);
		
		ExportClaimedByVersionCommandResult expResult = new ExportClaimedByVersionCommandResult.Builder()
				.defaults()
				.userId(userId)
				.username(username)
				.amount(amount.toString())
				.templateName("Go Services Pre-Wager Games")
				.templateVersion(1062)
				.startDateUtc("2021-12-13T16:25:00Z")
				.build();

		ExportClaimedByVersionCommandResp expectedExportResp = new ExportClaimedByVersionCommandResp.Builder()
				.defaults()
				.id(id)
				.addResult(expResult)
				.build();

		assertReflectionEquals(expectedExportResp, exportResp);	
		
		Reporter.log("06. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actCancelBonusResp =  BaseRequest.getResponse(cancelBonusReq, ResponseEndpoints.specificBonusCancelByAdminCommandSuccess);

		ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);
	}
	
	@Test(description = "Make a request to exportclaimedbyversioncommand. After-wager End to end Scenario.")
	public void exportClaimedByVersionCommand_After_Wager_End_To_End_Scenario() throws InterruptedException {

		String id = UUID.randomUUID().toString();
		String historyToken = UUID.randomUUID().toString();
		Integer userId = 4681140;
		String username = "GO_SVC_TESTS53";
		BigInteger bonustemplateId = new BigInteger("518");
		Integer versionId = 1063;
		BigDecimal amount = new BigDecimal("0.15");

		Reporter.log("01. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(amount)
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.historyToken(historyToken)
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(id)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		ResultOKResp actAddCreditResp =  BaseRequest.getResponse(addCreditReq, ResponseEndpoints.addCreditedUsersCommandSuccess);

		ResultOKResp expAddCreditResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expAddCreditResp, actAddCreditResp);	

		Reporter.log("02. Get userbonusId using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq getUsersForBonusActionsReq = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(id)
				.bonusTemplateId(bonustemplateId)
				.versionId(versionId)
				.includeOffered(true)
				.addUserId(userId)
				.removeAll(false)
				.build();
		
		GetUsersForBonusActionsCommandResp actGetUsersForBonusActionsResp = BaseRequest.getResponse(getUsersForBonusActionsReq, ResponseEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actGetUsersForBonusActionsResp.getUserbonusId();
		
		Reporter.log("03. Check that there is no bonus data for the user using exportclaimedbyversioncommand.");
		ExportClaimedByVersionCommandReq exportReq = new ExportClaimedByVersionCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(bonustemplateId)
				.build();

		CustomErrorResponse errorResp =  BaseRequest.getResponse(exportReq, ResponseEndpoints.exportClaimedByVersionCommandError);

		CustomErrorResponse expErrorResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(id)
				.message("No data was found for passed Bonus Template Id")
				.code(1001)
				.build();

		assertReflectionEquals(expErrorResp, errorResp);	
		
		Reporter.log("04. Claim the bonus");
		BonusClaimByAdminCommandReq bonusClaimReq = new BonusClaimByAdminCommandReq.Builder()
				.defaults()
				.id(id)
				.userBonusId(userbonusId)
				.userId(userId)
				.build();
		
		ResultOKResp actResultOKResp = BaseRequest.getResponse(bonusClaimReq, ResponseEndpoints.bonusClaimByAdminCommandSuccess);
		ResultOKResp expResultOKResp = new ResultOKResp.Builder()
				.defaults()
				.id(id)
				.build();

		assertReflectionEquals(expResultOKResp, actResultOKResp);	
		
		Reporter.log("05. Check that there is no bonus data for the user using exportclaimedbyversioncommand.");
		exportReq = new ExportClaimedByVersionCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(bonustemplateId)
				.build();

		ExportClaimedByVersionCommandResp exportResp =  BaseRequest.getResponse(exportReq, ResponseEndpoints.exportClaimedByVersionCommandSuccess);
		
		ExportClaimedByVersionCommandResult expResult = new ExportClaimedByVersionCommandResult.Builder()
				.defaults()
				.userId(userId)
				.username(username)
				.amount(amount.toString())
				.templateName("Go Services - exportclaimedbyversioncommand")
				.templateVersion(1063)
				.startDateUtc("2021-12-14T16:15:00Z")
				.build();

		ExportClaimedByVersionCommandResp expectedExportResp = new ExportClaimedByVersionCommandResp.Builder()
				.defaults()
				.id(id)
				.addResult(expResult)
				.build();

		assertReflectionEquals(expectedExportResp, exportResp);	
		
		Reporter.log("06. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actCancelBonusResp =  BaseRequest.getResponse(cancelBonusReq, ResponseEndpoints.specificBonusCancelByAdminCommandSuccess);

		ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);
	}
	
	@Test(description = "Make a request to exportclaimedbyversioncommand. Several results.")
	public void exportClaimedByVersionCommand_Several_Results() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		ExportClaimedByVersionCommandReq exportReq = new ExportClaimedByVersionCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(new BigInteger("519"))
				.build();

		ExportClaimedByVersionCommandResp exportResp =  BaseRequest.getResponse(exportReq, ResponseEndpoints.exportClaimedByVersionCommandSuccess);
		
		ExportClaimedByVersionCommandResult expResult1 = new ExportClaimedByVersionCommandResult.Builder()
				.defaults()
				.userId(4684881)
				.username("GO_SVC_TESTS54")
				.amount("0.12")
				.templateName("Go Services Pre-Wager Games")
				.templateVersion(1064)
				.startDateUtc("2021-12-15T13:05:00Z")
				.build();
		
		ExportClaimedByVersionCommandResult expResult2 = new ExportClaimedByVersionCommandResult.Builder()
				.defaults()
				.userId(4681140)
				.username("GO_SVC_TESTS53")
				.amount("1.36")
				.templateName("Go Services Pre-Wager Games")
				.templateVersion(1064)
				.startDateUtc("2021-12-15T13:05:00Z")
				.build();

		ExportClaimedByVersionCommandResp expectedExportResp = new ExportClaimedByVersionCommandResp.Builder()
				.defaults()
				.id(id)
				.addResult(expResult1)
				.addResult(expResult2)
				.build();

		assertReflectionEquals(expectedExportResp, exportResp);	
	}
	
	@Test(description = "Make a request to exportclaimedbyversioncommand. Missing/Invalid bonustemplate_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void exportClaimedByVersionCommand_Missing_Invalid_Bonus_Template_Id(String nullZero) throws InterruptedException {

		String id = UUID.randomUUID().toString();
		BigInteger bonustemplateId = nullZero.equals("null") ? null : new BigInteger(nullZero);

		ExportClaimedByVersionCommandReq exportReq = new ExportClaimedByVersionCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(bonustemplateId)
				.build();

		CustomErrorResponse resp =  BaseRequest.getResponse(exportReq, ResponseEndpoints.exportClaimedByVersionCommandError);
		
		CustomErrorResponse expResp = new CustomErrorResponse.Builder().defaults()
				.message("Missing/Invalid parameter: bonustemplate_id")
				.code(1003)
				.id(id)
				.build();

		assertReflectionEquals(expResp, resp);	
	}
	
	@Test(description = "Make a request to exportclaimedbyversioncommand. No data found.")
	public void exportClaimedByVersionCommand_No_Data_Found() throws InterruptedException {

		String id = UUID.randomUUID().toString();

		ExportClaimedByVersionCommandReq exportReq = new ExportClaimedByVersionCommandReq.Builder()
				.defaults()
				.id(id)
				.bonustemplateId(new BigInteger("1"))
				.build();

		CustomErrorResponse resp =  BaseRequest.getResponse(exportReq, ResponseEndpoints.exportClaimedByVersionCommandError);
		
		CustomErrorResponse expResp = new CustomErrorResponse.Builder().defaults()
				.message("No data was found for passed Bonus Template Id")
				.code(1001)
				.id(id)
				.build();

		assertReflectionEquals(expResp, resp);	
	}
}
