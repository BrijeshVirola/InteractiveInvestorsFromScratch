package tests.gamingbonusadminservice.responseobjects;

public class ExportCreditButNotClaimedCommandResult {
	
	Integer user_id;
	String username;
	String amount;
	String currency;
	String templatename;
	String startdateutc;
	
	private ExportCreditButNotClaimedCommandResult(Builder builder) {
		user_id = builder.user_id;
		username = builder.username;
		amount = builder.amount;
		currency = builder.currency;
		templatename = builder.templatename;
		startdateutc = builder.startdateutc;
	}
	
	public static class Builder {
		
		Integer user_id;
		String username;
		String amount;
		String currency;
		String templatename;
		String startdateutc;
		
		public Builder username(String username) {
			this.username = username;
			return this;
		}
		
		public Builder userId(Integer userId) {
			user_id = userId;
			return this;
		}
		
		public Builder templateName(String templateName) {
			this.templatename = templateName;
			return this;
		}
		
		public Builder startDateUtc(String startDateUtc) {
			this.startdateutc = startDateUtc;
			return this;
		}
		
		public Builder amount(String amount) {
			this.amount = amount;
			return this;
		}
		
		public Builder currency(String currency) {
			this.currency = currency;
			return this;
		}
		
		public Builder defaults() {
			user_id = 4685399;
			username = "GO_SVC_TESTS55";
			amount = "1";
			currency = "GBP";
			templatename = "Go Services Cash Casino - exportclaimedbyversionco";
			startdateutc = "2021-12-13T15:15:00Z";
			return this;
		}
		
		public ExportCreditButNotClaimedCommandResult build() {
			return new ExportCreditButNotClaimedCommandResult(this);
		}
	}
}
