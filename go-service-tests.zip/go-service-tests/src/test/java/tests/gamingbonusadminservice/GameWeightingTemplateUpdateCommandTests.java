package tests.gamingbonusadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import common.DatabaseQueries;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusadminservice.request.GameWeightingTemplateUpdateCommandReq;
import tests.gamingbonusadminservice.requestobjects.GameWeight;

public class GameWeightingTemplateUpdateCommandTests extends BaseClassSetup {
	
	@Test(description = "Make a request to gameweightingtemplateupdatecommand. Positive Scenario.")
	public void gameWeightingTemplateUpdateCommand_Positive_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		int regulatedGameId = 22990;
		int gameweighttemplateId = 71;
		int randomWeight = ThreadLocalRandom.current().nextInt(0, 101);
		
		GameWeightingTemplateUpdateCommandReq req = new GameWeightingTemplateUpdateCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.gameweighttemplateId(gameweighttemplateId)
				.addGameWeight(new GameWeight.Builder()
						.defaults()
						.regulatedgame_id(regulatedGameId)
						.weight(randomWeight)
						.build())
				.build();

		ResultOKResp resp =  BaseRequest.getResponse(req, ResponseEndpoints.gameWeightingTemplateUpdateCommandSuccess);

		ResultOKResp expResp = new ResultOKResp.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expResp, resp);
		
		int dbGameWeight = DatabaseQueries.getGameWeighFromGameWeightTemplateMapping(gameweighttemplateId, regulatedGameId);
		
		Assert.assertEquals(dbGameWeight, randomWeight, "GameWeight");
	}
	
	@Test(description = "Make a request to gameweightingtemplateupdatecommand. Missing/Invalid gameweighttemplate_id.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void gameWeightingTemplateUpdateCommand_Missing_Invalid_Gameweighttemplate_id(String gameweighttemplateIdProvider) throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer gameweighttemplateId = gameweighttemplateIdProvider.equals("null") ? null : Integer.parseInt(gameweighttemplateIdProvider);
		
		GameWeightingTemplateUpdateCommandReq req = new GameWeightingTemplateUpdateCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.gameweighttemplateId(gameweighttemplateId)
				.addGameWeight(new GameWeight.Builder()
						.defaults()
						.build())
				.build();

		CustomErrorResponse resp =  BaseRequest.getResponse(req, ResponseEndpoints.gameWeightingTemplateUpdateCommandError);

		CustomErrorResponse expResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.code(1003)
				.message("Missing/Invalid parameter: gameweighttemplate_id")
				.build();
		
		assertReflectionEquals(expResp, resp);
	}
	
	@Test(description = "Make a request to gameweightingtemplateupdatecommand. Missing/Invalid gameweights.")
	public void gameWeightingTemplateUpdateCommand_Missing_Invalid_Gameweights() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GameWeightingTemplateUpdateCommandReq req = new GameWeightingTemplateUpdateCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse resp =  BaseRequest.getResponse(req, ResponseEndpoints.gameWeightingTemplateUpdateCommandError);

		CustomErrorResponse expResp = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.code(1003)
				.message("Missing/Invalid parameter: gameweights")
				.build();
		
		assertReflectionEquals(expResp, resp);
	}
}
