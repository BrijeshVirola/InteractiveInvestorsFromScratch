package tests.gamingbonusadminservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.UUID;

import org.testng.Reporter;
import org.testng.annotations.Test;
import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DataProviders;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.gamingbonusadminservice.request.AddCreditedUsersCommandReq;
import tests.gamingbonusadminservice.request.GetUsersForBonusActionsCommandReq;
import tests.gamingbonusadminservice.request.SpecificBonusCancelByAdminCommandReq;
import tests.gamingbonusadminservice.requestobjects.UserBonus;
import tests.gamingbonusadminservice.response.GetUsersForBonusActionsCommandResp;
import tests.gamingbonusadminservice.responseobjects.UserBonusAction;

public class GetUsersForBonusActionsCommandTests extends BaseClassSetup {
	
	@Test(description = "Make a request to getusersforbonusactionscommand. Single user after-wager bonus games.")
	public void getUsersForBonusActionsCommand_Single_User_After_Wager_Bonus_Games() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = 4658635;
		BigInteger bonustemplateId = new BigInteger("468");
		
		Reporter.log("01. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(new BigDecimal("10"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.getResponse(addCreditReq, ResponseEndpoints.addCreditedUsersCommandSuccess);
		
		Reporter.log("02. Check that bonus is credited using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.bonusTemplateId(bonustemplateId)
										.versionId(1000)
										.includeOffered(true)
										.addUserId(userId)
										.removeAll(false)
										.build();
		
		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actualResponse.getUserbonusId();
		
		UserBonusAction expUserBonusAction = new UserBonusAction.Builder()
				.defaults()
				.username("GO_SVC_TESTS35")
				.userId(userId)
				.userbonusId(userbonusId)
				.userbonusStatus("Offered(Credited)")
				.amountPence(1000)
				.versionId(0)
				.currency("GBP")
				.build();
		
		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.addUserBonusAction(expUserBonusAction)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
		
		Reporter.log("03. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actCancelBonusResp =  BaseRequest.getResponse(cancelBonusReq, ResponseEndpoints.specificBonusCancelByAdminCommandSuccess);

		ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);
	}
	
	@Test(description = "Make a request to getusersforbonusactionscommand. Single user pre-wager bonus games.")
	public void getUsersForBonusActionsCommand_Single_User_Pre_Wager_Bonus_Games() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = 4658410;
		BigInteger bonustemplateId = new BigInteger("467");
		
		Reporter.log("01. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(new BigDecimal("5.20"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.getResponse(addCreditReq, ResponseEndpoints.addCreditedUsersCommandSuccess);
		
		Reporter.log("02. Check that bonus is credited using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.bonusTemplateId(bonustemplateId)
										.versionId(999)
										.includeOffered(true)
										.addUserId(userId)
										.removeAll(false)
										.build();
		
		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actualResponse.getUserbonusId();
		
		UserBonusAction expUserBonusAction = new UserBonusAction.Builder()
				.defaults()
				.username("GO_SVC_TESTS34")
				.userId(userId)
				.userbonusId(userbonusId)
				.userbonusStatus("Offered(Credited)")
				.amountPence(520)
				.versionId(0)
				.currency("GBP")
				.build();
		
		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.addUserBonusAction(expUserBonusAction)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
		
		Reporter.log("03. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actCancelBonusResp =  BaseRequest.getResponse(cancelBonusReq, ResponseEndpoints.specificBonusCancelByAdminCommandSuccess);

		ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);
	}
	
	@Test(description = "Make a request to getusersforbonusactionscommand. Single user cash bonus games.")
	public void getUsersForBonusActionsCommand_Single_User_Cash_Bonus_Games() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = 4656204;
		BigInteger bonustemplateId = new BigInteger("466");
		
		Reporter.log("01. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(new BigDecimal("0.16"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.getResponse(addCreditReq, ResponseEndpoints.addCreditedUsersCommandSuccess);
		
		Reporter.log("02. Check that bonus is credited using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.bonusTemplateId(bonustemplateId)
										.versionId(998)
										.includeOffered(true)
										.addUserId(userId)
										.removeAll(false)
										.build();
		
		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actualResponse.getUserbonusId();
		
		UserBonusAction expUserBonusAction = new UserBonusAction.Builder()
				.defaults()
				.username("GO_SVC_TESTS33")
				.userId(userId)
				.userbonusId(userbonusId)
				.userbonusStatus("Offered(Credited)")
				.amountPence(16)
				.versionId(0)
				.currency("GBP")
				.build();
		
		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.addUserBonusAction(expUserBonusAction)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
		
		Reporter.log("03. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actCancelBonusResp =  BaseRequest.getResponse(cancelBonusReq, ResponseEndpoints.specificBonusCancelByAdminCommandSuccess);

		ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);
	}
	
	@Test(description = "Make a request to getusersforbonusactionscommand. Single user after-wager bonus casino.")
	public void getUsersForBonusActionsCommand_Single_User_After_Wager_Casino() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = 4658635;
		BigInteger bonustemplateId = new BigInteger("465");
		
		Reporter.log("01. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(new BigDecimal("0.2"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.getResponse(addCreditReq, ResponseEndpoints.addCreditedUsersCommandSuccess);
		
		Reporter.log("02. Check that bonus is credited using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.bonusTemplateId(bonustemplateId)
										.versionId(997)
										.includeOffered(true)
										.addUserId(userId)
										.removeAll(false)
										.build();
		
		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actualResponse.getUserbonusId();
		
		UserBonusAction expUserBonusAction = new UserBonusAction.Builder()
				.defaults()
				.username("GO_SVC_TESTS35")
				.userId(userId)
				.userbonusId(userbonusId)
				.userbonusStatus("Offered(Credited)")
				.amountPence(20)
				.versionId(0)
				.currency("GBP")
				.build();
		
		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.addUserBonusAction(expUserBonusAction)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
		
		Reporter.log("03. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actCancelBonusResp =  BaseRequest.getResponse(cancelBonusReq, ResponseEndpoints.specificBonusCancelByAdminCommandSuccess);

		ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);
	}
	
	@Test(description = "Make a request to getusersforbonusactionscommand. Single user pre-wager bonus casino.")
	public void getUsersForBonusActionsCommand_Single_User_Pre_Wager_Casino() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = 4658410;
		BigInteger bonustemplateId = new BigInteger("464");
		
		Reporter.log("01. Credit user using addCreditedUsersCommand");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(bonustemplateId)
				.amount(new BigDecimal("2"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.getResponse(addCreditReq, ResponseEndpoints.addCreditedUsersCommandSuccess);
		
		Reporter.log("02. Check that bonus is credited using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.bonusTemplateId(bonustemplateId)
										.versionId(995)
										.includeOffered(true)
										.addUserId(userId)
										.removeAll(false)
										.build();
		
		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer userbonusId = actualResponse.getUserbonusId();
		
		UserBonusAction expUserBonusAction = new UserBonusAction.Builder()
				.defaults()
				.username("GO_SVC_TESTS34")
				.userId(userId)
				.userbonusId(userbonusId)
				.userbonusStatus("Offered(Credited)")
				.amountPence(200)
				.versionId(0)
				.currency("GBP")
				.build();
		
		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.addUserBonusAction(expUserBonusAction)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
		
		Reporter.log("03. Remove the bonus user using specificbonuscancelbyadmincommand");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(userbonusId)
				.build();

		ResultOKResp actCancelBonusResp =  BaseRequest.getResponse(cancelBonusReq, ResponseEndpoints.specificBonusCancelByAdminCommandSuccess);

		ResultOKResp expCancelBonusResp = new ResultOKResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expCancelBonusResp, actCancelBonusResp);
	}
	
	@Test(description = "Make a request to getusersforbonusactionscommand. Single user cash bonus casino. include_offered = true")
	public void getUsersForBonusActionsCommand_Single_User_Cash_Casino_Offered_True() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.bonusTemplateId(new BigInteger("452"))
										.versionId(958)
										.includeOffered(true)
										.addUserId(4656204)
										.removeAll(false)
										.build();
		
		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getUsersForBonusActionsCommandSuccess);
		
		UserBonusAction expUserBonusAction = new UserBonusAction.Builder()
				.defaults()
				.username("GO_SVC_TESTS33")
				.userId(4656204)
				.userbonusId(6707)
				.userbonusStatus("Offered(Credited)")
				.amountPence(500)
				.versionId(0)
				.currency("GBP")
				.build();
		
		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.addUserBonusAction(expUserBonusAction)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
	}
	
	@Test(description = "Make a request to getusersforbonusactionscommand. Single user. include_offered = false")
	public void getUsersForBonusActionsCommand_Single_User_Offered_False() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.bonusTemplateId(new BigInteger("452"))
										.versionId(958)
										.includeOffered(false)
										.addUserId(UsersId.GO_SVC_TESTS33)
										.removeAll(false)
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getUsersForBonusActionsCommandError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("No data was found for passed parameters")
				.code(1001)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);		
	}
	
	@Test(description = "Make a request to getusersforbonusactionscommand. Multiple users.")
	public void getUsersForBonusActionsCommand_Multiple_Users() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.bonusTemplateId(new BigInteger("452"))
				.versionId(958)
				.includeOffered(true)
				.addUserId(UsersId.GO_SVC_TESTS32)
				.addUserId(UsersId.GO_SVC_TESTS33)
				.removeAll(false)
				.build();
		
		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getUsersForBonusActionsCommandSuccess);
		
		UserBonusAction expUserBonusAction1 = new UserBonusAction.Builder()
				.defaults()
				.username("GO_SVC_TESTS32")
				.userId(UsersId.GO_SVC_TESTS32)
				.userbonusId(6679)
				.userbonusStatus("Offered(Credited)")
				.amountPence(100)
				.versionId(0)
				.currency("GBP")
				.build();
		
		UserBonusAction expUserBonusAction2 = new UserBonusAction.Builder()
				.defaults()
				.username("GO_SVC_TESTS32")
				.userId(UsersId.GO_SVC_TESTS32)
				.userbonusId(6680)
				.userbonusStatus("Offered(Credited)")
				.amountPence(100)
				.versionId(0)
				.currency("GBP")
				.build();
		
		UserBonusAction expUserBonusAction3 = new UserBonusAction.Builder()
				.defaults()
				.username("GO_SVC_TESTS33")
				.userId(UsersId.GO_SVC_TESTS33)
				.userbonusId(6707)
				.userbonusStatus("Offered(Credited)")
				.amountPence(500)
				.versionId(0)
				.currency("GBP")
				.build();
		
		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.addUserBonusAction(expUserBonusAction1)
															.addUserBonusAction(expUserBonusAction2)
															.addUserBonusAction(expUserBonusAction3)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
	}
	
	@Test(description = "Make a request to getusersforbonusactionscommand. Single user. Remove all = true")
	public void getUsersForBonusActionsCommand_Single_User_Remove_All() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.bonusTemplateId(new BigInteger("452"))
				.versionId(958)
				.includeOffered(true)
				.addUserId(UsersId.GO_SVC_TESTS33)
				.removeAll(true)
				.build();
		
		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getUsersForBonusActionsCommandSuccess);
		
		UserBonusAction expUserBonusAction1 = new UserBonusAction.Builder()
				.defaults()
				.username("GO_SVC_TESTS32")
				.userId(UsersId.GO_SVC_TESTS32)
				.userbonusId(6679)
				.userbonusStatus("Offered(Credited)")
				.amountPence(100)
				.versionId(0)
				.currency("GBP")
				.build();
		
		UserBonusAction expUserBonusAction2 = new UserBonusAction.Builder()
				.defaults()
				.username("GO_SVC_TESTS32")
				.userId(UsersId.GO_SVC_TESTS32)
				.userbonusId(6680)
				.userbonusStatus("Offered(Credited)")
				.amountPence(100)
				.versionId(0)
				.currency("GBP")
				.build();
		
		UserBonusAction expUserBonusAction3 = new UserBonusAction.Builder()
				.defaults()
				.username("GO_SVC_TESTS33")
				.userId(UsersId.GO_SVC_TESTS33)
				.userbonusId(6707)
				.userbonusStatus("Offered(Credited)")
				.amountPence(500)
				.versionId(0)
				.currency("GBP")
				.build();
		
		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.addUserBonusAction(expUserBonusAction1)
															.addUserBonusAction(expUserBonusAction2)
															.addUserBonusAction(expUserBonusAction3)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
	}
	
	@Test(description = "Make a request to getusersforbonusactionscommand. Offered and granted user. include_offered = true")
	public void getUsersForBonusActionsCommand_Offered_And_Granted_Offered_True() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = 4659130;
		String username = "GO_SVC_TESTS36";
		
		Reporter.log("01. Credit user using addCreditedUsersCommand - this is a preconditon as this bonus is expiring after some time");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(new BigInteger("467"))
				.amount(new BigDecimal("1.1"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.getResponse(addCreditReq, ResponseEndpoints.addCreditedUsersCommandSuccess);
		
		
		Reporter.log("02. Check that offered and granted bonuses are shown using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.bonusTemplateId(new BigInteger("467"))
										.versionId(999)
										.includeOffered(true)
										.addUserId(userId)
										.removeAll(false)
										.build();
		
		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getUsersForBonusActionsCommandSuccess);
		Integer secondUserBonusId = actualResponse.getUserbonusId(2);
		
		UserBonusAction expUserBonusAction1 = new UserBonusAction.Builder()
				.defaults()
				.username(username)
				.userId(userId)
				.userbonusId(6824)
				.userbonusStatus("Granted")
				.amountPence(100)
				.versionId(1)
				.currency("GBP")
				.build();
		
		UserBonusAction expUserBonusAction2 = new UserBonusAction.Builder()
				.defaults()
				.username(username)
				.userId(userId)
				.userbonusId(secondUserBonusId)
				.userbonusStatus("Offered(Credited)")
				.amountPence(110)
				.versionId(0)
				.currency("GBP")
				.build();
		
		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.addUserBonusAction(expUserBonusAction1)
															.addUserBonusAction(expUserBonusAction2)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
		
		Reporter.log("03. Remove the bonus user using specificbonuscancelbyadmincommand. This is cleaning everytime the offered bonus at the end.");
		SpecificBonusCancelByAdminCommandReq cancelBonusReq = new SpecificBonusCancelByAdminCommandReq.Builder()
				.defaults()
				.userId(userId)
				.userBonusId(secondUserBonusId)
				.build();

		BaseRequest.getResponse(cancelBonusReq, ResponseEndpoints.specificBonusCancelByAdminCommandSuccess);
	}
	
	@Test(description = "Make a request to getusersforbonusactionscommand. Offered and granted user. include_offered = false")
	public void getUsersForBonusActionsCommand_Offered_And_Granted_Offered_False() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer userId = 4689152;
		String username = "GO_SVC_TESTS59";
		
		Reporter.log("01. Credit user using addCreditedUsersCommand - this is a preconditon as this bonus is expiring after some time");
		UserBonus userBonus = new UserBonus.Builder()
				.defaults()
				.userId(userId)
				.bonustemplateId(new BigInteger("467"))
				.amount(new BigDecimal("1.1"))
				.creditTimeUtc("2021-11-15T12:34:23.390Z")
				.build();

		AddCreditedUsersCommandReq addCreditReq = new AddCreditedUsersCommandReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.addUserBonus(userBonus)
				.creditedby("vasilz")
				.build();

		BaseRequest.getResponse(addCreditReq, ResponseEndpoints.addCreditedUsersCommandSuccess);
		
		Reporter.log("02. Check that only granted bonus is shown using getusersforbonusactionscommand");
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.bonusTemplateId(new BigInteger("467"))
										.versionId(999)
										.includeOffered(false)
										.addUserId(userId)
										.removeAll(false)
										.build();
		
		GetUsersForBonusActionsCommandResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getUsersForBonusActionsCommandSuccess);
		
		UserBonusAction expUserBonusAction1 = new UserBonusAction.Builder()
				.defaults()
				.username(username)
				.userId(userId)
				.userbonusId(8060)
				.userbonusStatus("Granted")
				.amountPence(100)
				.versionId(1)
				.currency("GBP")
				.build();
		
		GetUsersForBonusActionsCommandResp expectedResponse = new GetUsersForBonusActionsCommandResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.addUserBonusAction(expUserBonusAction1)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to getusersforbonusactionscommand. Bonus Template id missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void getUsersForBonusActionsCommand_Bonus_Template_Missing(String bonusTemplId) throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		BigInteger bonusTemplateId = bonusTemplId.equals("null") ? null : new BigInteger(bonusTemplId);
		
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.addUserId(UsersId.GO_SVC_TESTS32)
										.bonusTemplateId(bonusTemplateId)
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getUsersForBonusActionsCommandError);
		
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing/invalid parameter: bonustemplate_id")
				.code(1003)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
	}
	
	@Test(description = "Make a request to getusersforbonusactionscommand. Version id missing or invalid.",
			dataProviderClass = DataProviders.class, dataProvider = "nullZero")
	public void getUsersForBonusActionsCommand_Version_Id_Missing(String versionIdString) throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		Integer versionId = versionIdString.equals("null") ? null : Integer.parseInt(versionIdString);
		
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.addUserId(UsersId.GO_SVC_TESTS32)
										.versionId(versionId)
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getUsersForBonusActionsCommandError);
		
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing/invalid parameter: version_id")
				.code(1003)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
	}
	
	@Test(description = "Make a request to getusersforbonusactionscommand. Not proper version id.")
	public void getUsersForBonusActionsCommand_No_Data() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.addUserId(UsersId.GO_SVC_TESTS32)
										.versionId(1)
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getUsersForBonusActionsCommandError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("No data was found for passed parameters")
				.code(1001)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
	}
	
	@Test(description = "Make a request to getusersforbonusactionscommand.User Ids invalid.")
	public void getUsersForBonusActionsCommand_User_Ids_Invalid() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.addUserId(0)
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getUsersForBonusActionsCommandError);
		
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Invalid user id: 0")
				.code(1003)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
	}
	
	@Test(description = "Make a request to getusersforbonusactionscommand.User Ids missing.")
	public void getUsersForBonusActionsCommand_User_Ids_Missing() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetUsersForBonusActionsCommandReq request = new GetUsersForBonusActionsCommandReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getUsersForBonusActionsCommandError);
		
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing/invalid parameter: user_ids")
				.code(1003)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
	}
}
