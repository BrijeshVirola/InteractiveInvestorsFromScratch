package tests.slotsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.Utils;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.slotsservice.request.LinkGameSessionToGameRoundReq;
import tests.slotsservice.response.ResultResp;

public class LinkGameSessionToGameRoundTests extends BaseClassSetup {

	@Test(description = "Make a request to LinkGameSessionToGameRound. Positive scenario.")
	public void linkGameSessionToGameRound_Positive_Scenario() {

		// Create new slots session
		Utils.createNewSlotsSession("GO_SVC_SLOTS2", new BigDecimal("50.0"));

		String gameSessionId = Utils.getSlotsGameSessionId(UsersId.GO_SVC_SLOTS2);

		LinkGameSessionToGameRoundReq request = new LinkGameSessionToGameRoundReq.Builder()
				.defaults()
				.gameRoundId(22222)
				.gameSessionId(gameSessionId)
				.build();

		ResultResp actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.linkGameSessionToGameRoundSuccess);

		ResultResp expResponse = new ResultResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to LinkGameSessionToGameRound. Invalid request.")
	public void linkGameSessionToGameRound_GameSession_Not_Found() {

		LinkGameSessionToGameRoundReq request = new LinkGameSessionToGameRoundReq.Builder()
				.defaults()
				.gameRoundId(333333)
				.gameSessionId("232131-112b-4123-bbb8-b6b44b585123")
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.linkGameSessionToGameRoundError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(4)
				.message("Invalid request")
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to LinkGameSessionToGameRound. Missing parameter.")
	public void linkGameSessionToGameRound_Missing_Parameter() {

		LinkGameSessionToGameRoundReq request = new LinkGameSessionToGameRoundReq.Builder()
				.defaults()
				.gameRoundId(null)
				.gameSessionId(null)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.linkGameSessionToGameRoundError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: game_round_id")
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to LinkGameSessionToGameRound. Wrong method.")
	public void linkGameSessionToGameRound_Wrong_Method() {

		LinkGameSessionToGameRoundReq request = new LinkGameSessionToGameRoundReq.Builder()
				.gameRoundId(444444)
				.gameSessionId(null)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.linkGameSessionToGameRoundError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(4)
				.message("Invalid request")
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}
}
