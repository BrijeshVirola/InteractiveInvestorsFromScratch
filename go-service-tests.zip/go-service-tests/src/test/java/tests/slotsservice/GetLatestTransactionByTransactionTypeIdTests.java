package tests.slotsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.TransactionType;
import common.Utils;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.ServiceErrors;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.slotsservice.request.GetLatestTransactionByTransactionTypeIdReq;
import tests.slotsservice.request.SlotsAdjustBalanceReq;
import tests.slotsservice.response.GetSlotsTransactionResp;
import tests.slotsservice.responseobjects.InsertTransaction;

public class GetLatestTransactionByTransactionTypeIdTests extends BaseClassSetup {

	@Test(description = "Make a request to GetLatestTransactionByTransactionTypeId. Positive scenario.")
	public void getLatestTransactionByTransactionTypeId_Positive_Scenario() {
		String stakeAmountNegative = "-0.03";
		String partnerTransactionId = UUID.randomUUID().toString();
		String partnerTimestampUtc = Instant.now().toString();
		Long gameRoundId = UUID.randomUUID().getMostSignificantBits() & Long.MAX_VALUE;

		// 1. Create new slots session
		String token = Utils.createNewSlotsSession("GO_SVC_SLOTS2", new BigDecimal("50.0"));
		String gameSessionId = Utils.getSlotsGameSessionId(UsersId.GO_SVC_SLOTS2);

		// 2. Send SlotsStake request in order to play a game round
		SlotsAdjustBalanceReq stakeRequest = new SlotsAdjustBalanceReq.Builder()
				.defaults()
				.userId(UsersId.GO_SVC_SLOTS2)
				.gameSessionId(gameSessionId)
				.transactionTypeId(TransactionType.SLOTS_STAKE.getValue())
				.gameRoundId(gameRoundId)
				.totalAmount(stakeAmountNegative)
				.partnerTransactionId(partnerTransactionId)
				.partnerTimestampUtc(partnerTimestampUtc)
				.token(token)
				.build();

		GetSlotsTransactionResp stakeResp = BaseRequest.getResponse(stakeRequest, ResponseEndpoints.slotsAdjustBalanceSuccess);

		// 3. Send GetLatestTransactionByTransactionTypeId request in order to retrieve the latest transaction created in step 2
		GetLatestTransactionByTransactionTypeIdReq request = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.transactionTypeId(129)
				.build();

		GetSlotsTransactionResp actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getLatestSlotsTransactionByTransactionTypeIdSuccess);

		// 4. Validate the response from GetLatestTransactionByTransactionTypeId request
		GetSlotsTransactionResp expResponse = new GetSlotsTransactionResp.Builder()
				.defaults()
				.addTransaction(new InsertTransaction.Builder().
						defaults()
						.bet365GamesTransactionId(stakeResp.getResult().getBet365GamesTransactionId())
						.transactionTypeId(TransactionType.SLOTS_STAKE.getValue())
						.partnerTimestampUtc(partnerTimestampUtc)
						.partnerTransactionId(partnerTransactionId)
						.totalAmount(stakeAmountNegative)
						.gameRoundId(gameRoundId)
						.isNew(false)
						.build())
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to getLatestTransactionByTransactionTypeId - Transaction Not Found.")
	public void getLatestTransactionByTransactionTypeId_Transaction_Not_Found() {

		GetLatestTransactionByTransactionTypeIdReq requestBody = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.transactionTypeId(1111)
				.build();

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1011)
				.message("Transaction not found")
				.build();

		CustomErrorResponse actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getLatestSlotsTransactionByTransactionTypeIdError);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to GetLatestTransactionByTransactionTypeId. Missing parameter - userId.")
	public void getLatestTransactionByTransactionTypeId_Missing_Parameter_UserId() {

		GetLatestTransactionByTransactionTypeIdReq request = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.userId(null)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getLatestSlotsTransactionByTransactionTypeIdError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message(ServiceErrors.MISSING_REQUIRED_PARAM_USER_ID.getMessage())
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to GetLatestTransactionByTransactionTypeId. Missing parameter - provider_region_id.")
	public void getLatestTransactionByTransactionTypeId_Missing_Parameter_ProviderRegionId() {

		GetLatestTransactionByTransactionTypeIdReq request = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.providerRegionId(null)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getLatestSlotsTransactionByTransactionTypeIdError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message(ServiceErrors.MISSING_PROVIDER_REGION_ID.getMessage())
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to GetLatestTransactionByTransactionTypeId. Missing parameter - partner_id.")
	public void getLatestTransactionByTransactionTypeId_Missing_Parameter_PartnerId() {

		GetLatestTransactionByTransactionTypeIdReq request = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.partnerId(null)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getLatestSlotsTransactionByTransactionTypeIdError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message(ServiceErrors.MISSING_REQUIRED_PARAM_PARTNER_ID.getMessage())
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to GetLatestTransactionByTransactionTypeId. Missing parameter - transaction_type_id.")
	public void getLatestTransactionByTransactionTypeId_Missing_Parameter_TransactionTypeId() {

		GetLatestTransactionByTransactionTypeIdReq request = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.transactionTypeId(null)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getLatestSlotsTransactionByTransactionTypeIdError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message(ServiceErrors.MISSING_REQUIRED_PARAM_PARTNER_TRANSACTION_TYPE_ID.getMessage())
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to GetLatestTransactionByTransactionTypeId. Wrong method.")
	public void getLatestTransactionByTransactionTypeId_Wrong_Method() {

		GetLatestTransactionByTransactionTypeIdReq request = new GetLatestTransactionByTransactionTypeIdReq.Builder()
				.defaults()
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getLatestSlotsTransactionByTransactionTypeIdError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}
}
