package tests.slotsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.slotsservice.request.GetTransactionByIDReq;
import tests.slotsservice.response.GetSlotsTransactionResp;

public class GetTransactionByIDTests extends BaseClassSetup {

	@Test(description = "Make a request to getTransactionsById. Positive default scenario.")
	public void getTransactionById_Positive_Default_Scenario() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetTransactionByIDReq requestBody = new GetTransactionByIDReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		GetSlotsTransactionResp expectedResponse = new GetSlotsTransactionResp.Builder()
				.defaults()
				.build();

		GetSlotsTransactionResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getSlotsTransactionByIdSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getTransactionsById with invalid method.")
	public void getTransactionsById_Invalid_Method() {

		GetTransactionByIDReq requestBody = new GetTransactionByIDReq.Builder()
				.defaults()
				.method("INVALID_METHOD")
				.id(null)
				.build();

		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getSlotsTransactionByIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getTransactionsById with missing parameter id.")
	public void getTransactionsById_Missing_Id() {

		GetTransactionByIDReq requestBody = new GetTransactionByIDReq.Builder()
				.defaults()
				.idInParams(null)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getSlotsTransactionByIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: ID")
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getTransactionsById unknown id.")
	public void getTransactionsById_Unknown_Id() {
		Long unknownId = 281474976710656L;

		GetTransactionByIDReq requestBody = new GetTransactionByIDReq.Builder()
				.defaults()
				.idInParams(unknownId)
				.build();

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1011)
				.message("Transaction not found")
				.build();

		CustomErrorResponse actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getSlotsTransactionByIdError);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
