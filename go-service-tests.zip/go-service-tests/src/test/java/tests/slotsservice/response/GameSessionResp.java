package tests.slotsservice.response;

import java.util.HashMap;
import java.util.Map;

public class GameSessionResp {

	@SuppressWarnings("unused")
	private String id = null;
	private Map<String, Object> result = new HashMap<>();

	private GameSessionResp(Builder builder) {
		this.id = builder.id;
		this.result.put("game_session_id", builder.game_session_id);
		this.result.put("session_id", builder.session_id);
		this.result.put("is_active", builder.is_active);
		this.result.put("end_date_utc", builder.end_date_utc);
		this.result.put("user_id", builder.user_id);
	}

	public String getGameSessionId() {
		return this.result.get("game_session_id").toString();
	}

	public String getSessionId() {
		return this.result.get("session_id").toString();
	}

	public Boolean getIsActive() {
		return Boolean.valueOf(this.result.get("is_active").toString());
	}

	public String getEndDateUtc() {
		return this.result.get("end_date_utc").toString();
	}

	public int getUserId() {
		Double userId = new Double(this.result.get("user_id").toString());
		return userId.intValue();
	}

	public static class Builder {
		private String id;
		private String game_session_id;
		private String session_id;
		private boolean is_active;
		private String end_date_utc;
		private Integer user_id;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder gameSessionId(String game_session_id) {
			this.game_session_id = game_session_id;
			return this;
		}

		public Builder sessionId(String session_id) {
			this.session_id = session_id;
			return this;
		}

		public Builder isActive(boolean is_active) {
			this.is_active = is_active;
			return this;
		}

		public Builder endDateUtc(String end_date_utc) {
			this.end_date_utc = end_date_utc;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder defaults() {
			this.id = null;
			this.is_active = true;
			return this;
		}

		public GameSessionResp build() {
			return new GameSessionResp(this);
		}	
	}
}
