package tests.slotsservice.response;

import java.util.ArrayList;
import java.util.List;

import tests.slotsservice.responseobjects.SelectTransaction;

public class GetSlotsTransactionsResp {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private List<SelectTransaction> result;

	private GetSlotsTransactionsResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.selectTransaction;
	}

	public static class Builder {
		private String id;
		private List<SelectTransaction> selectTransaction;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder addTransaction(SelectTransaction selectTransaction) {
			this.selectTransaction.add(selectTransaction);
			return this;
		}

		public Builder defaults() {
			this.selectTransaction = new ArrayList<SelectTransaction>();
			return this;
		}

		public GetSlotsTransactionsResp build() {
			return new GetSlotsTransactionsResp(this);
		}
	}
}
