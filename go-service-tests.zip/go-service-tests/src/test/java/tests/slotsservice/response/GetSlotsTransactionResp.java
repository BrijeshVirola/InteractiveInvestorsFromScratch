package tests.slotsservice.response;

import tests.slotsservice.responseobjects.InsertTransaction;

public class GetSlotsTransactionResp {

	@SuppressWarnings("unused")
	private String id;
	private InsertTransaction result;

	private GetSlotsTransactionResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.insertTransaction;
	}

	public InsertTransaction getResult() {
		return result;
	}

	public static class Builder {
		private String id;
		private InsertTransaction insertTransaction;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder addTransaction(InsertTransaction insertTransaction) {
			this.insertTransaction = insertTransaction;
			return this;
		}

		public Builder defaults() {
			this.insertTransaction = new InsertTransaction.Builder().defaults().build();
			return this;
		}

		public GetSlotsTransactionResp build() {
			return new GetSlotsTransactionResp(this);
		}
	}
}
