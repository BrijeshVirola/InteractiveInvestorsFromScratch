package tests.slotsservice.response;

public class ResultResp {

	@SuppressWarnings("unused")
	private String id = null;
	@SuppressWarnings("unused")
	private String result;

	private ResultResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}

	public static class Builder {
		private String id;
		private String result;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder result(String result) {
			this.result = result;
			return this;
		}

		public Builder defaults() {
			this.id = null;
			this.result = "OK";
			return this;
		}

		public ResultResp build() {
			return new ResultResp(this);
		}	
	}
}
