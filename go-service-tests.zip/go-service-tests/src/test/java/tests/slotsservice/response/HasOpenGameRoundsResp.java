package tests.slotsservice.response;

import java.util.HashMap;
import java.util.Map;

public class HasOpenGameRoundsResp {

	@SuppressWarnings("unused")
	private String id = null;
	private Map<String, Object> result = new HashMap<>();

	private HasOpenGameRoundsResp(Builder builder) {
		this.id = builder.id;
		this.result.put("has_open_game_rounds", builder.has_open_game_rounds);
	}

	public static class Builder {
		private String id;
		private Boolean has_open_game_rounds;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder hasOpenGameRounds(Boolean has_open_game_rounds) {
			this.has_open_game_rounds = has_open_game_rounds;
			return this;
		}

		public Builder defaults() {
			this.id = null;
			this.has_open_game_rounds = false;
			return this;
		}

		public HasOpenGameRoundsResp build() {
			return new HasOpenGameRoundsResp(this);
		}	
	}
}
