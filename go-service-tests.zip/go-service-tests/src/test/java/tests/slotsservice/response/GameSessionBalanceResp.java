package tests.slotsservice.response;

import java.util.HashMap;
import java.util.Map;

public class GameSessionBalanceResp {

	@SuppressWarnings("unused")
	private String id = null;
	private Map<String, Object> result = new HashMap<>();

	private GameSessionBalanceResp(Builder builder) {
		this.id = builder.id;
		this.result.put("balance", builder.balance);
	}
	
	public String getBalance() {
		return this.result.get("balance").toString();
	}

	public static class Builder {
		private String id;
		private String balance;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder balance(String balance) {
			this.balance = balance;
			return this;
		}

		public Builder defaults() {
			this.id = null;
			this.balance = "0";
			return this;
		}

		public GameSessionBalanceResp build() {
			return new GameSessionBalanceResp(this);
		}	
	}
}
