package tests.slotsservice.request;

import java.util.HashMap;
import java.util.Map;

public class QueueManualVoidReturnReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private QueueManualVoidReturnReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("transaction_type_id", builder.transaction_type_id);
		this.params.put("source_bet365_games_transaction_id", builder.source_bet365_games_transaction_id);
	}

	public static class Builder {
		private String method;
		private String id;
		private Integer transaction_type_id;
		private Integer source_bet365_games_transaction_id;

		public Builder transactionTypeId(Integer transaction_type_id) {
			this.transaction_type_id = transaction_type_id;
			return this;
		}

		public Builder sourceBet365GamesTransactionId(Integer source_bet365_games_transaction_id) {
			this.source_bet365_games_transaction_id = source_bet365_games_transaction_id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		public Builder defaults() {
			this.method  = "QueueManualVoidReturn";
			this.id = "1";
			return this;
		}

		public QueueManualVoidReturnReq build() {
			return new QueueManualVoidReturnReq(this);
		}
	}
}
