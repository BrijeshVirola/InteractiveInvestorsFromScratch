package tests.slotsservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetGameSessionReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Integer token_id;

	private Map<String, Object> params = new HashMap<>();

	private GetGameSessionReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("token_id", builder.token_id);
	}

	public static class Builder {
		private String method;
		private String id;
		private Integer token_id;

		public Builder tokenId(Integer token_id) {
			this.token_id = token_id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		public Builder defaults() {
			this.method  = "GetGameSession";
			this.id = "1";
			return this;
		}

		public GetGameSessionReq build() {
			return new GetGameSessionReq(this);
		}
	}
}
