package tests.slotsservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetActiveGameSessionReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Integer user_id;

	private Map<String, Object> params = new HashMap<>();

	private GetActiveGameSessionReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("user_id", builder.user_id);
	}

	public static class Builder {
		private String method;
		private String id;
		private Integer user_id;

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		public Builder defaults() {
			this.method  = "GetActiveGameSession";
			this.id = "1";
			return this;
		}

		public GetActiveGameSessionReq build() {
			return new GetActiveGameSessionReq(this);
		}
	}
}
