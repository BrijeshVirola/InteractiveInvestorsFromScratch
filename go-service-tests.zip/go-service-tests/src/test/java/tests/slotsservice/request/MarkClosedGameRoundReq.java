package tests.slotsservice.request;

import java.util.HashMap;
import java.util.Map;

public class MarkClosedGameRoundReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private MarkClosedGameRoundReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("game_round_id", builder.game_round_id);
	}

	public static class Builder {
		private String method;
		private String id;
		private Integer game_round_id;

		public Builder gameRoundId(Integer game_round_id) {
			this.game_round_id = game_round_id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		public Builder defaults() {
			this.method  = "MarkClosedGameRound";
			this.id = "1";
			return this;
		}

		public MarkClosedGameRoundReq build() {
			return new MarkClosedGameRoundReq(this);
		}
	}
}
