package tests.slotsservice.request;

import java.util.HashMap;
import java.util.Map;

public class HasOpenGameRoundsReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private HasOpenGameRoundsReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("game_session_id", builder.game_session_id);
	}

	public static class Builder {
		private String method;
		private String id;
		private String game_session_id;

		public Builder gameSessionId(String game_session_id) {
			this.game_session_id = game_session_id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		public Builder defaults() {
			this.method  = "HasOpenGameRounds";
			this.id = "1";
			return this;
		}

		public HasOpenGameRoundsReq build() {
			return new HasOpenGameRoundsReq(this);
		}
	}
}
