package tests.slotsservice.request;

import java.time.Instant;
import java.util.UUID;   

public class SlotsAdjustBalanceReq {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String method;
	public Params params;

	private SlotsAdjustBalanceReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params = new Params(builder);
	}

	public static class Builder {
		String id, method, bonus_game_type, token;
		Long bet365_games_transaction_id, game_round_id, bet365_transaction_id, flake_id, source_bet365_games_transaction_id;
		String game_session_id, partner_transaction_id;
		String real_amount, bonus_amount, total_amount, total_amount_gbp, currency_code, partner_timestamp_utc;
		String ring_fenced_amount;
		Integer provider_region_id, transaction_type_id, action_type_id, user_id, cmscore_game_id, regulated_game_id, partner_id, product_id, currency_id, user_bonus_id;
		Boolean is_new, allow_bonus, allow_ring_fenced;

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder bet365GamesTransactionId(Long bet365_games_transaction_id) {
			this.bet365_games_transaction_id = bet365_games_transaction_id;
			return this;
		}

		public Builder transactionTypeId(Integer transaction_type_id) {
			this.transaction_type_id = transaction_type_id;
			return this;
		}

		public Builder actionTypeId(Integer action_type_id) {
			this.action_type_id = action_type_id;
			return this;
		}

		public Builder gameSessionId(String game_session_id) {
			this.game_session_id = game_session_id;
			return this;
		}

		public Builder partnerTransactionId(String partner_transaction_id) {
			this.partner_transaction_id = partner_transaction_id;
			return this;
		}

		public Builder realAmount(String real_amount) {
			this.real_amount = real_amount;
			return this;
		}

		public Builder ringFencedAmount(String ring_fenced_amount) {
			this.ring_fenced_amount = ring_fenced_amount;
			return this;
		}

		public Builder bonusAmount(String bonus_amount) {
			this.bonus_amount = bonus_amount;
			return this;
		}

		public Builder totalAmount(String total_amount) {
			this.total_amount = total_amount;
			return this;
		}

		public Builder totalAmountGbp(String total_amount_gbp) {
			this.total_amount_gbp = total_amount_gbp;
			return this;
		}

		public Builder currencyCode(String currency_code) {
			this.currency_code = currency_code;
			return this;
		}

		public Builder partnerTimestampUtc(String partner_timestamp_utc) {
			this.partner_timestamp_utc = partner_timestamp_utc;
			return this;
		}

		public Builder gameRoundId(Long game_round_id) {
			this.game_round_id = game_round_id;
			return this;
		}

		public Builder bet365TransactionId(Long bet365_transaction_id) {
			this.bet365_transaction_id = bet365_transaction_id;
			return this;
		}

		public Builder providerRegionId(Integer provider_region_id) {
			this.provider_region_id = provider_region_id;
			return this;
		}

		public Builder bonusGameType(String bonus_game_type) {
			this.bonus_game_type = bonus_game_type;
			return this;
		}

		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}

		public Builder cmsCoreGameId(Integer cmscore_game_id) {
			this.cmscore_game_id = cmscore_game_id;
			return this;
		}

		public Builder regulatedGameId(Integer regulated_game_id) {
			this.regulated_game_id = regulated_game_id;
			return this;
		}

		public Builder partnerId(Integer partner_id) {
			this.partner_id = partner_id;
			return this;
		}

		public Builder productId(Integer product_id) {
			this.product_id = product_id;
			return this;
		}

		public Builder token(String token) {
			this.token = token;
			return this;
		}

		public Builder allowBonus(Boolean allow_bonus) {
			this.allow_bonus = allow_bonus;
			return this;
		}

		public Builder allowRingFenced(Boolean allow_ring_fenced) {
			this.allow_ring_fenced = allow_ring_fenced;
			return this;
		}

		public Builder currencyId(Integer currency_id) {
			this.currency_id = currency_id;
			return this;
		}

		public Builder flakeId(Long flake_id) {
			this.flake_id = flake_id;
			return this;
		}

		public Builder userBonusId(Integer user_bonus_id) {
			this.user_bonus_id = user_bonus_id;
			return this;
		}

		public Builder sourceBet365GamesTransactionId(Long source_bet365_games_transaction_id) {
			this.source_bet365_games_transaction_id = source_bet365_games_transaction_id;
			return this;
		}


		public Builder defaults() {
			this.id = "1";
			this.method = "AdjustBalance";
			this.flake_id = UUID.randomUUID().getMostSignificantBits() & Long.MAX_VALUE;
			this.real_amount = "-0.01";
			this.bonus_amount = "-0.01";
			this.ring_fenced_amount = "-0.01";
			this.total_amount = "-0.03";
			this.bonus_game_type = "G";
			this.user_id = 4419877;
			this.cmscore_game_id = 2885;
			this.regulated_game_id = 97998;
			this.transaction_type_id = 2;
			this.action_type_id = 1;
			this.partner_transaction_id = UUID.randomUUID().toString();
			this.partner_timestamp_utc = Instant.now().toString();
			this.partner_id = 154;
			this.game_round_id = 383998L;
			this.product_id = 19;
			this.token = "545b6038-112b-4123-bbb8-b6b44b5856e1";
			this.provider_region_id = 171;
			this.allow_bonus = true;
			this.allow_ring_fenced = true;
			this.currency_id = 17;
			this.bet365_transaction_id = UUID.randomUUID().getMostSignificantBits() & Long.MAX_VALUE;
			this.user_bonus_id = null;
			this.source_bet365_games_transaction_id = null;

			return this;
		}

		public SlotsAdjustBalanceReq build() {
			return new SlotsAdjustBalanceReq(this);
		}
	}

	public class Params {
		public Long flake_id;
		public Integer transaction_type_id;
		public Long game_round_id;
		public String game_session_id;
		public String partner_transaction_id;
		public String real_amount;
		public String bonus_amount;
		public String total_amount;
		public String partner_timestamp_utc;
		public Integer user_id;
		public Integer regulated_game_id;
		public Integer cmscore_game_id;
		public Integer partner_id;
		public Integer provider_region_id;
		public String token;
		public Integer action_type_id;
		public Long source_bet365_games_transaction_id;
		public Long bet365_games_transaction_id;
		public Boolean allow_bonus;
		public String bonus_game_type;
		public Integer currency_id;

		public Params(Builder builder) {
			this.flake_id = builder.flake_id;
			this.game_session_id = builder.game_session_id;
			this.real_amount = builder.real_amount;
			this.bonus_amount = builder.bonus_amount;
			this.total_amount = builder.total_amount;
			this.bonus_game_type = builder.bonus_game_type;
			this.user_id = builder.user_id;
			this.cmscore_game_id = builder.cmscore_game_id;
			this.regulated_game_id = builder.regulated_game_id;
			this.transaction_type_id = builder.transaction_type_id;
			this.partner_transaction_id = builder.partner_transaction_id;
			this.partner_timestamp_utc = builder.partner_timestamp_utc;
			this.partner_id = builder.partner_id;
			this.game_round_id = builder.game_round_id;
			this.token = builder.token;
			this.action_type_id = builder.action_type_id;
			this.provider_region_id = builder.provider_region_id;
			this.allow_bonus = builder.allow_bonus;
			this.currency_id = builder.currency_id;
			this.source_bet365_games_transaction_id = builder.source_bet365_games_transaction_id;
			this.bet365_games_transaction_id = builder.bet365_games_transaction_id;
		}
	}
}
