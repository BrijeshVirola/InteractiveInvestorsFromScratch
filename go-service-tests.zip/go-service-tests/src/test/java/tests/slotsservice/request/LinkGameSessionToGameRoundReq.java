package tests.slotsservice.request;

import java.util.HashMap;
import java.util.Map;

public class LinkGameSessionToGameRoundReq {

	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	private Map<String, Object> params = new HashMap<>();

	private LinkGameSessionToGameRoundReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params.put("game_round_id", builder.game_round_id);
		this.params.put("game_session_id", builder.game_session_id);
	}

	public static class Builder {
		private String method;
		private String id;
		private Integer game_round_id;
		private String game_session_id;

		public Builder gameRoundId(Integer game_round_id) {
			this.game_round_id = game_round_id;
			return this;
		}

		public Builder gameSessionId(String game_session_id) {
			this.game_session_id = game_session_id;
			return this;
		}

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		public Builder defaults() {
			this.method  = "LinkGameSessionToGameRound";
			this.id = "1";
			return this;
		}

		public LinkGameSessionToGameRoundReq build() {
			return new LinkGameSessionToGameRoundReq(this);
		}
	}
}
