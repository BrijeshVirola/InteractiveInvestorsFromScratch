package tests.slotsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.TransactionType;
import common.Utils;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.slotsservice.request.GetGameSessionBalanceReq;
import tests.slotsservice.request.SlotsAdjustBalanceReq;
import tests.slotsservice.response.GameSessionBalanceResp;
import tests.slotsservice.response.GetSlotsTransactionResp;
import tests.slotsservice.responseobjects.InsertTransaction;
public class AdjustBalanceTests extends BaseClassSetup {

	@Test(description = "Make a SLOTS_STAKE request to Adjust balance endpoint. Positive scenario.")
	public void valid_Slots_Stake_TransactionType_When_AdjustBalance_Then_TheExpectedTransactionIsReturned() {
		String stakeAmountNegative = "-0.03";
		String stakeAmountPositive = "0.03";
		String partnerTransactionId = UUID.randomUUID().toString();
		String partnerTimestampUtc = Instant.now().toString();
		Long gameRoundId = UUID.randomUUID().getMostSignificantBits() & Long.MAX_VALUE;

		// 1. Create new slots session
		String token = Utils.createNewSlotsSession("GO_SVC_SLOTS2", new BigDecimal("50.0"));
		String gameSessionId = Utils.getSlotsGameSessionId(UsersId.GO_SVC_SLOTS2);

		// 2. Get the initial slots session balance
		GetGameSessionBalanceReq getBalanceReq = new GetGameSessionBalanceReq.Builder()
				.defaults()
				.gameSessionId(gameSessionId)
				.build();

		GameSessionBalanceResp balanceResp = BaseRequest.getResponse(getBalanceReq, ResponseEndpoints.getGameSessionBalanceSuccess);
		BigDecimal initialSessionBalance = new BigDecimal(balanceResp.getBalance());

		// 3. Send SlotsStake request in order to play a game round
		SlotsAdjustBalanceReq request = new SlotsAdjustBalanceReq.Builder()
				.defaults()
				.userId(UsersId.GO_SVC_SLOTS2)
				.gameSessionId(gameSessionId)
				.transactionTypeId(TransactionType.SLOTS_STAKE.getValue())
				.gameRoundId(gameRoundId)
				.totalAmount(stakeAmountNegative)
				.partnerTransactionId(partnerTransactionId)
				.partnerTimestampUtc(partnerTimestampUtc)
				.token(token)
				.build();

		GetSlotsTransactionResp actResponse = BaseRequest.getResponse(request, ResponseEndpoints.slotsAdjustBalanceSuccess);

		// 4. Prepare the expected response object in order to validate the actual response
		GetSlotsTransactionResp expResponse = new GetSlotsTransactionResp.Builder()
				.defaults()
				.addTransaction(new InsertTransaction.Builder().
						defaults()
						.bet365GamesTransactionId(actResponse.getResult().getBet365GamesTransactionId())
						.transactionTypeId(TransactionType.SLOTS_STAKE.getValue())
						.partnerTimestampUtc(partnerTimestampUtc)
						.partnerTransactionId(partnerTransactionId)
						.totalAmount(stakeAmountNegative)
						.gameRoundId(gameRoundId)
						.build())
				.build();

		// 5. Validate the response of the SlotsStake request
		assertReflectionEquals(expResponse, actResponse);

		// 6. Get again the slots session balance and check that it's updated correctly
		GetGameSessionBalanceReq getBalanceAfterStakeReq = new GetGameSessionBalanceReq.Builder()
				.defaults()
				.gameSessionId(gameSessionId)
				.build();

		GameSessionBalanceResp actBalanceAfterStakeResp = BaseRequest.getResponse(getBalanceAfterStakeReq, ResponseEndpoints.getGameSessionBalanceSuccess);

		// 7. The new balance should be initialBalance - balanceAfterStake
		GameSessionBalanceResp expBalanceResponse =  new GameSessionBalanceResp.Builder()
				.defaults()
				.balance(initialSessionBalance.subtract(new BigDecimal(stakeAmountPositive)).stripTrailingZeros().toPlainString())
				.build();

		assertReflectionEquals(expBalanceResponse, actBalanceAfterStakeResp);
	}

}