package tests.slotsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.Utils;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import junit.framework.Assert;
import tests.slotsservice.request.GetActiveGameSessionReq;
import tests.slotsservice.response.GameSessionResp;

public class GetActiveGameSessionTests extends BaseClassSetup {

	@Test(description = "Make a request to GetActiveGameSession. Positive scenario.")
	public void getActiveGameSession_Positive_Scenario() {

		// Create new slots session
		Utils.createNewSlotsSession("GO_SVC_SLOTS1", new BigDecimal("50.0"));

		GetActiveGameSessionReq request = new GetActiveGameSessionReq.Builder()
				.defaults()
				.userId(UsersId.GO_SVC_SLOTS1)
				.build();

		GameSessionResp actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getActiveGameSessionSuccess);

		Assert.assertNotNull(actResponse.getGameSessionId());
		Assert.assertNotNull(actResponse.getSessionId());
		Assert.assertTrue(actResponse.getIsActive());
		Assert.assertNotNull(actResponse.getEndDateUtc());
		Assert.assertEquals(UsersId.GO_SVC_SLOTS1, actResponse.getUserId());
	}

	@Test(description = "Make a request to GetActiveGameSession. Game session not found.")
	public void getActiveGameSession_GameSession_Not_Found() {

		GetActiveGameSessionReq request = new GetActiveGameSessionReq.Builder()
				.defaults()
				.userId(UsersId.NOT_EXISTING)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getActiveGameSessionError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Game session not found")
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to GetActiveGameSession. Missing parameter.")
	public void getActiveGameSession_Missing_Parameter() {

		GetActiveGameSessionReq request = new GetActiveGameSessionReq.Builder()
				.defaults()
				.userId(null)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getActiveGameSessionError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to GetActiveGameSession. Wrong method.")
	public void getActiveGameSession_Wrong_Method() {

		GetActiveGameSessionReq request = new GetActiveGameSessionReq.Builder()
				.userId(UsersId.GO_SVC_SLOTS1)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getActiveGameSessionError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(4)
				.message("Invalid request")
				.id(null)
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}
}
