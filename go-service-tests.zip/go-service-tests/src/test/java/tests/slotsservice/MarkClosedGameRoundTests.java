package tests.slotsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.slotsservice.request.MarkClosedGameRoundReq;
import tests.slotsservice.response.ResultResp;

public class MarkClosedGameRoundTests extends BaseClassSetup {

	@Test(description = "Make a request to MarkClosedGameRound. Positive scenario.")
	public void markClosedGameRound_Positive_Scenario() {

		MarkClosedGameRoundReq request = new MarkClosedGameRoundReq.Builder()
				.defaults()
				.gameRoundId(1)
				.build();

		ResultResp actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.markClosedGameRoundSuccess);

		ResultResp expResponse = new ResultResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to MarkClosedGameRound. Missing parameter.")
	public void markClosedGameRound_Missing_Parameter() {

		MarkClosedGameRoundReq request = new MarkClosedGameRoundReq.Builder()
				.defaults()
				.gameRoundId(null)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.markClosedGameRoundError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: game_round_id")
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to MarkClosedGameRound. Wrong method.")
	public void markClosedGameRound_Wrong_Method() {

		MarkClosedGameRoundReq request = new MarkClosedGameRoundReq.Builder()
				.gameRoundId(1)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.markClosedGameRoundError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(4)
				.message("Invalid request")
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}
}
