package tests.slotsservice.responseobjects;

public class SelectTransaction {
	private Long bet365_games_transaction_id;
	@SuppressWarnings("unused")
	private Integer transaction_type_id;
	@SuppressWarnings("unused")
	private Integer action_type_id;
	@SuppressWarnings("unused")
	private String partner_transaction_id;
	@SuppressWarnings("unused")
	private String real_amount;
	@SuppressWarnings("unused")
	private String bonus_amount;
	@SuppressWarnings("unused")
	private String total_amount;
	@SuppressWarnings("unused")
	private String total_amount_gbp;
	@SuppressWarnings("unused")
	private String currency_code;
	@SuppressWarnings("unused")
	private String partner_timestamp_utc;
	@SuppressWarnings("unused")
	private Long game_round_id;
	@SuppressWarnings("unused")
	private Integer provider_region_id;
	@SuppressWarnings("unused")
	private Integer regulated_game_id;
	@SuppressWarnings("unused")
	private String user_token;
	@SuppressWarnings("unused")
	private Boolean is_new;

	private SelectTransaction(Builder builder) {
		this.bet365_games_transaction_id = builder.bet365_games_transaction_id;
		this.transaction_type_id = builder.transaction_type_id;
		this.action_type_id = builder.action_type_id;
		this.partner_transaction_id = builder.partner_transaction_id;
		this.real_amount = builder.real_amount;
		this.bonus_amount = builder.bonus_amount;
		this.total_amount = builder.total_amount;
		this.total_amount_gbp = builder.total_amount_gbp;
		this.currency_code = builder.currency_code;
		this.partner_timestamp_utc = builder.partner_timestamp_utc;
		this.game_round_id = builder.game_round_id;
		this.provider_region_id = builder.provider_region_id;
		this.regulated_game_id = builder.regulated_game_id;
		this.user_token = builder.user_token;
		this.is_new = builder.is_new;
	}

	public Long getBet365GamesTransactionId() {
		return bet365_games_transaction_id;
	}

	public static class Builder {
		private Long bet365_games_transaction_id;
		private Integer transaction_type_id;
		private Integer action_type_id;
		private String partner_transaction_id;
		private String real_amount;
		private String bonus_amount;
		private String total_amount;
		private String total_amount_gbp;
		private String currency_code;
		private String partner_timestamp_utc;
		private Long game_round_id;
		private Integer provider_region_id;
		private Integer regulated_game_id;
		private String user_token;
		private Boolean is_new;

		public Builder bet365GamesTransactionId(Long bet365_games_transaction_id) {
			this.bet365_games_transaction_id = bet365_games_transaction_id;
			return this;
		}

		public Builder transactionTypeId(Integer transaction_type_id) {
			this.transaction_type_id = transaction_type_id;
			return this;
		}

		public Builder actionTypeId(Integer action_type_id) {
			this.action_type_id = action_type_id;
			return this;
		}

		public Builder partnerTransactionId(String partner_transaction_id) {
			this.partner_transaction_id = partner_transaction_id;
			return this;
		}

		public Builder realAmount(String real_amount) {
			this.real_amount = real_amount;
			return this;
		}

		public Builder bonusAmount(String bonus_amount) {
			this.bonus_amount = bonus_amount;
			return this;
		}

		public Builder totalAmount(String total_amount) {
			this.total_amount = total_amount;
			return this;
		}

		public Builder totalAmountGBP(String total_amount_gbp) {
			this.total_amount_gbp = total_amount_gbp;
			return this;
		}

		public Builder currencyCode(String currency_code) {
			this.currency_code = currency_code;
			return this;
		}

		public Builder partnerTimestampUtc(String partner_timestamp_utc) {
			this.partner_timestamp_utc = partner_timestamp_utc;
			return this;
		}

		public Builder gameRoundId(Long game_round_id) {
			this.game_round_id = game_round_id;
			return this;
		}

		public Builder providerRegionId(Integer provider_region_id) {
			this.provider_region_id = provider_region_id;
			return this;
		}

		public Builder regulatedGameId(Integer regulated_game_id) {
			this.regulated_game_id = regulated_game_id;
			return this;
		}

		public Builder userToken(String user_token) {
			this.user_token = user_token;
			return this;
		}

		public Builder isNew(Boolean is_new) {
			this.is_new = is_new;
			return this;
		}

		public Builder defaults() {
			this.bet365_games_transaction_id = 2155976673L;
			this.transaction_type_id = 129;
			this.action_type_id = 1;
			this.partner_transaction_id = "0c7add80-faf1-4738-93cf-8e3cd4d06d10";
			this.real_amount = "-0.03";
			this.bonus_amount = "0";
			this.total_amount = "-0.03";
			this.total_amount_gbp = "-0.025";
			this.currency_code	= "EUR";
			this.partner_timestamp_utc = "2021-12-23T14:26:42.051Z";
			this.game_round_id = 231231255L;
			this.provider_region_id = 171;
			this.regulated_game_id = 97998;
			this.user_token = "52b75705-81d4-4b21-b093-de1728c8c24f";
			this.is_new = false;
			return this;
		}

		public SelectTransaction build() {
			return new SelectTransaction(this);
		}
	}
}

