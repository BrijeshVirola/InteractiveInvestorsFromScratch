package tests.slotsservice.responseobjects;

public class InsertTransaction {

	private Long bet365_games_transaction_id;
	@SuppressWarnings("unused")
	private Integer transaction_type_id;
	@SuppressWarnings("unused")
	private Integer action_type_id;
	@SuppressWarnings("unused")
	private String partner_transaction_id;
	@SuppressWarnings("unused")
	private String real_amount;
	@SuppressWarnings("unused")
	private String bonus_amount;
	@SuppressWarnings("unused")
	private String total_amount;
	@SuppressWarnings("unused")
	private String total_amount_gbp;
	@SuppressWarnings("unused")
	private String currency_code;
	@SuppressWarnings("unused")
	private String partner_timestamp_utc;
	@SuppressWarnings("unused")
	private Long game_round_id;
	@SuppressWarnings("unused")
	private Long bet365_transaction_id;
	@SuppressWarnings("unused")
	private Integer provider_region_id;
	@SuppressWarnings("unused")
	private Boolean is_new;

	private InsertTransaction(Builder builder) {
		this.bet365_games_transaction_id = builder.bet365_games_transaction_id;
		this.transaction_type_id = builder.transaction_type_id;
		this.action_type_id = builder.action_type_id;
		this.partner_transaction_id = builder.partner_transaction_id;
		this.real_amount = builder.real_amount;
		this.bonus_amount = builder.bonus_amount;
		this.total_amount = builder.total_amount;
		this.total_amount_gbp = builder.total_amount_gbp;
		this.currency_code = builder.currency_code;
		this.partner_timestamp_utc = builder.partner_timestamp_utc;
		this.game_round_id = builder.game_round_id;
		this.bet365_transaction_id = builder.bet365_transaction_id;
		this.provider_region_id = builder.provider_region_id;
		this.is_new = builder.is_new;
	}

	public Long getBet365GamesTransactionId() {
		return bet365_games_transaction_id;
	}

	public static class Builder {
		Long bet365_games_transaction_id, game_round_id, bet365_transaction_id;
		String partner_transaction_id;
		String real_amount, bonus_amount, total_amount, total_amount_gbp, currency_code, partner_timestamp_utc;
		Integer provider_region_id, transaction_type_id, action_type_id;
		Boolean is_new;

		public Builder bet365GamesTransactionId(Long bet365_games_transaction_id) {
			this.bet365_games_transaction_id = bet365_games_transaction_id;
			return this;
		}

		public Builder transactionTypeId(Integer transaction_type_id) {
			this.transaction_type_id = transaction_type_id;
			return this;
		}

		public Builder actionTypeId(Integer action_type_id) {
			this.action_type_id = action_type_id;
			return this;
		}

		public Builder partnerTransactionId(String partner_transaction_id) {
			this.partner_transaction_id = partner_transaction_id;
			return this;
		}

		public Builder realAmount(String real_amount) {
			this.real_amount = real_amount;
			return this;
		}

		public Builder bonusAmount(String bonus_amount) {
			this.bonus_amount = bonus_amount;
			return this;
		}

		public Builder totalAmount(String total_amount) {
			this.total_amount = total_amount;
			return this;
		}

		public Builder totalAmountGbp(String total_amount_gbp) {
			this.total_amount_gbp = total_amount_gbp;
			return this;
		}

		public Builder currencyCode(String currency_code) {
			this.currency_code = currency_code;
			return this;
		}

		public Builder partnerTimestampUtc(String partner_timestamp_utc) {
			this.partner_timestamp_utc = partner_timestamp_utc;
			return this;
		}

		public Builder gameRoundId(Long game_round_id) {
			this.game_round_id = game_round_id;
			return this;
		}

		public Builder bet365TransactionId(Long bet365_transaction_id) {
			this.bet365_transaction_id = bet365_transaction_id;
			return this;
		}

		public Builder providerRegionId(Integer provider_region_id) {
			this.provider_region_id = provider_region_id;
			return this;
		}

		public Builder isNew(Boolean is_new) {
			this.is_new = is_new;
			return this;
		}

		public Builder defaults() {
			this.bet365_games_transaction_id = 2157854833L;
			this.transaction_type_id = 129;
			this.action_type_id = 1;
			this.partner_transaction_id = "aeed400e-4ee5-41d5-b185-60912d0d5796";
			this.real_amount = "-0.03";
			this.bonus_amount = "0";
			this.total_amount = "-0.03";
			this.total_amount_gbp = "-0.025";
			this.currency_code = "EUR";
			this.partner_timestamp_utc = "2021-12-23T14:12:43.569Z";
			this.game_round_id = 12222222L;
			this.provider_region_id = 171;
			this.is_new = false;
			return this;
		}

		public InsertTransaction build() {
			return new InsertTransaction(this);
		}
	}
}