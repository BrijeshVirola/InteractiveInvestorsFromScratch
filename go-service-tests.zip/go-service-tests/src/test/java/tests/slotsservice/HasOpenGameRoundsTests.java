package tests.slotsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.Utils;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.slotsservice.request.HasOpenGameRoundsReq;
import tests.slotsservice.response.HasOpenGameRoundsResp;

public class HasOpenGameRoundsTests extends BaseClassSetup {

	@Test(description = "Make a request to HasOpenGameRounds. Positive scenario.")
	public void hasOpenGameRounds_Positive_Scenario() {
		BigDecimal slotsSessionBalance = new BigDecimal("50.0");

		// Create new slots session
		Utils.createNewSlotsSession("GO_SVC_SLOTS2", slotsSessionBalance);

		String gameSessionId = Utils.getSlotsGameSessionId(UsersId.GO_SVC_SLOTS2);

		HasOpenGameRoundsReq request = new HasOpenGameRoundsReq.Builder()
				.defaults()
				.gameSessionId(gameSessionId)
				.build();

		HasOpenGameRoundsResp actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.hasOpenGameRoundsSuccess);

		HasOpenGameRoundsResp expResponse =  new HasOpenGameRoundsResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to HasOpenGameRounds. Missing parameter.")
	public void hasOpenGameRounds_Missing_Parameter() {

		HasOpenGameRoundsReq request = new HasOpenGameRoundsReq.Builder()
				.defaults()
				.gameSessionId("Invalid")
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.hasOpenGameRoundsError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(4)
				.message("Invalid request")
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to HasOpenGameRounds. Wrong method.")
	public void hasOpenGameRounds_Wrong_Method() {

		String gameSessionId = Utils.getSlotsGameSessionId(UsersId.GO_SVC_SLOTS1);

		HasOpenGameRoundsReq request = new HasOpenGameRoundsReq.Builder()
				.defaults()
				.gameSessionId(gameSessionId)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.hasOpenGameRoundsError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(4)
				.message("Invalid request")
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}
}
