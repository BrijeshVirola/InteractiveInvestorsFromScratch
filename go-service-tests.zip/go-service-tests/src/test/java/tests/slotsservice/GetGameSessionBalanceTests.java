package tests.slotsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.Utils;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.slotsservice.request.GetGameSessionBalanceReq;
import tests.slotsservice.response.GameSessionBalanceResp;

public class GetGameSessionBalanceTests extends BaseClassSetup {

	@Test(description = "Make a request to GetGameSessionBalance. Positive scenario.")
	public void getGameSessionBalance_Positive_Scenario() {
		BigDecimal slotsSessionBalance = new BigDecimal("50.0");

		// Create new slots session
		Utils.createNewSlotsSession("GO_SVC_SLOTS1", slotsSessionBalance);

		String gameSessionId = Utils.getSlotsGameSessionId(UsersId.GO_SVC_SLOTS1);

		GetGameSessionBalanceReq request = new GetGameSessionBalanceReq.Builder()
				.defaults()
				.gameSessionId(gameSessionId)
				.build();

		GameSessionBalanceResp actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getGameSessionBalanceSuccess);

		GameSessionBalanceResp expResponse =  new GameSessionBalanceResp.Builder()
				.defaults()
				.balance(slotsSessionBalance.stripTrailingZeros().toPlainString())
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to GetGameSessionBalance. Game session not found.")
	public void getGameSessionBalance_GameSession_Not_Found() {

		GetGameSessionBalanceReq request = new GetGameSessionBalanceReq.Builder()
				.defaults()
				.gameSessionId("671b0911-8c35-44a2-9890-babc2a47c147")
				.build();

		GameSessionBalanceResp actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getGameSessionBalanceSuccess);

		GameSessionBalanceResp expResponse =  new GameSessionBalanceResp.Builder()
				.defaults()
				.balance("0")
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to GetGameSessionBalance. Missing parameter.")
	public void getGameSessionBalance_Missing_Parameter() {

		GetGameSessionBalanceReq request = new GetGameSessionBalanceReq.Builder()
				.defaults()
				.gameSessionId(null)
				.build();

		GameSessionBalanceResp actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getGameSessionBalanceSuccess);

		GameSessionBalanceResp expResponse =  new GameSessionBalanceResp.Builder()
				.defaults()
				.balance("0")
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to GetGameSessionBalance. Wrong method.")
	public void getGameSessionBalance_Wrong_Method() {

		String gameSessionId = Utils.getSlotsGameSessionId(UsersId.GO_SVC_SLOTS1);

		GetGameSessionBalanceReq request = new GetGameSessionBalanceReq.Builder()
				.defaults()
				.gameSessionId(gameSessionId)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getGameSessionBalanceError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(4)
				.message("Invalid request")
				.id(null)
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}
}
