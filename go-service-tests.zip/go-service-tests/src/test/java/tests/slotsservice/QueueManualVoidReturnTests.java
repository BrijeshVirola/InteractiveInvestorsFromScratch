package tests.slotsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.Utils;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.slotsservice.request.QueueManualVoidReturnReq;
import tests.slotsservice.response.ResultResp;

public class QueueManualVoidReturnTests extends BaseClassSetup {

	// Once the slots return request is ready - enable this test and refactor it
	@Test(enabled = false, description = "Make a request to QueueManualVoidReturn. Positive scenario.")
	public void queueManualVoidReturn_Positive_Scenario() {

		// Create new slots session
		Utils.createNewSlotsSession("GO_SVC_SLOTS2", new BigDecimal("50.0"));

		QueueManualVoidReturnReq request = new QueueManualVoidReturnReq.Builder()
				.defaults()
				.transactionTypeId(130)
				.sourceBet365GamesTransactionId(1212121)
				.build();

		ResultResp actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.slotsQueueManualVoidReturnSuccess);

		ResultResp expResponse = new ResultResp.Builder()
				.defaults()
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to QueueManualVoidReturn. Invalid request.")
	public void queueManualVoidReturn_Invalid_Transaction_Type() {

		QueueManualVoidReturnReq request = new QueueManualVoidReturnReq.Builder()
				.defaults()
				.transactionTypeId(22222)
				.sourceBet365GamesTransactionId(1212121)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.slotsQueueManualVoidReturnError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(1003)
				.message("Invalid transaction type")
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to QueueManualVoidReturn. Missing parameter.")
	public void queueManualVoidReturn_Missing_Parameter() {

		QueueManualVoidReturnReq request = new QueueManualVoidReturnReq.Builder()
				.defaults()
				.transactionTypeId(null)
				.sourceBet365GamesTransactionId(1212121)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.slotsQueueManualVoidReturnError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: transaction_type_id")
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to QueueManualVoidReturn. Wrong method.")
	public void queueManualVoidReturn_Wrong_Method() {

		QueueManualVoidReturnReq request = new QueueManualVoidReturnReq.Builder()
				.transactionTypeId(null)
				.sourceBet365GamesTransactionId(1212121)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.slotsQueueManualVoidReturnError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(4)
				.message("Invalid request")
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}
}
