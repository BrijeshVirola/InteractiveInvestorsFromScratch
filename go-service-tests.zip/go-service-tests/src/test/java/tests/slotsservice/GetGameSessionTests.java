package tests.slotsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigDecimal;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DatabaseQueries;
import common.Utils;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import junit.framework.Assert;
import tests.slotsservice.request.GetGameSessionReq;
import tests.slotsservice.response.GameSessionResp;

public class GetGameSessionTests extends BaseClassSetup {

	@Test(description = "Make a request to GetGameSession. Positive scenario.")
	public void getGameSession_Positive_Scenario() {

		// Create new slots session
		Utils.createNewSlotsSession("GO_SVC_SLOTS1", new BigDecimal("50.0"));

		String gameSessionId = Utils.getSlotsGameSessionId(UsersId.GO_SVC_SLOTS1);

		// Get sakuraTokenSno value from the DB associated with the gameSessionId
		Integer sakuraTokenSno = DatabaseQueries.getSakuraTokenSNOByGameSessionId(gameSessionId);

		GetGameSessionReq request = new GetGameSessionReq.Builder()
				.defaults()
				.tokenId(sakuraTokenSno)
				.build();

		GameSessionResp actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getGameSessionSuccess);

		Assert.assertEquals(gameSessionId, actResponse.getGameSessionId());
		Assert.assertNotNull(actResponse.getSessionId());
		Assert.assertTrue(actResponse.getIsActive());
		Assert.assertNotNull(actResponse.getEndDateUtc());
		Assert.assertEquals(UsersId.GO_SVC_SLOTS1, actResponse.getUserId());
	}

	@Test(description = "Make a request to GetGameSession. Game session not found.")
	public void getGameSession_GameSession_Not_Found() {

		GetGameSessionReq request = new GetGameSessionReq.Builder()
				.defaults()
				.tokenId(1234567890)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getGameSessionError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Game session not found")
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to GetGameSession. Missing parameter.")
	public void getGameSession_Missing_Parameter() {

		GetGameSessionReq request = new GetGameSessionReq.Builder()
				.defaults()
				.tokenId(null)
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getGameSessionError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: token_id")
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Make a request to GetGameSession. Wrong method.")
	public void getGameSession_Wrong_Method() {

		GetGameSessionReq request = new GetGameSessionReq.Builder()
				.tokenId(1234567890)
				.method("INVALID_METHOD_NAME")
				.build();

		CustomErrorResponse actResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getGameSessionError);

		CustomErrorResponse expResponse = new CustomErrorResponse.Builder()
				.code(4)
				.message("Invalid request")
				.id(null)
				.build();

		assertReflectionEquals(expResponse, actResponse);
	}
}
