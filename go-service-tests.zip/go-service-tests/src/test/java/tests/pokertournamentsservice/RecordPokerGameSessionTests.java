package tests.pokertournamentsservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.Assert;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.DatabaseQueries;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.common.response.ResultOKResp;
import tests.pokertournamentsservice.request.PokerGameSessionDB;
import tests.pokertournamentsservice.request.RecordPokerGameSessionReq;
public class RecordPokerGameSessionTests extends BaseClassSetup{
	
	@Test(description = "Make a request to RecordPokerGameSession. Positive scenario.")
	public void recordPokerGameSession_Positive_Scenario() throws InterruptedException {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		RecordPokerGameSessionReq request = new RecordPokerGameSessionReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		
		ResultOKResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.recordPokerGameSessionSuccess);

		ResultOKResp expectedResponse = new ResultOKResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
		
		PokerGameSessionDB dbData = DatabaseQueries.getPokerGameSession(request.getGameRoundSno());
		
		Assert.assertEquals(dbData.getCasino(), request.getCasino());
		Assert.assertEquals(dbData.getClientPlatform(), request.getClientPlatform());
		Assert.assertEquals(dbData.getClientType(), request.getClientType());
		Assert.assertEquals(dbData.getGameType(), request.getGameType()); 
		Assert.assertEquals(dbData.getGameRoundSno(), request.getGameRoundSno());
		Assert.assertEquals(dbData.getRakeAmount(), request.getRakeAmount());
	}
	
	@Test(description = "Make a request to recordPokerGameSession. Missing game_round_sno parameter.")
	public void recordPokerGameSession_MissingFeeAmount_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		RecordPokerGameSessionReq request = new RecordPokerGameSessionReq.Builder()
										.defaults()
										.gameRoundSno(null)
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
										
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.recordPokerGameSessionError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: game_round_sno")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to recordPokerGameSession. Wrong method.")
	public void recordPokerGameSession_Wrong_Method() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		RecordPokerGameSessionReq request = new RecordPokerGameSessionReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.method("INVALID_METHOD_NAME")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.recordPokerGameSessionError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(6)
				.message("Incorrect method in request")
				.id(null)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to recordPokerGameSession. client_type field too long.")
	public void recordPokerGameSession_clientType_maxLength_test() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		RecordPokerGameSessionReq request = new RecordPokerGameSessionReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.clientType("THIS_SENTENCE_IN_TOTAL_IS_ONE_CHARACTER_LONGER_THAN_THE_MAXIMUM_ALLOWABLE_FIELD_LENGTH_OF_ONE_HUNDRED")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.recordPokerGameSessionError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Invalid parameter: client_type")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to recordPokerGameSession. client_platform field too long.")
	public void recordPokerGameSession_clientPlatform_maxLength_test() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		RecordPokerGameSessionReq request = new RecordPokerGameSessionReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.clientPlatform("THIS_SENTENCE_IN_TOTAL_IS_ONE_CHARACTER_LONGER_THAN_THE_MAXIMUM_ALLOWABLE_FIELD_LENGTH_OF_ONE_HUNDRED")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.recordPokerGameSessionError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Invalid parameter: client_platform")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to recordPokerGameSession. game_type field too long.")
	public void recordPokerGameSession_gameType_maxLength_test() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		RecordPokerGameSessionReq request = new RecordPokerGameSessionReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.gameType("THIS_SENTENCE_IN_TOTAL_IS_ONE_CHARACTER_LONGER_THAN_THE_MAXIMUM_ALLOWABLE_FIELD_LENGTH_OF_ONE_HUNDRED")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.recordPokerGameSessionError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Invalid parameter: game_type")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to recordPokerGameSession. casino field too long.")
	public void recordPokerGameSession_casino_maxLength_test() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		RecordPokerGameSessionReq request = new RecordPokerGameSessionReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.casino("ONE_CHAR_LONGER_THAN_THE_MAX_PERMITTED_LENGTH_OF_50")
										.build();
		
		CustomErrorResponse actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.recordPokerGameSessionError);
		
		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
				.code(1002)
				.message("Invalid parameter: casino")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
