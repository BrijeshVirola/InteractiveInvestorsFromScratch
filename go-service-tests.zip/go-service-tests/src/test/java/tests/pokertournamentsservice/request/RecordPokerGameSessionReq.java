package tests.pokertournamentsservice.request;

import java.util.UUID;   

public class RecordPokerGameSessionReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;

	Params params;

	private RecordPokerGameSessionReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params = new Params(builder);
	}
	
	public Long getGameRoundSno() {
		return params.game_round_sno;
	}

	public String getClientType() {
		return params.client_type;
	}
	
	public String getCasino() {
		return params.casino;
	}
	
	public String getClientPlatform() {
		return params.client_platform;
	}
	
	public String getGameType() {
		return params.game_type;
	}
	
	public Double getRakeAmount() {
		return params.rake_amount;
	}
	
	public static class Builder {
		private String method, id, client_type, client_platform, game_type, casino;
		private Long game_round_sno;
		private Double rake_amount;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder gameRoundSno(Long game_round_sno) {
			this.game_round_sno = game_round_sno;
			return this;
		}
		
		public Builder clientType(String client_type) {
			this.client_type = client_type;
			return this;
		}

		public Builder clientPlatform(String client_platform) {
			this.client_platform = client_platform;
			return this;
		}

		public Builder gameType(String game_type) {
			this.game_type = game_type;
			return this;
		}
		
		public Builder casino(String casino) {
			this.casino = casino;
			return this;
		}

		public Builder rakeAmount(Double rake_amount) {
			this.rake_amount = rake_amount;
			return this;
		}
		
		public Builder defaults() {
			this.method = "recordpokergamesession";
			this.id = "1";
			this.game_round_sno = UUID.randomUUID().getMostSignificantBits() & Long.MAX_VALUE;
			this.client_type = "casino";
		    this.client_platform = "flash";
		    this.game_type = "bfb";
		    this.casino = "ptstaging2.152";
		    this.rake_amount = 10.01;
			return this;
		}

		public RecordPokerGameSessionReq build() {
			return new RecordPokerGameSessionReq(this);
		}
	}
	
	private class Params {

		String client_type;
		String client_platform;
		String game_type;
		String casino;
		Long game_round_sno;
		Double rake_amount;

		public Params(Builder builder) {
			this.client_type = builder.client_type;
			this.client_platform = builder.client_platform;
			this.game_type = builder.game_type;
			this.casino = builder.casino;
			this.game_round_sno = builder.game_round_sno;
			this.rake_amount = builder.rake_amount;
		}
	}
}

