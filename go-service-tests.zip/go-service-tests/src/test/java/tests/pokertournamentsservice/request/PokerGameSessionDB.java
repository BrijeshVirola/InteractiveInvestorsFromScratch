package tests.pokertournamentsservice.request;

public class PokerGameSessionDB {
	private Long game_round_sno;
	private String client_type;
	private String client_platform;
	private String game_type;
	private String casino;
	private Double rake_amount;
	
	public void setGameRoundSno(Long game_round_sno) {
		this.game_round_sno = game_round_sno;
	}
	
	public void setClientType(String client_type) {
		this.client_type = client_type;
	}
	
	public void setClientPlatform(String client_platform) {
		this.client_platform = client_platform;
	}
	
	public void setGameType(String game_type) {
		this.game_type = game_type;
	}
	
	public void setCasino(String casino) {
		this.casino = casino;
	}
	
	public void setRakeAmount(Double rake_amount) {
		this.rake_amount = rake_amount;
	}
	
	public Long getGameRoundSno() {
		return game_round_sno;
	}
	
	public String getClientType() {
		return client_type;
	}
	
	public String getClientPlatform() {
		return client_platform;
	}
	
	public String getGameType() {
		return game_type;
	}
	
	public String getCasino() {
		return casino;
	}
	
	public Double getRakeAmount() {
		return rake_amount;
	}
}