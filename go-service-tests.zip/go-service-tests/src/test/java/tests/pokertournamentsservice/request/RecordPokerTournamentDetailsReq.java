package tests.pokertournamentsservice.request;

import java.util.UUID;

public class RecordPokerTournamentDetailsReq {
	
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	Params params;

	private RecordPokerTournamentDetailsReq(Builder builder) {
		this.id = builder.id;
		this.method = builder.method;
		this.params = new Params(builder);
	}

	public Long getTransactionFlakeId() {
		return params.transaction_flake_id;
	}
	
	public String getTournamentId() {
		return params.tournament_id;
	}
	
	public Double getFeeAmount() {
		return params.fee_amount;
	}
	
	public Double getDisplayAmount() {
		return params.display_amount;
	}
	
	public Integer getFeeCurrencyId() {
		return params.fee_currency_id;
	}
	
	public Integer getDisplayCurrencyId() {
		return params.display_currency_id;
	}
	
	public static class Builder {
		private String method, id, tournament_id;
		private Long transaction_flake_id;
		private Integer fee_currency_id, display_currency_id;
		private Double fee_amount, display_amount;

		public Builder method(String method) {
			this.method = method;
			return this;
		}

		public Builder id(String id) {
			this.id = id;
			return this;
		}

		public Builder transactionFlakeId(Long transaction_flake_id) {
			this.transaction_flake_id = transaction_flake_id;
			return this;
		}
		
		public Builder tournamentId(String tournament_id) {
			this.tournament_id = tournament_id;
			return this;
		}

		public Builder feeAmount(Double fee_amount) {
			this.fee_amount = fee_amount;
			return this;
		}

		public Builder feeCurrencyId(Integer fee_currency_id) {
			this.fee_currency_id = fee_currency_id;
			return this;
		}
		
		public Builder displayAmount(Double display_amount) {
			this.display_amount = display_amount;
			return this;
		}

		public Builder displayCurrencyId(Integer display_currency_id) {
			this.display_currency_id = display_currency_id;
			return this;
		}
		
		public Builder defaults() {
			this.method = "recordpokertournamentdetails";
			this.id = "1";
			this.transaction_flake_id = UUID.randomUUID().getMostSignificantBits() & Long.MAX_VALUE;
			this.tournament_id = "12345";
			this.fee_amount = 3.50;
			this.fee_currency_id = 1;
			this.display_amount = 3.50;
			this.display_currency_id = 1;
			return this;
		}

		public RecordPokerTournamentDetailsReq build() {
			return new RecordPokerTournamentDetailsReq(this);
		}
	}
	
	private class Params {

		Double fee_amount, display_amount;
		Long transaction_flake_id;
		Integer fee_currency_id;
		Integer display_currency_id;
		String tournament_id;

		public Params(Builder builder) {
			this.fee_amount = builder.fee_amount;
			this.display_amount = builder.display_amount;
			this.transaction_flake_id = builder.transaction_flake_id;
			this.fee_currency_id = builder.fee_currency_id;
			this.display_currency_id = builder.display_currency_id;
			this.tournament_id = builder.tournament_id;
		}
	}
}

