package tests.userservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.userservice.request.GetUsersAffiliateCodeReq;
import tests.userservice.response.GetUsersAffiliateCodeResp;

public class GetUsersAffiliateCodeTests extends BaseClassSetup {

	@Test(description = "Make a request to getUsersAffiliateCode. Positive default scenario.")
	public void getUsersAffiliateCode_Positive_Default_Scenario() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetUsersAffiliateCodeResp expectedResponse = new GetUsersAffiliateCodeResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.build();

		GetUsersAffiliateCodeReq requestBody = new GetUsersAffiliateCodeReq.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId)
											.build();
		
		GetUsersAffiliateCodeResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getUsersAffiliateCodeSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to GetUsersAffiliateCode with invalid method.")
	public void getUsersAffiliateCode_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		GetUsersAffiliateCodeReq requestBody = new GetUsersAffiliateCodeReq.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();

		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getUsersAffiliateCodeError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getUsersAffiliateCode with missing parameter user.")
	public void getUsersAffiliateCode_Missing_UserId() {
		
		String id = UUID.randomUUID().toString();

		GetUsersAffiliateCodeReq requestBody = new GetUsersAffiliateCodeReq.Builder()
				.defaults()
				.userId(null)
				.id(id)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getUsersAffiliateCodeError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder().code(7)
				.message("Missing parameter: user_id").id(id).build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getUsersAffiliateCode unknown user_id")
	public void getUsersAffiliateCode_Unknown_UserId() {
		
		String id = UUID.randomUUID().toString();

		GetUsersAffiliateCodeReq requestBody = new GetUsersAffiliateCodeReq.Builder()
				.defaults()
				.userId(999)
				.id(id)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getUsersAffiliateCodeError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder().code(1001).message("User not found").id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}
