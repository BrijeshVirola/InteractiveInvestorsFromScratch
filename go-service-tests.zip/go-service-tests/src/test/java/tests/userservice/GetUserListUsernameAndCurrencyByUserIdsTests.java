package tests.userservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.ExpectedFailure;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.userservice.request.GetUserListUsernameAndCurrencyByUserIdsReq;
import tests.userservice.response.GetUserListUsernameAndCurrencyByUserIdsResp;
import tests.userservice.responseobjects.GetUserUsernameAndCurrency;

public class GetUserListUsernameAndCurrencyByUserIdsTests extends BaseClassSetup {
	
	@ExpectedFailure(jiraRef="https://jira/browse/PRJSAK-2214", action="disabled test")
	@Test(enabled=false, description = "Make a request to getUserListUsernameAndCurrencyByUserIds with multiple users.")
	public void getUserListUsernameAndCurrencyByUserIds_Multiple_Users() {
		
		String id = UUID.randomUUID().toString();
		int userid1 = 4622042;
		int userid2 = 2403054;
		
		GetUserUsernameAndCurrency expUser1 = new GetUserUsernameAndCurrency
				.Builder()
				.defaults()
				.userId(userid1)
				.username("go_svc_tests06")
				.currencyId(1)
				.build();
		
		GetUserUsernameAndCurrency expUser2 = new GetUserUsernameAndCurrency
				.Builder()
				.defaults()
				.userId(userid2)
				.username("vzuat5es")
				.currencyId(17)
				.build();
		
		GetUserListUsernameAndCurrencyByUserIdsResp expectedResponse =  new GetUserListUsernameAndCurrencyByUserIdsResp
				.Builder()
				.defaults()
				.id(id)
				.addUser(expUser1)
				.addUser(expUser2)
				.build();
		
		GetUserListUsernameAndCurrencyByUserIdsReq requestBody = new GetUserListUsernameAndCurrencyByUserIdsReq
				.Builder()
				.defaults()
				.id(id)
				.addUserId(userid1)
				.addUserId(userid2)
				.build();
		GetUserListUsernameAndCurrencyByUserIdsResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserListUsernameAndCurrencyByUserIdsSuccess);
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@ExpectedFailure(jiraRef="https://jira/browse/PRJSAK-2214", action="disabled test")
	@Test(enabled=false, description = "Make a request to getUserListUsernameAndCurrencyByUserIds with one user.")
	public void getUserListUsernameAndCurrencyByUserIds_One_User() {
		
		String id = UUID.randomUUID().toString();
		int userid = 2349500;
		
		GetUserUsernameAndCurrency expUser = new GetUserUsernameAndCurrency
				.Builder()
				.defaults()
				.userId(userid)
				.username("vzuat1ireland")
				.currencyId(17)
				.build();
		
		GetUserListUsernameAndCurrencyByUserIdsResp expectedResponse =  new GetUserListUsernameAndCurrencyByUserIdsResp
				.Builder()
				.defaults()
				.id(id)
				.addUser(expUser)
				.build();
		
		GetUserListUsernameAndCurrencyByUserIdsReq requestBody = new GetUserListUsernameAndCurrencyByUserIdsReq
				.Builder()
				.defaults()
				.id(id)
				.addUserId(userid)
				.build();
		GetUserListUsernameAndCurrencyByUserIdsResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserListUsernameAndCurrencyByUserIdsSuccess);
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to GetUserListUsernameAndCurrencyByUserIds with invalid method.")
	public void getUserListUsernameAndCurrencyByUserIds_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		GetUserListUsernameAndCurrencyByUserIdsReq requestBody = new GetUserListUsernameAndCurrencyByUserIdsReq
				.Builder()
				.defaults()
				.method("INVALID_METHOD")
				.id(id)
				.addUserId(4622042)
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserListUsernameAndCurrencyByUserIdsError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to getUserListUsernameAndCurrencyByUserIds with missing parameter user_ids.")
	public void getUserListUsernameAndCurrencyByUserIds_Missing_UserIds() {
		
		String id = UUID.randomUUID().toString();
		
		GetUserListUsernameAndCurrencyByUserIdsReq requestBody = new GetUserListUsernameAndCurrencyByUserIdsReq
				.Builder()
				.defaults()
				.userIds(null)
				.id(id)
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserListUsernameAndCurrencyByUserIdsError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(7)
												.message("Missing parameter: user_ids")
												.id(id)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	
	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2214", action="test disabled")
	@Test(enabled=false, description = "Make a request to getUserListUsernameAndCurrencyByUserIds with not existing user id.")
	public void getUserListUsernameAndCurrencyByUserIds_Not_Existing_UserIds() {
		
		List<GetUserUsernameAndCurrency> emptyList = new ArrayList<GetUserUsernameAndCurrency>();
		String id = UUID.randomUUID().toString();
		
		GetUserListUsernameAndCurrencyByUserIdsResp expectedResponse =  new GetUserListUsernameAndCurrencyByUserIdsResp
				.Builder()
				.defaults()
				.id(id)
				.result(emptyList)
				.build();
		
		GetUserListUsernameAndCurrencyByUserIdsReq requestBody = new GetUserListUsernameAndCurrencyByUserIdsReq
				.Builder()
				.defaults()
				.addUserId(UsersId.NOT_EXISTING)
				.id(id)
				.build();
		
		GetUserListUsernameAndCurrencyByUserIdsResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserListUsernameAndCurrencyByUserIdsSuccess);
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}

}
