package tests.userservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.ExpectedFailure;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.userservice.request.GetUserHasTransferredToGamingWalletReq;
import tests.userservice.response.GetUserHasTransferredToGamingWalletResp;

public class GetUserHasTransferredToGamingWalletTests extends BaseClassSetup {

	@Test(description = "Make a request to getUserHasTransferredToGamingWallet. Positive default scenario.")
	public void getUserHasTransferredToGamingWallet_Positive_Default_Scenario() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetUserHasTransferredToGamingWalletResp expectedResponse = new GetUserHasTransferredToGamingWalletResp.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId)
											.build();

		GetUserHasTransferredToGamingWalletReq requestBody = new GetUserHasTransferredToGamingWalletReq.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId)
											.build();
		
		GetUserHasTransferredToGamingWalletResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserHasTransferredToGamingWalletSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to GetUserHasTransferredToGamingWallet with invalid method.")
	public void getUserHasTransferredToGamingWallet_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		GetUserHasTransferredToGamingWalletReq requestBody = new GetUserHasTransferredToGamingWalletReq.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserHasTransferredToGamingWalletError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getUserHasTransferredToGamingWallet with missing user_id.")
	public void getUserHasTransferredToGamingWallet_Missing_UserId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetUserHasTransferredToGamingWalletReq requestBody = new GetUserHasTransferredToGamingWalletReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserHasTransferredToGamingWalletError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2215", action="test disabled")
	@Test(enabled=false, description = "Make a request to getUserHasTransferredToGamingWallet unknown user_id.")
	public void getUserHasTransferredToGamingWallet_Unknown_UserId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetUserHasTransferredToGamingWalletReq requestBody = new GetUserHasTransferredToGamingWalletReq.Builder()
				.defaults()
				.userId(UsersId.NOT_EXISTING)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserHasTransferredToGamingWalletError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1001)
				.message("User not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

}
