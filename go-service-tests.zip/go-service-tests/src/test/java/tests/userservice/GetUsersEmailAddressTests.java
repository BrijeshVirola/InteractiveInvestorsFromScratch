package tests.userservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.userservice.request.GetUsersEmailAddressReq;
import tests.userservice.response.GetUsersEmailAddressResp;

public class GetUsersEmailAddressTests extends BaseClassSetup {

	@Test(description = "Make a request to getUsersEmailAddress. Positive default scenario.")
	public void getUsersEmailAddress_Positive_Default_Scenario() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetUsersEmailAddressResp expectedResponse = new GetUsersEmailAddressResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.build();

		GetUsersEmailAddressReq requestBody = new GetUsersEmailAddressReq.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId)
											.build();
		
		GetUsersEmailAddressResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getUsersEmailAddressSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to GetUsersEmailAddress with invalid method.")
	public void getUsersEmailAddress_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		GetUsersEmailAddressReq requestBody = new GetUsersEmailAddressReq.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getUsersEmailAddressError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getUsersEmailAddress with missing parameter user.")
	public void getUsersEmailAddress_Missing_UserId() {
		
		String id = UUID.randomUUID().toString();

		GetUsersEmailAddressReq requestBody = new GetUsersEmailAddressReq.Builder()
				.defaults()
				.id(id)
				.userId(null)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getUsersEmailAddressError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder().code(7).id(id)
				.message("Missing parameter: user_id").build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getUsersEmailAddress unknown user_id")
	public void getUsersEmailAddress_Unknown_UserId() {
		
		String id = UUID.randomUUID().toString();

		GetUsersEmailAddressReq requestBody = new GetUsersEmailAddressReq.Builder()
				.defaults()
				.id(id)
				.userId(999)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getUsersEmailAddressError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder().code(1001).message("User not found").id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}
