package tests.userservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.userservice.request.GetCoreDataByUserIdReq;
import tests.userservice.response.GetCoreDataResp;
import tests.userservice.responseobjects.GetCoreDataResult;

public class GetCoreDataByUserIdTests extends BaseClassSetup {
	
	@DataProvider(name = "getCoreDataByUserId")
	//id, userId, username, gamingId, country_id, country_state_id, language_id, currency_id,
	//currency_code, timezone_id, has_transferred_to_gaming_wallet
	//
	private Object[][] getCoreDataByUserId() {
		return new Object[][] {
			{"testId123", 4622042, "go_svc_tests06", "CCFE4339FF1961", 197, 0, 1, "GBP", 1},
			{"55425", 2403054, "vzuat5es", "105D5672FB8C7B", 171, 0, 17, "EUR", 4},
			{"test1@", 2349500, "vzuat1ireland", "FB82C182E3B59B", 95, 166,17, "EUR", 1}
			};
	}
	
	@Test(description = "Make a request to getCoreDataByUserId. Positive default scenario.", 
			dataProvider = "getCoreDataByUserId")
	public void getCoreDataByUserId_Positive_Scenario(String id, Integer userId, String username, String gamingId, Integer country_id,
			Integer country_state_id, Integer currency_id,
			String currency_code, Integer timezone_id) {
		
		GetCoreDataResult expectedResult = new GetCoreDataResult.ResultBuilder()
				.defaults()
				.userId(userId)
				.username(username)
				.gamingId(gamingId)
				.countryId(country_id)
				.countryStateId(country_state_id)
				.currencyId(currency_id)
				.currencyCode(currency_code)
				.timeZoneId(timezone_id)
				.build();
		GetCoreDataResp expectedResponse =  new GetCoreDataResp(id, expectedResult);
		
		GetCoreDataByUserIdReq requestBody = new GetCoreDataByUserIdReq(id, userId);
		GetCoreDataResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getCoreDataByUserIdSuccess);
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to getCoreDataByUserId with invalid method.")
	public void getCoreDataByUserId_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		GetCoreDataByUserIdReq requestBody = new GetCoreDataByUserIdReq(id, 4622042);
		requestBody.setMethod("INVALID_METHOD");
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getCoreDataByUserIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to getCoreDataByUserId with missing parameter user id.")
	public void getCoreDataByUserId_Missing_UserId() {
		
		String id = UUID.randomUUID().toString();
		
		GetCoreDataByUserIdReq requestBody = new GetCoreDataByUserIdReq(id, null);
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getCoreDataByUserIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(7)
												.message("Missing parameter: user_id")
												.id(id)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to getCoreDataByUserId with not existing user id.")
	public void getCoreDataByUserId_Not_Existing_User() {
		
		String id = UUID.randomUUID().toString();
		
		GetCoreDataByUserIdReq requestBody = new GetCoreDataByUserIdReq(id, 1);
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getCoreDataByUserIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(1001)
												.message("User not found")
												.id(id)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
}
