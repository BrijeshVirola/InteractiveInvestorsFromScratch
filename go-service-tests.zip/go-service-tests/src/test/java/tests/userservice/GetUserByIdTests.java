package tests.userservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.userservice.request.GetUserByIdReq;
import tests.userservice.response.GetUserResp;
import tests.userservice.responseobjects.GetUserResult;

public class GetUserByIdTests extends BaseClassSetup {

	@Test(description = "Make a request to getUserById. Positive default scenario.")
	public void getUserById_Positive_Default_Scenario() {
		
		String id = UUID.randomUUID().toString();
		
		GetUserResult expectedResult = new GetUserResult.ResultBuilder().defaults().build();
		GetUserResp expectedResponse = new GetUserResp(id, expectedResult);

		GetUserByIdReq requestBody = new GetUserByIdReq.Builder()
											.defaults()
											.id(id)
											.build();
		
		GetUserResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserByIdSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to getUserById with invalid method.")
	public void getUserById_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		GetUserByIdReq requestBody = new GetUserByIdReq.Builder()
				.defaults()
				.method("INVALID_METHOD")
				.id(id)
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserByIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getUserById with missing parameter user.")
	public void getUserById_Missing_UserId() {
		
		String id = UUID.randomUUID().toString();

		GetUserByIdReq requestBody = new GetUserByIdReq.Builder()
				.defaults()
				.userId(null)
				.id(id)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserByIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getUserById unknown user_id.")
	public void getUserById_Unknown_UserId() {

		String id = UUID.randomUUID().toString();
		
		GetUserByIdReq requestBody = new GetUserByIdReq.Builder()
				.defaults()
				.userId(999)
				.id(id)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserByIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1001)
				.message("User not found")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}
