package tests.userservice.request;

public class GetCoreDataByGamingIdReq {
	
	@SuppressWarnings("unused")
	private String Method = "getCoreDataByGamingId";
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private GetCoreDataByGamingIdParams Params;
	
	public GetCoreDataByGamingIdReq(String id, String userId) {
		this.ID = id;
		Params  = new GetCoreDataByGamingIdParams(userId);
	}

	public void setMethod(String method) {
		this.Method = method;
	}
	
	private class GetCoreDataByGamingIdParams {
		@SuppressWarnings("unused")
		private String gaming_id;
		
		public GetCoreDataByGamingIdParams(String gamingId) {
			this.gaming_id = gamingId;
		}
	}
}