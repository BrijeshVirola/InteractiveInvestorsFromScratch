package tests.userservice.request;

public class GetUserByUsernameReq {
	
	@SuppressWarnings("unused")
	private String Method = "getUserByUsername";
	@SuppressWarnings("unused")
	private String ID;

	@SuppressWarnings("unused")
	private GetUserByUsernameParams Params;
	
	public GetUserByUsernameReq(String id, String username) {
		this.ID = id;
		Params  = new GetUserByUsernameParams(username);
	}

	public void setMethod(String method) {
		this.Method = method;
	}
	
	private class GetUserByUsernameParams {
		@SuppressWarnings("unused")
		private String username;
		
		public GetUserByUsernameParams(String username) {
			this.username = username;
		}
	}
}