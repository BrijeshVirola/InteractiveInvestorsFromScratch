package tests.userservice.request;

public class GetCoreDataByUsernameReq {
	
	@SuppressWarnings("unused")
	private String Method = "getCoreDataByUsername";
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private GetCoreDataByUsernameParams Params;
	
	public GetCoreDataByUsernameReq(String id, String username) {
		this.ID = id;
		Params  = new GetCoreDataByUsernameParams(username);
	}

	public void setMethod(String method) {
		this.Method = method;
	}
	
	private class GetCoreDataByUsernameParams {
		@SuppressWarnings("unused")
		private String username;
		
		public GetCoreDataByUsernameParams(String username) {
			this.username = username;
		}
	}
}