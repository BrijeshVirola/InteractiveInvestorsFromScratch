package tests.userservice.request;

public class GetCoreDataByUserIdReq {
	
	@SuppressWarnings("unused")
	private String Method = "getCoreDataByUserId";
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private GetCoreDataByUserIdParams Params;
	
	public GetCoreDataByUserIdReq(String id, Integer userId) {
		this.ID = id;
		Params  = new GetCoreDataByUserIdParams(userId);
	}

	public void setMethod(String method) {
		this.Method = method;
	}
	
	private class GetCoreDataByUserIdParams {
		@SuppressWarnings("unused")
		private Integer user_id;
		
		public GetCoreDataByUserIdParams(Integer userId) {
			this.user_id = userId;
		}
	}
}