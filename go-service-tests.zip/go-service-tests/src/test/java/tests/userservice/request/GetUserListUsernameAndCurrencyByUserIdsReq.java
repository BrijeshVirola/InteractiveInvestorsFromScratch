package tests.userservice.request;

import java.util.ArrayList;
import java.util.List;

public class GetUserListUsernameAndCurrencyByUserIdsReq {
	@SuppressWarnings("unused")
	private String Method;
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private GetUserListUsernameAndCurrencyByUserIdsParams Params;
	
	private GetUserListUsernameAndCurrencyByUserIdsReq(Builder builder) {
		Method = builder.method;
		ID = builder.ID;
		Params = new GetUserListUsernameAndCurrencyByUserIdsParams(builder);
	}

	public static class Builder {
		private String method;
		private String ID;
		private List<Integer> user_ids;

		public Builder id(String id) {
			this.ID = id;
			return this;
		}
		
		public Builder userIds(List<Integer> userIds) {
			this.user_ids = userIds;
			return this;
		}
		
		public Builder addUserId(Integer user_id) {
			this.user_ids.add(user_id);
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder defaults() {
			this.method = "getUserListUsernameAndCurrencyByUserIds";
			this.ID = "1";
			user_ids = new ArrayList<>();
			return this;
		}
		
		public GetUserListUsernameAndCurrencyByUserIdsReq build() {
			return new GetUserListUsernameAndCurrencyByUserIdsReq(this);
		}
	}
	
	private class GetUserListUsernameAndCurrencyByUserIdsParams {
		@SuppressWarnings("unused")
		private List<Integer> user_ids;
		
		public GetUserListUsernameAndCurrencyByUserIdsParams(Builder builder) {
			user_ids = builder.user_ids;
		}
	}
}
