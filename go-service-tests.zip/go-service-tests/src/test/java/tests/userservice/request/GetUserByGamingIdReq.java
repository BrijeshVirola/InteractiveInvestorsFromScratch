package tests.userservice.request;

public class GetUserByGamingIdReq {
	
	@SuppressWarnings("unused")
	private String Method = "getUserByGamingId";
	@SuppressWarnings("unused")
	private String ID;
	@SuppressWarnings("unused")
	private GetUserByUsernameParams Params;
	
	public GetUserByGamingIdReq(String id, String gamingId) {
		this.ID = id;
		Params  = new GetUserByUsernameParams(gamingId);
	}

	public void setMethod(String method) {
		this.Method = method;
	}
	
	private class GetUserByUsernameParams {
		@SuppressWarnings("unused")
		private String gaming_id;
		
		public GetUserByUsernameParams(String gamingId) {
			this.gaming_id = gamingId;
		}
	}
}