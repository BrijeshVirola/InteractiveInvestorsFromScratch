package tests.userservice.request;

import java.util.HashMap;
import java.util.Map;

public class GetUserHasTransferredToGamingWalletReq {
	@SuppressWarnings("unused")
	private String method;
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private Integer user_id;
	private Map<String, Object> params = new HashMap<>();
	
	private GetUserHasTransferredToGamingWalletReq(Builder builder) {
		this.method = builder.method;
		this.id = builder.id;
		this.params.put("user_id", builder.user_id);
	}

	public static class Builder {
		private String method;
		private String id;
		private Integer user_id;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder userId(Integer user_id) {
			this.user_id = user_id;
			return this;
		}
		
		public Builder method(String method) {
			this.method = method;
			return this;
		}
		
		public Builder defaults() {
			this.method = "getUserHasTransferredToGamingWallet";
			this.id = null;
			this.user_id = 4622042;
			return this;
		}
		
		public GetUserHasTransferredToGamingWalletReq build() {
			return new GetUserHasTransferredToGamingWalletReq(this);
		}
	}
}
