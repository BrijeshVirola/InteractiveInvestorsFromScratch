package tests.userservice.response;

import java.util.HashMap;
import java.util.Map;

public class GetUsersEmailAddressResp {
	@SuppressWarnings("unused")
	private String id;
	private Map<String, Object> result = new HashMap<>();
	
	private GetUsersEmailAddressResp(Builder builder) {
		this.id = builder.id;
		this.result.put("email_address", builder.email_address);
	}

	public static class Builder {
		private String id;
		private String email_address;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder emailAddress(String email_address) {
			this.email_address = email_address;
			return this;
		}
		
		public Builder defaults() {
			this.id = null;
			this.email_address = "telebet@bet365.com";
			return this;
		}
		
		public GetUsersEmailAddressResp build() {
			return new GetUsersEmailAddressResp(this);
		}
	}
}
