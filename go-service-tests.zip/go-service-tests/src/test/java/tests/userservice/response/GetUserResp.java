package tests.userservice.response;

import tests.userservice.responseobjects.GetUserResult;

public class GetUserResp {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private GetUserResult result;
	
	public GetUserResp(String id, GetUserResult result) {
		this.id = id;
		this.result = result;
	}

	
}
