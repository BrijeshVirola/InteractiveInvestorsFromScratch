package tests.userservice.response;

import java.util.HashMap;
import java.util.Map;

public class GetVipLevelResp {
	@SuppressWarnings("unused")
	private String id;
	private Map<String, Object> result = new HashMap<>();
	
	private GetVipLevelResp(Builder builder) {
		this.id = builder.id;
		this.result.put("vip_level", builder.vip_level);
	}

	public static class Builder {
		private String id;
		private Integer vip_level;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder vipLevel(Integer vip_level) {
			this.vip_level = vip_level;
			return this;
		}
		
		public Builder defaults() {
			this.id = null;
			this.vip_level = 3;
			return this;
		}
		
		public GetVipLevelResp build() {
			return new GetVipLevelResp(this);
		}
	}
}
