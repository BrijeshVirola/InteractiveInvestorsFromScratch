package tests.userservice.response;

public class SetUserResp {
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String result;
	
	private SetUserResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}

	public static class Builder {
		private String id;
		private String result;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder result(String result) {
			this.result = result;
			return this;
		}
		
		public Builder defaults() {
			this.id = null;
			this.result = "OK";
			return this;
		}
		
		public SetUserResp build() {
			return new SetUserResp(this);
		}
	}
}
