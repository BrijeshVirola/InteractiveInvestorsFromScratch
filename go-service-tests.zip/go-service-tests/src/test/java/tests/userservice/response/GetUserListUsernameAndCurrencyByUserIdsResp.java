package tests.userservice.response;

import java.util.ArrayList;
import java.util.List;

import tests.userservice.responseobjects.GetUserUsernameAndCurrency;

public class GetUserListUsernameAndCurrencyByUserIdsResp {

	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private List<GetUserUsernameAndCurrency> result = new ArrayList<>();

	private GetUserListUsernameAndCurrencyByUserIdsResp(Builder builder) {
		this.id = builder.id;
		this.result = builder.result;
	}
	
	public static class Builder {
		private String id;
		private List<GetUserUsernameAndCurrency> result = new ArrayList<>();

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder result(List<GetUserUsernameAndCurrency> result) {
			this.result = result;
			return this;
		}
		
		public Builder addUser(GetUserUsernameAndCurrency user) {
			result.add(user);
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			return this;
		}
		
		public GetUserListUsernameAndCurrencyByUserIdsResp build() {
			return new GetUserListUsernameAndCurrencyByUserIdsResp(this);
		}
	}

}