package tests.userservice.response;

import java.util.HashMap;
import java.util.Map;

public class GetUsersAffiliateCodeResp {
	@SuppressWarnings("unused")
	private String id;
	private Map<String, Object> result = new HashMap<>();
	
	private GetUsersAffiliateCodeResp(Builder builder) {
		this.id = builder.id;
		this.result.put("affiliate_code", builder.affiliate_code);
	}

	public static class Builder {
		private String id;
		private String affiliate_code;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder affiliateCode(String affiliate_code) {
			this.affiliate_code = affiliate_code;
			return this;
		}
		
		public Builder defaults() {
			this.id = null;
			this.affiliate_code = "grm_15469";
			return this;
		}
		
		public GetUsersAffiliateCodeResp build() {
			return new GetUsersAffiliateCodeResp(this);
		}
	}
}
