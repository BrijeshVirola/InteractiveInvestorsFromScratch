package tests.userservice.response;

import java.util.HashMap;
import java.util.Map;

public class GetUserHasTransferredToGamingWalletResp {

	@SuppressWarnings("unused")
	private String id;
	
	private Map<String, Object> result = new HashMap<>();
	
	private GetUserHasTransferredToGamingWalletResp(Builder builder) {
		this.id = builder.id;
		this.result.put("has_transferred_to_gaming_wallet", builder.has_transferred_to_gaming_wallet);
	}
		
	public static class Builder {
		private String id;
		private Boolean has_transferred_to_gaming_wallet;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder bucketDate(Boolean has_transferred_to_gaming_wallet) {
			this.has_transferred_to_gaming_wallet = has_transferred_to_gaming_wallet;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.has_transferred_to_gaming_wallet = false;
			return this;
		}
		
		public GetUserHasTransferredToGamingWalletResp build() {
			return new GetUserHasTransferredToGamingWalletResp(this);
		}	
	}
}
