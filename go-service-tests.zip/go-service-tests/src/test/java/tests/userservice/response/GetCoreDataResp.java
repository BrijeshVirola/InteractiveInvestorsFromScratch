package tests.userservice.response;

import tests.userservice.responseobjects.GetCoreDataResult;

public class GetCoreDataResp {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private GetCoreDataResult result;
	
	public GetCoreDataResp(String id, GetCoreDataResult result) {
		this.id = id;
		this.result = result;
	}
	
}
