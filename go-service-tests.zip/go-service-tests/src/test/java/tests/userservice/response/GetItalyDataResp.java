package tests.userservice.response;

import java.util.HashMap;
import java.util.Map;

public class GetItalyDataResp {
	@SuppressWarnings("unused")
	private String id;
	private Map<String, Object> result = new HashMap<>();
	
	private GetItalyDataResp(Builder builder) {
		this.id = builder.id;
		this.result.put("province_of_birth_id", builder.province_of_birth_id);
		this.result.put("codice_fiscale", builder.codice_fiscale);
		this.result.put("conto_gioco", builder.conto_gioco);
	}

	public static class Builder {
		private String id, codice_fiscale, conto_gioco;
		private Integer province_of_birth_id;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder provinceOfBirthId(Integer province_of_birth_id) {
			this.province_of_birth_id = province_of_birth_id;
			return this;
		}
		
		public Builder codiceFiscale(String codice_fiscale) {
			this.codice_fiscale = codice_fiscale;
			return this;
		}
		
		public Builder contoGioco(String conto_gioco) {
			this.conto_gioco = conto_gioco;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.codice_fiscale = "CRRVTR57S01A783Q";
		    this.conto_gioco = "BT70782";
		    this.province_of_birth_id = 293;
			return this;
		}
		
		public GetItalyDataResp build() {
			return new GetItalyDataResp(this);
		}
	}
}
