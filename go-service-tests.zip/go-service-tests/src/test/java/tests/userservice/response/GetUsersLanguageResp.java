package tests.userservice.response;

import java.util.HashMap;
import java.util.Map;

public class GetUsersLanguageResp {

	@SuppressWarnings("unused")
	private String id;
	
	private Map<String, Object> result = new HashMap<>();
	
	private GetUsersLanguageResp(Builder builder) {
		this.id = builder.id;
		this.result.put("language_id", builder.language_id);
	}
		
	public static class Builder {
		private String id;
		private Integer language_id;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder bucketDate(Integer language_id) {
			this.language_id = language_id;
			return this;
		}
		
		public Builder defaults() {
			this.id = "1";
			this.language_id = 1;
			return this;
		}
		
		public GetUsersLanguageResp build() {
			return new GetUsersLanguageResp(this);
		}	
	}
}
