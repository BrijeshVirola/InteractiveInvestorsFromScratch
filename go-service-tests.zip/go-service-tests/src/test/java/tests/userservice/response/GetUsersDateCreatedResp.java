package tests.userservice.response;

import java.util.HashMap;
import java.util.Map;

public class GetUsersDateCreatedResp {
	@SuppressWarnings("unused")
	private String id;
	private Map<String, Object> result = new HashMap<>();
	
	private GetUsersDateCreatedResp(Builder builder) {
		this.id = builder.id;
		this.result.put("date_created_utc", builder.date_created_utc);
	}

	public static class Builder {
		private String id;
		private String date_created_utc;

		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder dateCreated(String date_created) {
			this.date_created_utc = date_created;
			return this;
		}
		
		public Builder defaults() {
			this.id = null;
			this.date_created_utc = "2007-01-03T09:42:12.38Z";
			return this;
		}
		
		public GetUsersDateCreatedResp build() {
			return new GetUsersDateCreatedResp(this);
		}
	}
}
