package tests.userservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.userservice.request.GetUserByUsernameReq;
import tests.userservice.response.GetUserResp;
import tests.userservice.responseobjects.GetUserCountry;
import tests.userservice.responseobjects.GetUserResult;
import tests.userservice.responseobjects.GetUserRgdd;

public class GetUserByUsernameTests extends BaseClassSetup {
	
	@DataProvider(name = "getUserByUsername")
	//userId, username, timezone, languageId, viplevel, gamingId, currencycode, currencyId, 
	//countryId, countryName, countryIso2, countryIso3
	//
	private Object[][] getUserByUsername() {
		return new Object[][] {
			{2403054, "vzuat5es", 4, 1, 3, "105D5672FB8C7B", "EUR", 17, 171, "Spain", "ES", "ESP", false, false, true, false},
			{3458320, "vzuatdkgrusd", 16, 7, 4, "9BE86EC4EA2BB7", "USD", 54, 218, "Greenland", "GL", "DKK", false, false, true, false},
			};
	}
	
	@Test(description = "Make a request to getUserByUsername. Positive default scenario.")
	public void getUserByUsername_Positive_Default_Scenario() {
		
		String id = UUID.randomUUID().toString();
		
		GetUserResult expectedResult = new GetUserResult.ResultBuilder()
				.defaults()
				.build();
		GetUserResp expectedResponse =  new GetUserResp(id, expectedResult);
		
		GetUserByUsernameReq requestBody = new GetUserByUsernameReq(id, "go_svc_tests06");
		GetUserResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserByUsernameSuccess);
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to getUserByUsername. Positive dataprovider scenario.",
				dataProvider = "getUserByUsername")
	public void getUserByUsername_Positive_Dataprovider_Scenario(Integer userId, String userName, Integer timezone,
			Integer languageId, Integer viplevel, String gamingId, String currencyCode, Integer currencyId, Integer countryId, String countryName, String countryIso2,
			String countryIso3, Boolean allowPlayCgbv, Boolean allowTransferToSports, 
			Boolean allowLogin, Boolean allowPlayPoker) {
		
		String id = UUID.randomUUID().toString();
		
		GetUserCountry expCountry = new GetUserCountry.CountryBuilder()
				.defaults()
				.id(countryId)
				.name(countryName)
				.iso_2_code(countryIso2)
				.iso_3_code(countryIso3)
				.build();
		
		GetUserRgdd expRgdd = new GetUserRgdd.RgddBuilder()
				.defaults()
				.allowPlayCgbv(allowPlayCgbv)
				.allowTransferToSports(allowTransferToSports)
				.allowLogin(allowLogin)
				.allowPlayPoker(allowPlayPoker)
				.build();
		
		GetUserResult expectedResult = new GetUserResult.ResultBuilder()
				.defaults()
				.userId(userId)
				.username(userName)
				.timeZoneId(timezone)
				.currencyCode(currencyCode)
				.currencyId(currencyId)
				.languageId(languageId)
				.country(expCountry)
				.rgdd(expRgdd)
				.vipLevel(viplevel)
				.gamingId(gamingId)
				.build();
		GetUserResp expectedResponse =  new GetUserResp(id, expectedResult);
		
		GetUserByUsernameReq requestBody = new GetUserByUsernameReq(id, userName);
		GetUserResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserByUsernameSuccess);
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to GetUserByUsername with invalid method.")
	public void getUserByUsername_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		GetUserByUsernameReq requestBody = new GetUserByUsernameReq(id, "vzuat5es");
		requestBody.setMethod("INVALID_METHOD");
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserByUsernameError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to getUserByUsername with missing parameter username.")
	public void getUserByUsername_Missing_Username() {
		
		String id = UUID.randomUUID().toString();
		
		GetUserByUsernameReq requestBody = new GetUserByUsernameReq(id, null);
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserByUsernameError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(7)
												.id(id)
												.message("Missing parameter: username")
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to getUserByUsername with not existing user.")
	public void getUserByUsername_Not_Existing_User() {
		
		String id = UUID.randomUUID().toString();
		
		GetUserByUsernameReq requestBody = new GetUserByUsernameReq(id, "not_existing_user");

		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getUserByUsernameError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(1001)
												.id(id)
												.message("User not found")
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
}
