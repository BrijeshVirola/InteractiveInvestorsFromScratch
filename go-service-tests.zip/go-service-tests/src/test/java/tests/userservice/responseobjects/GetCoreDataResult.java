package tests.userservice.responseobjects;

public class GetCoreDataResult {
	
	@SuppressWarnings("unused")
	private Integer user_id;
	@SuppressWarnings("unused")
	private String username;
	@SuppressWarnings("unused")
	private String gaming_id;
	@SuppressWarnings("unused")
	private Integer country_id;
	@SuppressWarnings("unused")
	private Integer country_state_id;
	@SuppressWarnings("unused")
	private Integer currency_id;
	@SuppressWarnings("unused")
	private String currency_code;
	@SuppressWarnings("unused")
	private Integer timezone_id;

	private GetCoreDataResult(ResultBuilder builder) {
		this.user_id = builder.user_id;
		this.username = builder.username;
		this.gaming_id = builder.gaming_id;
		this.country_id = builder.country_id;
		this.country_state_id = builder.country_state_id;
		this.currency_id = builder.currency_id;
		this.currency_code = builder.currency_code;
		this.timezone_id = builder.timezone_id;
	}

	public static class ResultBuilder {
		
		private Integer user_id;
		private String username;
		private String gaming_id;
		private Integer country_id;
		private Integer country_state_id;
		private Integer currency_id;
		private String currency_code;
		private Integer timezone_id;

		public ResultBuilder userId(Integer userId) {
			this.user_id = userId;
			return this;
		}

		public ResultBuilder username(String username) {
			this.username = username;
			return this;
		}
		
		public ResultBuilder gamingId(String gamingId) {
			this.gaming_id = gamingId;
			return this;
		}
		
		public ResultBuilder countryId(Integer countryId) {
			this.country_id = countryId;
			return this;
		}
		
		public ResultBuilder countryStateId(Integer countryStateId) {
			this.country_state_id = countryStateId;
			return this;
		}

		public ResultBuilder currencyId(Integer currencyId) {
			this.currency_id = currencyId;
			return this;
		}
		
		public ResultBuilder currencyCode(String currencyCode) {
			this.currency_code = currencyCode;
			return this;
		}
		
		public ResultBuilder timeZoneId(Integer timeZoneId) {
			this.timezone_id = timeZoneId;
			return this;
		}
		
		public ResultBuilder defaults() {
			
			this.user_id = 4622042;
			this.username = "go_svc_tests06";
			this.gaming_id = "CCFE4339FF1961";
			this.country_id = 197;
			this.country_state_id = 0;
			this.currency_id = 1;		
			this.currency_code = "GBP";
			this.timezone_id = 1;
			return this;
		}

		public GetCoreDataResult build() {
			GetCoreDataResult result = new GetCoreDataResult(this);
			return result;
		}
	}
}

