package tests.userservice.responseobjects;

public class GetUserRgdd {
	
	@SuppressWarnings("unused")
	private Boolean allow_play_cgbv, allow_transfer_to_sports, allow_login, allow_play_poker;

	private GetUserRgdd(RgddBuilder builder) {
		this.allow_play_cgbv = builder.allow_play_cgbv;
		this.allow_transfer_to_sports = builder.allow_transfer_to_sports;
		this.allow_login = builder.allow_login;
		this.allow_play_poker = builder.allow_play_poker;
	}

	public static class RgddBuilder {
		private Boolean allow_play_cgbv, allow_transfer_to_sports, allow_login, allow_play_poker;

		public RgddBuilder allowPlayCgbv(Boolean allowPlayCgbv) {
			this.allow_play_cgbv = allowPlayCgbv;
			return this;
		}

		public RgddBuilder allowTransferToSports(Boolean allowTransferToSports) {
			this.allow_transfer_to_sports = allowTransferToSports;
			return this;
		}
		
		public RgddBuilder allowLogin(Boolean allowLogin) {
			this.allow_login = allowLogin;
			return this;
		}
		
		public RgddBuilder allowPlayPoker(Boolean allowPlayPoker) {
			this.allow_play_poker = allowPlayPoker;
			return this;
		}
		
		public RgddBuilder defaults() {
			this.allow_play_cgbv = true;
			this.allow_transfer_to_sports = true;		
			this.allow_login = true;		
			this.allow_play_poker = true;		
			return this;
		}

		public GetUserRgdd build() {
			GetUserRgdd result = new GetUserRgdd(this);
			return result;
		}
	}
}

