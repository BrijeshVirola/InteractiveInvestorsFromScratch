package tests.userservice.responseobjects;

public class GetUserUsernameAndCurrency {
	
	@SuppressWarnings("unused")
	private Integer user_id;
	@SuppressWarnings("unused")
	private String username;
	@SuppressWarnings("unused")
	private Integer currency_id;
	
	private GetUserUsernameAndCurrency(Builder builder) {
		this.user_id = builder.user_id;
		this.username = builder.username;
		this.currency_id = builder.currency_id;
	}
	
	public static class Builder {
		
		private Integer user_id;
		private String username;
		private Integer currency_id;

		public Builder userId(Integer userId) {
			this.user_id = userId;
			return this;
		}

		public Builder username(String username) {
			this.username = username;
			return this;
		}
		
		public Builder currencyId(Integer currencyId) {
			this.currency_id = currencyId;
			return this;
		}

		public Builder defaults() {
			this.user_id = 56311;
			this.username = "gmcgann";		
			this.currency_id = 1;		
			return this;
		}

		public GetUserUsernameAndCurrency build() {
			GetUserUsernameAndCurrency result = new GetUserUsernameAndCurrency(this);
			return result;
		}
	}

}
