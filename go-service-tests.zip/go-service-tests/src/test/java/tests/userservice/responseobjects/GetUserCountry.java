package tests.userservice.responseobjects;

public class GetUserCountry {
	
	@SuppressWarnings("unused")
	private Integer id;
	@SuppressWarnings("unused")
	private String name, iso_2_code, iso_3_code;

	private GetUserCountry(CountryBuilder builder) {
		this.id = builder.id;
		this.name = builder.name;
		this.iso_2_code = builder.iso_2_code;
		this.iso_3_code = builder.iso_3_code;
	}

	public static class CountryBuilder {
		
		private Integer id;
		private String name, iso_2_code, iso_3_code;

		public CountryBuilder id(Integer id) {
			this.id = id;
			return this;
		}

		public CountryBuilder name(String name) {
			this.name = name;
			return this;
		}
		
		public CountryBuilder iso_2_code(String iso_2_code) {
			this.iso_2_code = iso_2_code;
			return this;
		}
		
		public CountryBuilder iso_3_code(String iso_3_code) {
			this.iso_3_code = iso_3_code;
			return this;
		}
		
		public CountryBuilder defaults() {
			this.id = 197;
			this.name = "United Kingdom";		
			this.iso_2_code = "GB";		
			this.iso_3_code = "GBR";		
			return this;
		}

		public GetUserCountry build() {
			GetUserCountry result = new GetUserCountry(this);
			return result;
		}
	}
}

