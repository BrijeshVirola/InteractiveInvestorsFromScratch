package tests.userservice.responseobjects;

public class GetUserResult {
	
	@SuppressWarnings("unused")
	private Integer user_id;
	@SuppressWarnings("unused")
	private String username;
	@SuppressWarnings("unused")
	private String currency_code;
	@SuppressWarnings("unused")
	private Integer time_zone_id;
	@SuppressWarnings("unused")
	private Integer language_id;
	@SuppressWarnings("unused")
	private Integer vip_level;
	@SuppressWarnings("unused")
	private String gaming_id;
	@SuppressWarnings("unused")
	private GetUserCountry country;
	@SuppressWarnings("unused")
	private GetUserRgdd rgdd;
	@SuppressWarnings("unused")
	private Integer currency_id;

	private GetUserResult(ResultBuilder builder) {
		this.user_id = builder.user_id;
		this.username = builder.username;
		this.currency_code = builder.currency_code;
		this.time_zone_id = builder.time_zone_id;
		this.language_id = builder.language_id;
		this.vip_level = builder.vip_level;
		this.gaming_id = builder.gaming_id;
		this.country = builder.country;
		this.rgdd = builder.rgdd;
		this.currency_id = builder.currency_id;
	}

	public static class ResultBuilder {
		
		private Integer user_id;
		private String username;
		private String currency_code;
		private Integer time_zone_id;
		private Integer language_id;
		private Integer vip_level;
		private String gaming_id;
		private GetUserCountry country;
		private GetUserRgdd rgdd;
		private Integer currency_id;

		public ResultBuilder userId(Integer userId) {
			this.user_id = userId;
			return this;
		}

		public ResultBuilder username(String username) {
			this.username = username;
			return this;
		}
		
		public ResultBuilder currencyCode(String currencyCode) {
			this.currency_code = currencyCode;
			return this;
		}
		
		public ResultBuilder timeZoneId(Integer timeZoneId) {
			this.time_zone_id = timeZoneId;
			return this;
		}
		
		public ResultBuilder languageId(Integer languageId) {
			this.language_id = languageId;
			return this;
		}
		
		public ResultBuilder vipLevel(Integer vipLevel) {
			this.vip_level = vipLevel;
			return this;
		}
		
		public ResultBuilder gamingId(String gamingId) {
			this.gaming_id = gamingId;
			return this;
		}
		
		public ResultBuilder country(GetUserCountry country) {
			this.country = country;
			return this;
		}
		
		public ResultBuilder rgdd(GetUserRgdd rgdd) {
			this.rgdd = rgdd;
			return this;
		}
		
		public ResultBuilder currencyId(Integer currencyId) {
			this.currency_id = currencyId;
			return this;
		}
		
		public ResultBuilder defaults() {
			
			this.user_id = 4622042;
			this.username = "go_svc_tests06";
			this.currency_code = "GBP";
			this.time_zone_id = 1;
			this.language_id = 1;
			this.vip_level = 3;
			this.gaming_id = "CCFE4339FF1961";
			this.country = new GetUserCountry.CountryBuilder().defaults().build();
			this.rgdd = new GetUserRgdd.RgddBuilder().defaults().build();
			this.currency_id = 1;		
			return this;
		}

		public GetUserResult build() {
			GetUserResult result = new GetUserResult(this);
			return result;
		}
	}
}

