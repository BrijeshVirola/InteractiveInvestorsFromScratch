package tests.userservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.userservice.request.GetUsersDateCreatedReq;
import tests.userservice.response.GetUsersDateCreatedResp;

public class GetUsersDateCreatedTests extends BaseClassSetup {

	@Test(description = "Make a request to getUsersDateCreated. Positive default scenario.")
	public void getUsersDateCreated_Positive_Default_Scenario() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetUsersDateCreatedResp expectedResponse = new GetUsersDateCreatedResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.build();

		GetUsersDateCreatedReq requestBody = new GetUsersDateCreatedReq.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId)
											.build();
		
		GetUsersDateCreatedResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getUsersDateCreatedSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to GetUsersDateCreated with invalid method.")
	public void getUsersDateCreated_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		GetUsersDateCreatedReq requestBody = new GetUsersDateCreatedReq.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getUsersDateCreatedError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getUsersDateCreated with missing parameter user.")
	public void getUsersDateCreated_Missing_UserId() {
		
		String id = UUID.randomUUID().toString();

		GetUsersDateCreatedReq requestBody = new GetUsersDateCreatedReq.Builder()
				.defaults()
				.userId(null)
				.id(id)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getUsersDateCreatedError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder().code(7).id(id)
				.message("Missing parameter: user_id").build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getUsersDateCreated unknown user_id.")
	public void getUsersDateCreated_Unknown_UserId() {
		
		String id = UUID.randomUUID().toString();
		
		GetUsersDateCreatedReq requestBody = new GetUsersDateCreatedReq.Builder()
				.defaults()
				.userId(999)
				.id(id)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getUsersDateCreatedError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder().code(1001).message("User not found").id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}
