package tests.userservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.userservice.request.SetUserHasLaunchedGameReq;
import tests.userservice.response.SetUserResp;

public class SetUserHasLaunchedGameTests extends BaseClassSetup {

	@Test(description = "Make a request to setUserHasLaunchedGame. Positive default scenario.")
	public void setUserHasLaunchedGame_Positive_Default_Scenario() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		SetUserResp expectedResponse = new SetUserResp.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId)
											.build();

		SetUserHasLaunchedGameReq requestBody = new SetUserHasLaunchedGameReq.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId)
											.build();
		
		SetUserResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.setUserHasLaunchedGameSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to SetUserHasLaunchedGame with invalid method.")
	public void SetUserHasLaunchedGame_Invalid_Method() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		SetUserHasLaunchedGameReq requestBody = new SetUserHasLaunchedGameReq.Builder()
				.defaults()
				.method("INVALID_METHOD")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.setUserHasLaunchedGameError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to setUserHasLaunchedGame with missing parameter user.")
	public void setUserHasLaunchedGame_Missing_UserId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		SetUserHasLaunchedGameReq requestBody = new SetUserHasLaunchedGameReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.setUserHasLaunchedGameError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to setUserHasLaunchedGame unknown user_id.")
	public void setUserHasLaunchedGame_Unknown_UserId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		SetUserHasLaunchedGameReq requestBody = new SetUserHasLaunchedGameReq.Builder()
				.defaults()
				.userId(UsersId.NOT_EXISTING)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.setUserHasLaunchedGameError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1001)
				.message("User not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}
