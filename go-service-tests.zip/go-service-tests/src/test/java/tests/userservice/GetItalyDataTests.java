package tests.userservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.ServiceErrors;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import domain.ErrorResponse;
import io.restassured.response.Response;
import tests.userservice.request.GetItalyDataReq;
import tests.userservice.response.GetItalyDataResp;

public class GetItalyDataTests extends BaseClassSetup {

	@Test(description = "Make a request to getItalyData. Positive default scenario.")
	public void getItalyData_Positive_Default_Scenario() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetItalyDataResp expectedResponse = new GetItalyDataResp.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId)
											.build();

		GetItalyDataReq requestBody = new GetItalyDataReq.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId)
											.build();
		
		GetItalyDataResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getItalyDataSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to getItalyData with invalid method.")
	public void getItalyData_Invalid_Method() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetItalyDataReq requestBody = new GetItalyDataReq.Builder()
				.defaults()
				.method("INVALID_METHOD")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getItalyDataError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getItalyData with missing parameter user_id.")
	public void getItalyData_Missing_UserId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetItalyDataReq requestBody = new GetItalyDataReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getItalyDataError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getItalyData unknown user_id.")
	public void getItalyData_Unknown_UserId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetItalyDataReq requestBody = new GetItalyDataReq.Builder()
				.defaults()
				.userId(UsersId.NOT_EXISTING)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getItalyDataError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1001)
				.message("User not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to getItalyData for known user but who is not resident in Italy.")
	public void getItalyData_NonItalian_UserId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetItalyDataReq requestBody = new GetItalyDataReq.Builder()
				.defaults()
				.userId(UsersId.GO_SVC_TESTS)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getItalyDataError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1001)
				.message("User not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request with no json in the body - Error code 4")
	public void no_Json() {

		Response response = BaseRequest.callNoJsonRequest(baseUriUserService, "getItalyData",
				true, true, true);
		
		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.NO_JSON_REQUEST);

		assertReflectionEquals(expError, actError);
	}
	
	
	@Test(description = "Make a request with empty json in the body - Error code 5")
	public void json_Body_Empty() {

		Response response = BaseRequest.callEmptyBodyRequest(baseUriUserService, "getItalyData",
				true, true, true);
		
		ErrorResponse actError = response.as(ErrorResponse.class);
		ErrorResponse expError =  new ErrorResponse(ServiceErrors.EMPTY_JSON_BODY_REQUEST);

		assertReflectionEquals(expError, actError);
	}
}
