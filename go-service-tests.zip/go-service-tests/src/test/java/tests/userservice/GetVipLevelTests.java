package tests.userservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.userservice.request.GetVipLevelReq;
import tests.userservice.response.GetVipLevelResp;

public class GetVipLevelTests extends BaseClassSetup {

	@Test(description = "Make a request to getVipLevel. Positive default scenario.")
	public void getVipLevel_Positive_Default_Scenario() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		GetVipLevelResp expectedResponse = new GetVipLevelResp.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId)
											.build();

		GetVipLevelReq requestBody = new GetVipLevelReq.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId)
											.build();
		
		GetVipLevelResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.getVipLevelSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to GetVipLevel with invalid method.")
	public void getVipLevel_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		GetVipLevelReq requestBody = new GetVipLevelReq.Builder()
				.defaults()
				.id(id)
				.method("INVALID_METHOD")
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getVipLevelError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to getVipLevel with missing user_id.")
	public void getVipLevel_Missing_UserId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetVipLevelReq requestBody = new GetVipLevelReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getVipLevelError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: user_id")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to getVipLevel unknown user_id.")
	public void getVipLevel_Unknown_UserId() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetVipLevelReq requestBody = new GetVipLevelReq.Builder()
				.defaults()
				.userId(UsersId.NOT_EXISTING)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getVipLevelError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1006)
				.message("User VIP level not found")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to getVipLevel with unknown product_id.")
	public void getVipLevel_Unknown_ProductId() {

		Integer unknownProductId = 99999;
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetVipLevelReq requestBody = new GetVipLevelReq.Builder()
				.defaults()
				.productId(unknownProductId)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.getVipLevelError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1005)
				.message("Invalid product_id. Must be a derivative of Games, Casino or Poker.")
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}
