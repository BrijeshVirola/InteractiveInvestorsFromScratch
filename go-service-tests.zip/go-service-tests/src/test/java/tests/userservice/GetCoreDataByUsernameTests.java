package tests.userservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.userservice.request.GetCoreDataByUsernameReq;
import tests.userservice.response.GetCoreDataResp;
import tests.userservice.responseobjects.GetCoreDataResult;

public class GetCoreDataByUsernameTests extends BaseClassSetup {
	
	@DataProvider(name = "getCoreDataByUserName")
	//id, userId, username, gamingId, country_id, country_state_id, language_id, currency_id,
	//currency_code, timezone_id, has_transferred_to_gaming_wallet
	//
	private Object[][] getCoreDataByUserName() {
		return new Object[][] {
			{"testId123", 4622042, "go_svc_tests06", "CCFE4339FF1961", 197, 0, 1, "GBP", 1},
			{"55425", 2403054, "vzuat5es", "105D5672FB8C7B", 171, 0, 17, "EUR", 4},
			{"test1@", 2349500, "vzuat1ireland", "FB82C182E3B59B", 95, 166, 17, "EUR", 1}
			};
	}
	
	@Test(description = "Make a request to getCoreDataByUserName. Positive default scenario.", 
			dataProvider = "getCoreDataByUserName")
	public void getCoreDataByUserName_Positive_Scenario(String id, Integer userId, String username, String gamingId, Integer country_id,
			Integer country_state_id, Integer currency_id,
			String currency_code, Integer timezone_id) {
		
		GetCoreDataResult expectedResult = new GetCoreDataResult.ResultBuilder()
				.defaults()
				.userId(userId)
				.username(username)
				.gamingId(gamingId)
				.countryId(country_id)
				.countryStateId(country_state_id)
				.currencyId(currency_id)
				.currencyCode(currency_code)
				.timeZoneId(timezone_id)
				.build();
		GetCoreDataResp expectedResponse =  new GetCoreDataResp(id, expectedResult);
		
		GetCoreDataByUsernameReq requestBody = new GetCoreDataByUsernameReq(id, username);
		GetCoreDataResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getCoreDataByUserNameSuccess);
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getCoreDataByUserName with invalid method.")
	public void getCoreDataByUserName_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		GetCoreDataByUsernameReq requestBody = new GetCoreDataByUsernameReq(id, "testId123");
		requestBody.setMethod("INVALID_METHOD");
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getCoreDataByUserNameError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to getCoreDataByUserName with missing parameter username.")
	public void getUserByUsername_Missing_UserId() {
		
		String id = UUID.randomUUID().toString();
		
		GetCoreDataByUsernameReq requestBody = new GetCoreDataByUsernameReq(id, null);
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getCoreDataByUserNameError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(7)
												.message("Missing parameter: username")
												.id(id)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to getCoreDataByUserName with not existing username.")
	public void getUserByUsername_Not_Existing_User() {
		
		String id = UUID.randomUUID().toString();
		
		GetCoreDataByUsernameReq requestBody = new GetCoreDataByUsernameReq(id, "not_existing_user");
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getCoreDataByUserNameError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(1001)
												.message("User not found")
												.id(id)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
}
