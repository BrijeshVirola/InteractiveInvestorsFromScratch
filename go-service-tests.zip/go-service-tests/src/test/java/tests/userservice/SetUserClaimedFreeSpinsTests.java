package tests.userservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import common.enumsconstants.UsersId;
import domain.BaseRequest;
import tests.userservice.request.SetUserClaimedFreeSpinsReq;
import tests.userservice.response.SetUserResp;

public class SetUserClaimedFreeSpinsTests extends BaseClassSetup {

	@Test(description = "Make a request to setUserClaimedFreeSpins. Positive default scenario.")
	public void setUserClaimedFreeSpins_Positive_Default_Scenario() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		SetUserResp expectedResponse = new SetUserResp.Builder()
															.defaults()
															.id(idForRequestToBeEchoedBackInResponseId)
															.build();

		SetUserClaimedFreeSpinsReq requestBody = new SetUserClaimedFreeSpinsReq.Builder()
											.defaults()
											.id(idForRequestToBeEchoedBackInResponseId)
											.build();
		
		SetUserResp actualResponse = BaseRequest.getResponse(requestBody, ResponseEndpoints.setUserClaimedFreeSpinsSuccess);

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to SetUserClaimedFreeSpins with invalid method.")
	public void SetUserClaimedFreeSpins_Invalid_Method() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		SetUserClaimedFreeSpinsReq requestBody = new SetUserClaimedFreeSpinsReq.Builder()
				.defaults()
				.id(idForRequestToBeEchoedBackInResponseId)
				.method("UNKNOWN_METHOD")
				.build();
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.setUserClaimedFreeSpinsError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to setUserClaimedFreeSpins with missing parameter user.")
	public void setUserClaimedFreeSpins_Missing_UserId() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SetUserClaimedFreeSpinsReq requestBody = new SetUserClaimedFreeSpinsReq.Builder()
				.defaults()
				.userId(null)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.setUserClaimedFreeSpinsError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder().code(7)
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("Missing parameter: user_id").build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Make a request to setUserClaimedFreeSpins unknown user_id.")
	public void setUserClaimedFreeSpins_Unknown_UserId() {
		
		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		SetUserClaimedFreeSpinsReq requestBody = new SetUserClaimedFreeSpinsReq.Builder()
				.defaults()
				.userId(UsersId.NOT_EXISTING)
				.id(idForRequestToBeEchoedBackInResponseId)
				.build();

		CustomErrorResponse actualError = BaseRequest.getResponse(requestBody, ResponseEndpoints.setUserClaimedFreeSpinsError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder().code(1001)
				.id(idForRequestToBeEchoedBackInResponseId)
				.message("User not found")
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}
