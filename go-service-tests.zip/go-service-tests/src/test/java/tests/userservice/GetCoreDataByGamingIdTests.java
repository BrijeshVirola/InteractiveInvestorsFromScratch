package tests.userservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.userservice.request.GetCoreDataByGamingIdReq;
import tests.userservice.response.GetCoreDataResp;
import tests.userservice.responseobjects.GetCoreDataResult;

public class GetCoreDataByGamingIdTests extends BaseClassSetup {
	
	@DataProvider(name = "getCoreDataByGamingId")
	//id, userId, username, gamingId, country_id, country_state_id, language_id, currency_id,
	//currency_code, timezone_id, has_transferred_to_gaming_wallet
	//
	private Object[][] getCoreDataByGamingId() {
		return new Object[][] {
			{"testId123", 4622042, "go_svc_tests06", "CCFE4339FF1961", 197, 0, 1, "GBP", 1},
			{"55425", 2403054, "vzuat5es", "105D5672FB8C7B", 171, 0, 17, "EUR", 4},
			{"test1@", 2349500, "vzuat1ireland", "FB82C182E3B59B", 95, 166, 17, "EUR", 1}
			};
	}
	
	@Test(description = "Make a request to getCoreDataByGamingId. Positive default scenario.", 
			dataProvider = "getCoreDataByGamingId")
	public void getCoreDataByGamingId_Positive_Scenario(String id, Integer userId, String username, String gamingId, Integer country_id,
			Integer country_state_id,Integer currency_id,
			String currency_code, Integer timezone_id) {
		
		GetCoreDataResult expectedResult = new GetCoreDataResult.ResultBuilder()
				.defaults()
				.userId(userId)
				.username(username)
				.gamingId(gamingId)
				.countryId(country_id)
				.countryStateId(country_state_id)
				.currencyId(currency_id)
				.currencyCode(currency_code)
				.timeZoneId(timezone_id)
				.build();
		GetCoreDataResp expectedResponse =  new GetCoreDataResp(id, expectedResult);
		
		GetCoreDataByGamingIdReq requestBody = new GetCoreDataByGamingIdReq(id, gamingId);
		GetCoreDataResp actualResponse =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getCoreDataByGamingIdSuccess);
		
		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@Test(description = "Make a request to getCoreDataByGamingId with invalid method.")
	public void getCoreDataByGamingId_Invalid_Method() {
		
		String id = UUID.randomUUID().toString();
		
		GetCoreDataByGamingIdReq requestBody = new GetCoreDataByGamingIdReq(id, "4622042");
		requestBody.setMethod("INVALID_METHOD");
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getCoreDataByGamingIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(6)
												.message("Incorrect method in request")
												.id(null)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to getCoreDataByGamingId with missing parameter user id.")
	public void getCoreDataByGamingId_Missing_UserId() {
		
		String id = UUID.randomUUID().toString();
		
		GetCoreDataByGamingIdReq requestBody = new GetCoreDataByGamingIdReq(id, null);
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getCoreDataByGamingIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(7)
												.message("Missing parameter: gaming_id")
												.id(id)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to getCoreDataByGamingId invalid gamingId.")
	public void getCoreDataByGamingId_Invalid_GamingId() {
		
		String id = UUID.randomUUID().toString();
		
		GetCoreDataByGamingIdReq requestBody = new GetCoreDataByGamingIdReq(id, "9BE86EC4EA2BB71");
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getCoreDataByGamingIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(8)
												.message("Parameter validation failed: gaming_id must be 14 characters")
												.id(id)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
	
	@Test(description = "Make a request to getCoreDataByGamingId with not existing gamingId.")
	public void getCoreDataByGamingId_Not_Existing_GamingId() {
		
		String id = UUID.randomUUID().toString();
		
		GetCoreDataByGamingIdReq requestBody = new GetCoreDataByGamingIdReq(id, "ID_ISNOT_FOUND");
		
		CustomErrorResponse actualError =  BaseRequest.getResponse(requestBody, ResponseEndpoints.getCoreDataByGamingIdError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
												.code(1001)
												.message("User not found")
												.id(id)
												.build();
		
		assertReflectionEquals(expectedError, actualError);
	}
}
