package tests.playtechbalanceservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.ExpectedFailure;
import common.enumsconstants.ResponseEndpoints;
import domain.BaseRequest;
import tests.playtechbalanceservice.request.GetBonusBalancesForProductReq;
import tests.playtechbalanceservice.response.GetBonusBalancesForProductResp;

public class GetBonusBalancesForProductTests extends BaseClassSetup {
	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2425", action="commented out test for id field")
	@Test(description = "Make a request to GetBonusBalancesForProduct. Positive scenario.")
	public void getBonusBalancesForProduct_Positive_Scenario() throws InterruptedException {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();
		
		GetBonusBalancesForProductReq request = new GetBonusBalancesForProductReq.Builder()
										.defaults()
										.id(idForRequestToBeEchoedBackInResponseId)
										.build();
		
		GetBonusBalancesForProductResp actualResponse =  BaseRequest.getResponse(request, ResponseEndpoints.getBonusBalancesForProductSuccess);

		GetBonusBalancesForProductResp expectedResponse = new GetBonusBalancesForProductResp.Builder()
															.defaults()
															.id(null)//reinstate this test when PRJSAK-2425 is fixed
															.build();
		
		assertReflectionEquals(expectedResponse, actualResponse);	
	}

	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2425", action="commented out test for id field")
	@Test(description = "Make a request to getBonusBalancesForProduct. Missing user_id parameter.")
	public void getBonusBalancesForProduct_MissingUserid_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetBonusBalancesForProductReq request = new GetBonusBalancesForProductReq.Builder()
														.defaults()
														.userId(null)
														.id(idForRequestToBeEchoedBackInResponseId)
														.build();

		CustomErrorResponse actualResponse = BaseRequest.getResponse(request, ResponseEndpoints.getBonusBalancesForProductError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
													.code(7)
													.message("Missing parameter: user_id")
													.id(null)//reinstate this test when PRJSAK-2425 is fixed
													.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}

	@ExpectedFailure(jiraRef = "https://jira/browse/PRJSAK-2425", action="commented out test for id field")
	@Test(description = "Make a request to getBonusBalancesForProduct. Missing product_id parameter.")
	public void getBonusBalancesForProduct_MissingProductId_Parameter() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetBonusBalancesForProductReq request = new GetBonusBalancesForProductReq.Builder()
														.defaults()
														.productId(null)
														.id(idForRequestToBeEchoedBackInResponseId)
														.build();

		CustomErrorResponse actualResponse = BaseRequest.getResponse(request, ResponseEndpoints.getBonusBalancesForProductError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
													.code(7)
													.message("Missing parameter: product_id")
													.id(null)//reinstate this test when PRJSAK-2425 is fixed
													.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
	
	@Test(description = "Make a request to getBonusBalancesForProduct. Wrong method.")
	public void getNetPositon_Wrong_Method() {

		String idForRequestToBeEchoedBackInResponseId = UUID.randomUUID().toString();

		GetBonusBalancesForProductReq request = new GetBonusBalancesForProductReq.Builder().defaults()
				.id(idForRequestToBeEchoedBackInResponseId).method("INVALID_METHOD_NAME").build();

		CustomErrorResponse actualResponse = BaseRequest.getResponse(request, ResponseEndpoints.getBonusBalancesForProductError);

		CustomErrorResponse expectedResponse = new CustomErrorResponse.Builder()
													.code(6)
													.message("Incorrect method in request")
													.id(null)
													.build();

		assertReflectionEquals(expectedResponse, actualResponse);
	}
}
