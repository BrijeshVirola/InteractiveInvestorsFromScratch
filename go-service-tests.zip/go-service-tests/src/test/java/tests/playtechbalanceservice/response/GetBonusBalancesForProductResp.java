package tests.playtechbalanceservice.response;

import java.util.HashMap;
import java.util.Map;

public class GetBonusBalancesForProductResp {
	@SuppressWarnings("unused")
	private String id = null;
	private Map<String, Object> result = new HashMap<>();
	
	private GetBonusBalancesForProductResp(Builder builder) {
		this.id = builder.id;
		this.result.put("bonus_balance", builder.bonus_balance);
		this.result.put("bonus_pending_winnings", builder.bonus_pending_winnings);
		this.result.put("ringfenced_balance", builder.ringfenced_balance);
		this.result.put("real_winnings_balance", builder.real_winnings_balance);
	}
	
	public static class Builder {
		private String id, bonus_balance, bonus_pending_winnings, ringfenced_balance, real_winnings_balance;
		
		public Builder id(String id) {
			this.id = id;
			return this;
		}
		
		public Builder bonusBalance(String bonus_balance) {
			this.bonus_balance = bonus_balance;
			return this;
		}
		
		public Builder bonusPendingWinnings(String bonus_pending_winnings) {
			this.bonus_pending_winnings = bonus_pending_winnings;
			return this;
		}
		
		public Builder ringfencedBalance(String ringfenced_balance) {
			this.ringfenced_balance = ringfenced_balance;
			return this;
		}
		
		public Builder realWinningsBalance(String real_winnings_balance) {
			this.real_winnings_balance = real_winnings_balance;
			return this;
		}
		
		public Builder defaults() {
			this.id = null;
			this.bonus_balance = "0";
			this.bonus_pending_winnings = "0";
			this.ringfenced_balance = "0";
			this.real_winnings_balance = "0";
			return this;
		}
		
		public GetBonusBalancesForProductResp build() {
			return new GetBonusBalancesForProductResp(this);
		}	
	}
}

