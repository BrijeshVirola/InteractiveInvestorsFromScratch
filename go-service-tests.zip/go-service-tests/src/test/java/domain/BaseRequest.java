package domain;
import com.google.gson.JsonObject;

import common.enumsconstants.ResponseEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import logging.LoggingRequestFilter;

public class BaseRequest {
	
	private static LoggingRequestFilter filter = new LoggingRequestFilter();
	private static JsonObject body = new JsonObject();
	
	public static RequestSpecification createRequest(JsonObject jsonBody) {
		return createRequest(jsonBody, true, true); 
	}
	
	public static RequestSpecification createRequest(Object pojo) {
		return createRequest(pojo, true, true); 
	}
	
	public static RequestSpecification createRequest(JsonObject jsonBody, boolean shouldSetAcceptHeader, boolean shouldSetContentTypeHeader) {
		RequestSpecification request = RestAssured.given().filter(filter);

		setAcceptAndContentType(shouldSetAcceptHeader, shouldSetContentTypeHeader, request);
		
		request.body(jsonBody.toString());

		return request;
	}
	
	public static RequestSpecification createRequest(Object pojo, boolean shouldSetAcceptHeader, boolean shouldSetContentTypeHeader) {
		
		RequestSpecification request = RestAssured.given().filter(filter);
		setAcceptAndContentType(shouldSetAcceptHeader, shouldSetContentTypeHeader, request);
		request.body(pojo);

		return request;
	}
	
	public static Response callWrongMethodNameRequest(String baseUri, String endPoint, boolean post) {
		
		JsonObject body = new JsonObject();
		body.addProperty("Method", "invalid_method");

		RequestSpecification request = createRequest(body);
		Response response = post ? request.post(baseUri + endPoint) : request.get(baseUri + endPoint);
		response.then().statusCode(200);
		return response;
	}
	
	/**
	 * 
	 * @param baseUri
	 * @param endPoint
	 * @param shouldSetAcceptHeader
	 * @param shouldSetContentTypeHeader
	 * @param post if true will call POST request, otherwise GET
	 * @return
	 */
	public static Response callEmptyBodyRequest(String baseUri, String endPoint,
			boolean shouldSetAcceptHeader,
			boolean shouldSetContentTypeHeader, boolean post) {

		RequestSpecification request = createRequest(body, shouldSetAcceptHeader, shouldSetContentTypeHeader);
		Response response = post ? request.post(baseUri + endPoint) : request.get(baseUri + endPoint);
		response.then().statusCode(200);
		return response;
	}
	
	public static Response callNoJsonRequest(String baseUri, String endPoint, boolean shouldSetAcceptHeader,
			boolean shouldSetContentTypeHeader, boolean post) {
		RequestSpecification request = RestAssured.given().filter(filter);
		setAcceptAndContentType(shouldSetAcceptHeader, shouldSetContentTypeHeader, request);
		request.body("");
		
		Response response = post ? request.post(baseUri + endPoint) : request.get(baseUri + endPoint);
		response.then().statusCode(200);
		return response;
	}
	
	private static void setAcceptAndContentType(boolean shouldSetAcceptHeader, boolean shouldSetContentTypeHeader, RequestSpecification request) {
		if (shouldSetAcceptHeader) {
			request.header("Accept", "application/json");
		}
		if (shouldSetContentTypeHeader) {
			request.header("Content-Type", "application/json");
		}
	}
	
	public static <T> T getResponse(Object reqObject, ResponseEndpoints endpoint) {
		
		String port = "";
		if (endpoint.getPort().length() > 0) {
			port = ":" + endpoint.getPort();
		}

		String baseUri = RestAssured.baseURI + port + "/api/";
		
		RequestSpecification request = createRequest(reqObject);
		Response response = request.post(baseUri + endpoint.getEndPoint());
		response.then().statusCode(200);
		
		T resp = response.as(endpoint.getRespClass());
		
		return resp;
	}
}

