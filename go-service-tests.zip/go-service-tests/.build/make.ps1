param (
    [string]$action,
    [string]$configuration = "Debug"
)

$ErrorActionPreference = "Stop"

.('C:\Gaming-Build\PowerShell\Infrastructure\Master.ps1')

Debug-UserInfo

$executionPath = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

function Make-Compile {
    Write-Host "Starting action: compile"
	
	robocopy "E:\JavaMavenDependencies" LIB /e

	C:\Gaming-Build\Dependencies\Maven\3.3.9\bin\mvn.cmd "-Dfile.encoding=UTF-8" "-Dmaven.repo.local=LIB" clean compile test-compile -e -X -nsu -gs settings.xml -s settings.xml

	$BUILDOUTPUT = $LASTEXITCODE

	Remove-Item LIB -Recurse -Force
	
	if ($BUILDOUTPUT -ne 0) {
        throw "Build Failed"
    }

    Write-Host "Finished action: compile"
}

try {
    if ($action -eq "compile") {
        Make-Compile
    }
    else {
        Write-Host "No matching actions"
        Write-Host "Supported actions are: compile"
    }
}
catch {
    Write-Output "Exception Caught: $($_.Exception.Message)"
    Write-Output "QUITTING AFTER FAILURE"
    exit 1
}