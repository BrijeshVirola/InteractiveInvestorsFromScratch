package common;

public class Config {


	public static String gameplayLimitsPort = "9523";
}
