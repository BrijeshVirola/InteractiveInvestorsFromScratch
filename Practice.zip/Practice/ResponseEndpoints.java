package common.enumsconstants;

import common.Config;
import common.CustomErrorResponse;

public enum ResponseEndpoints {
	
	
	//Gameplay Limits Service
	getCurrentSummaryError(CustomErrorResponse.class, "GetCurrentSummary", Config.gameplayLimitsPort),
	getCurrentSummarySuccess(GetCurrentSummaryResp.class, "GetCurrentSummary", Config.gameplayLimitsPort),
    RevertSpendSuccess(RevertSpendResp.class, "revertspend", Config.gameplayLimitsPort),
    RevertSpendError(CustomErrorResponse.class, "revertspend", Config.gameplayLimitsPort),
	applyReturnSuccess(ApplyReturnResp.class, "ApplyReturn", Config.gameplayLimitsPort),
	applyReturnError(CustomErrorResponse.class, "ApplyReturn", Config.gameplayLimitsPort),
	revertReturnSuccess(RevertReturnResp.class, "RevertReturn", Config.gameplayLimitsPort),
	revertReturnError(CustomErrorResponse.class, "RevertReturn", Config.gameplayLimitsPort),
	
	
	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;
	private String port;
	
	<T> ResponseEndpoints(Class<T> cls, String endpoint, String port) {
		this.respClass = cls;
		this.endPoint = endpoint;
		this.port = port;
	}
	
	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

	public String getPort() {
		return port;
	}

}
