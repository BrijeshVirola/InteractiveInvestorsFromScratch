package tests.balanceservice;

import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

import java.math.BigInteger;
import java.util.UUID;

import org.testng.annotations.Test;

import common.BaseClassSetup;
import common.CustomErrorResponse;
import common.TransactionType;
import domain.BaseRequest;
import tests.balanceservice.enums.BalanceEndpoints;
import tests.balanceservice.request.QueueManualVoidReturnReq;
import tests.balanceservice.response.QueueManualVoidReturnResp;

public class QueueManualVoidReturnTests extends BaseClassSetup {

	@Test(description = "Queue Manual Void Return - Positive Scenario")
	public void manual_Void_Return() {
		BigInteger transactionId = new BigInteger("6789");
		QueueManualVoidReturnReq req = new QueueManualVoidReturnReq(TransactionType.VOID_RETURN, transactionId);

		QueueManualVoidReturnResp actResponse = BaseRequest.post(req, BalanceEndpoints.queueManualVoidReturn);
		QueueManualVoidReturnResp expResponse = new QueueManualVoidReturnResp("OK");

		assertReflectionEquals(expResponse, actResponse);
	}

	@Test(description = "Queue Manual Void Return - Invalid Transaction Type")
	public void manual_Void_Return_Invalid_Transaction_Type() {
		BigInteger transactionId = new BigInteger("6789");
		String id = UUID.randomUUID().toString();

		QueueManualVoidReturnReq req = new QueueManualVoidReturnReq(TransactionType.STAKE, transactionId);
		req.setId(id);

		CustomErrorResponse actualError = BaseRequest.post(req, BalanceEndpoints.queueManualVoidReturnError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(1009)
				.message("Invalid transaction type")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Queue Manual Void Return - Invalid Transaction Id")
	public void manual_Void_Return_Invalid_TransactionId() {

		String id = UUID.randomUUID().toString();
		BigInteger invalidTransaction = new BigInteger("9976476474674542542");
		QueueManualVoidReturnReq req = new QueueManualVoidReturnReq(TransactionType.VOID_RETURN, invalidTransaction);
		req.setId(id);

		CustomErrorResponse actualError = BaseRequest.post(req, BalanceEndpoints.queueManualVoidReturnError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(4)
				.message("Couldn't unmarshal params into target type : json: cannot unmarshal number 9976476474674542542 into Go struct field queueManualVoidReturnRequest.source_bet365_games_transaction_id of type int64")
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Queue Manual Void Return - Missing transaction_type_id")
	public void manual_Void_Return_Missing_Transaction_Type_Id() {

		String id = UUID.randomUUID().toString();
		BigInteger transactionId = new BigInteger("6789");
		QueueManualVoidReturnReq req = new QueueManualVoidReturnReq(TransactionType.MISSING, transactionId);
		req.setId(id);

		CustomErrorResponse actualError = BaseRequest.post(req, BalanceEndpoints.queueManualVoidReturnError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: transaction_type_id")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}

	@Test(description = "Queue Manual Void Return - Missing transaction_type_id")
	public void manual_Void_Return_Missing_Source_Bet365_Games_Transaction_Id() {

		String id = UUID.randomUUID().toString();
		BigInteger transactionId = new BigInteger("0");
		QueueManualVoidReturnReq req = new QueueManualVoidReturnReq(TransactionType.RETURN, transactionId);
		req.setId(id);

		CustomErrorResponse actualError = BaseRequest.post(req, BalanceEndpoints.queueManualVoidReturnError);
		CustomErrorResponse expectedError = new CustomErrorResponse.Builder()
				.code(7)
				.message("Missing parameter: source_bet365_games_transaction_id")
				.id(id)
				.build();

		assertReflectionEquals(expectedError, actualError);
	}
}
