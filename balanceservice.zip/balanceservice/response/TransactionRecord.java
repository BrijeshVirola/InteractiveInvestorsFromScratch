package tests.balanceservice.response;

import common.enumsconstants.Errors;
import domain.ErrorResponse;
import tests.balanceservice.request.AdjustBalanceReq;
import tests.balanceservice.responseobjects.TransactionResult;

public class TransactionRecord extends ErrorResponse {
	
	String Id;
	private TransactionResult result;
	
	public TransactionResult getResult() {
		return result;
	}
	
	public TransactionRecord(Errors error) {
		super(error);
	}
	
	public TransactionRecord(AdjustBalanceReq request, TransactionRecord transaction) {
		this.result = new TransactionResult(request, transaction);
	}
	
	public TransactionRecord(AdjustBalanceReq request, AdjustBalanceResp response, boolean isNew) {
		this.Id = (String) request.getParams().get("Id");
		this.result = new TransactionResult(request, response, isNew);
		
	}
}
