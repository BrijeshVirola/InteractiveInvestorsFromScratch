package tests.balanceservice.enums;


import common.CustomErrorResponse;
import common.enumsconstants.ResponseEndpoints;
import tests.balanceservice.response.AdjustBalanceResp;
import tests.balanceservice.response.GetLatestTransactionByTransactionTypeIdResp;
import tests.balanceservice.response.GetTransactionByIdResp;
import tests.balanceservice.response.GetTransactionsByGameRoundResp;
import tests.balanceservice.response.GetTransactionsByPartnerTransactionIdResp;
import tests.balanceservice.response.GetUserBalanceResp;
import tests.balanceservice.response.QueueManualVoidReturnResp;
import tests.cbsbalanceservice.response.GetCbsTransactionResp;
import tests.cbsbalanceservice.response.GetCbsTransactionsResp;

public enum BalanceEndpoints implements ResponseEndpoints {

	getUserBalanceSuccess(GetUserBalanceResp.class, "GetUserBalance"),
	getUserBalanceError(CustomErrorResponse.class, "GetUserBalance"),
	adjustBalance(AdjustBalanceResp.class, "adjustBalance"),
	getTransactionsByPartnerTransactionIDSuccess(GetCbsTransactionsResp.class, "GetTransactionsByPartnerTransactionID"),
	getTransactionsByPartnerTransactionIDError(CustomErrorResponse.class, "GetTransactionsByPartnerTransactionID"),
	getLatestTransactionByTransactionTypeIdSuccess(GetCbsTransactionResp.class, "GetLatestTransactionByTransactionTypeId"),
	getLatestTransactionByTransactionTypeIdError(CustomErrorResponse.class, "GetLatestTransactionByTransactionTypeId"),
	adjustBalanceError(CustomErrorResponse.class, "adjustBalance"),
	getTransactionsByGameRoundSuccess(GetTransactionsByGameRoundResp.class, "getTransactionsByGameRound"),
	getTransactionsByGameRoundError(CustomErrorResponse.class, "getTransactionsByGameRound"),
	getLatestTransactionByTransactionTypeId(GetLatestTransactionByTransactionTypeIdResp.class, "GetLatestTransactionByTransactionTypeId"),
	getTransactionsByPartnerTransactionID(GetTransactionsByPartnerTransactionIdResp.class, "GetTransactionsByPartnerTransactionID"),
	getTransactionById(GetTransactionByIdResp.class, "GetTransactionById"),
	getTransactionByIdError(CustomErrorResponse.class, "GetTransactionById"),
	queueManualVoidReturn(QueueManualVoidReturnResp.class, "QueueManualVoidReturn"),
	queueManualVoidReturnError(CustomErrorResponse.class, "QueueManualVoidReturn");

	@SuppressWarnings("rawtypes")
	private Class respClass;
	private String endPoint;

	<T> BalanceEndpoints(Class<T> cls, String endpoint) {
		this.respClass = cls;
		this.endPoint = endpoint;
	}

	@SuppressWarnings("unchecked")
	public <T> Class<T> getRespClass() {
		return respClass;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
