package tests.balanceservice.request;

import java.math.BigInteger;
import common.TransactionType;

public class QueueManualVoidReturnReq {
	
	@SuppressWarnings("unused")
	private String id;
	@SuppressWarnings("unused")
	private String Method = "QueueManualVoidReturn";
	@SuppressWarnings("unused")
	private QueueManualVoidReturnParams Params;
	
	public QueueManualVoidReturnReq(TransactionType transactionType,
			BigInteger sourceBet365gamesTransaction_Id) {
		Params = new QueueManualVoidReturnParams(transactionType, sourceBet365gamesTransaction_Id);
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	class QueueManualVoidReturnParams {
		@SuppressWarnings("unused")
		private int transaction_type_id;
		@SuppressWarnings("unused")
		private BigInteger source_bet365_games_transaction_id;
		
		public QueueManualVoidReturnParams(TransactionType transactionType,
				BigInteger sourceBet365gamesTransaction_Id) {
			this.transaction_type_id = transactionType.getValue();
			this.source_bet365_games_transaction_id = sourceBet365gamesTransaction_Id;
		}
	}
}
